# =============================================================================
# SDTM Clinical Data Explorer - Production Grade
# app.py  -  Entry point / Home page
# =============================================================================
# Encoding: ASCII-safe, straight quotes only, no Unicode hidden chars
# =============================================================================

import streamlit as st
import pandas as pd
import sys
import os
import hashlib
import tempfile
from pathlib import Path

ROOT = Path(__file__).parent.resolve()
sys.path.insert(0, str(ROOT))

from src.data.loader import SDTMLoader, dir_fingerprint
from src.data.session import init_session, get_population_df
from src.utils.theme import apply_theme, render_theme_toggle
from src.utils.helpers import format_n_pct

st.set_page_config(
    page_title="SDTM Clinical Data Explorer",
    page_icon="[CDE]",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------------------------------------------------------------------------
# Session + theme
# ---------------------------------------------------------------------------
init_session()
apply_theme(st.session_state.get("dark_mode", True))


# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------
def render_sidebar():
    with st.sidebar:
        render_theme_toggle()
        st.markdown("---")
        st.markdown("### Data Source")

        src = st.radio("Load from", ["Upload files", "Folder path"], horizontal=True)

        ftype = st.multiselect(
            "File types",
            [".xpt", ".sas7bdat"],
            default=[".xpt", ".sas7bdat"],
        )

        uploaded = None
        folder_path = None

        if src == "Upload files":
            uploaded = st.file_uploader(
                "Drop SDTM files (.xpt / .sas7bdat)",
                type=["xpt", "sas7bdat"],
                accept_multiple_files=True,
            )
        else:
            folder_path = st.text_input("SDTM folder path", value="data/sdtm")

        pop_options = ["All Subjects", "Safety (SAFFL=Y)", "ITT (ITTFL=Y)", "PP (PPROTFL=Y)"]
        pop_sel = st.selectbox("Analysis Population", pop_options, index=1)
        st.session_state["pop_selection"] = pop_sel

        if st.button("Load Data", type="primary", use_container_width=True):
            _load_data(src, uploaded, folder_path, ftype)

        st.markdown("---")
        if st.button(
            "Try Demo Data (60 synthetic subjects)",
            use_container_width=True,
            help="Loads synthetic DM/AE/EX/LB/VS/CM/MH/DS/RS/TR domains - no files required",
        ):
            _load_demo()

        if st.session_state.get("data_loaded"):
            _render_sidebar_summary()


def _files_fp(files):
    m = hashlib.md5()
    for f in sorted(files, key=lambda x: x.name):
        m.update(f.name.encode())
        m.update(str(f.size or 0).encode())
        raw = f.getvalue()
        m.update(raw[:512])
        m.update(raw[-512:] if len(raw) > 512 else raw)
    return m.hexdigest()


@st.cache_data(show_spinner="Loading SDTM data ...")
def _cached_load_folder(path, fp):
    loader = SDTMLoader()
    return loader.load_all_domains(data_path=path)


@st.cache_data(show_spinner="Loading uploaded files ...")
def _cached_load_uploads(fp, _files):
    tmp = tempfile.mkdtemp(prefix="sdtm_")
    for f in _files:
        dest = Path(tmp) / Path(f.name).name
        with open(dest, "wb") as out:
            out.write(f.getvalue())
    loader = SDTMLoader()
    return loader.load_all_domains(data_path=tmp)


def _load_data(src, uploaded, folder_path, ftype):
    try:
        if src == "Upload files":
            if not uploaded:
                st.sidebar.warning("Please upload at least one file.")
                return
            fp = _files_fp(uploaded)
            domains = _cached_load_uploads(fp, uploaded)
        else:
            fp = dir_fingerprint(folder_path, ftype)
            domains = _cached_load_folder(folder_path, fp)

        from src.derivations.populations import PopulationDerivation
        pop = PopulationDerivation()
        adsl = pop.create_adsl(domains.get("dm"), domains.get("ex"))

        from src.graph.builder import SDTMGraphBuilder
        g_builder = SDTMGraphBuilder()
        graph = g_builder.build(domains, adsl)

        st.session_state["sdtm_data"] = domains
        st.session_state["adsl"] = adsl
        st.session_state["sdtm_graph"] = graph
        st.session_state["data_loaded"] = True
        st.sidebar.success(f"Loaded {len(domains)} domain(s).")
        st.rerun()
    except FileNotFoundError as exc:
        st.sidebar.error(f"Path not found: {exc}")
    except Exception as exc:
        st.sidebar.error(f"Load error: {exc}")
        import traceback
        st.sidebar.code(traceback.format_exc())



def _load_demo():
    """Load synthetic demo data for testing without real SDTM files."""
    try:
        with st.spinner("Generating demo data ..."):
            from src.data.demo_data import load_demo_data
            from src.graph.builder import SDTMGraphBuilder
            domains, adsl = load_demo_data()
            g_builder = SDTMGraphBuilder()
            graph = g_builder.build(domains, adsl)
            st.session_state["sdtm_data"] = domains
            st.session_state["adsl"] = adsl
            st.session_state["sdtm_graph"] = graph
            st.session_state["data_loaded"] = True
        st.sidebar.success(
            f"Demo loaded: {len(domains)} domains, {len(adsl)} subjects."
        )
        st.rerun()
    except Exception as exc:
        st.sidebar.error(f"Demo load error: {exc}")
        import traceback
        st.sidebar.code(traceback.format_exc())

def _render_sidebar_summary():
    adsl = st.session_state.get("adsl")
    if adsl is None:
        return
    st.sidebar.markdown("---")
    st.sidebar.markdown("### Population Filters")

    trts = []
    for col in ["TRT01A", "ACTARM", "ARM"]:
        if col in adsl.columns:
            trts = sorted(adsl[col].dropna().unique().tolist())
            break
    if trts:
        sel_trts = st.sidebar.multiselect("Treatment Arms", trts, default=trts)
        st.session_state["sel_treatments"] = sel_trts
    else:
        st.session_state["sel_treatments"] = []

    st.sidebar.markdown("---")
    st.sidebar.markdown("### Study Summary")
    n = len(adsl)
    st.sidebar.metric("Total Subjects", n)
    for flag, label in [("SAFFL", "Safety"), ("ITTFL", "ITT"), ("PPROTFL", "PP")]:
        if flag in adsl.columns:
            k = (adsl[flag] == "Y").sum()
            st.sidebar.metric(label, format_n_pct(int(k), n))

    domains = st.session_state.get("sdtm_data", {})
    st.sidebar.metric("Domains Loaded", len(domains))


# ---------------------------------------------------------------------------
# Home dashboard
# ---------------------------------------------------------------------------
def render_home():
    dm = st.session_state.get("dark_mode", True)
    accent = "#38bdf8" if dm else "#2563eb"

    st.markdown(
        f"<h1 style='color:{accent};margin-bottom:4px;'>"
        "SDTM Clinical Data Explorer</h1>",
        unsafe_allow_html=True,
    )
    st.markdown(
        "<p style='color:#94a3b8;margin-top:0;'>Production-grade exploratory "
        "analysis platform for clinical trial SDTM datasets</p>",
        unsafe_allow_html=True,
    )

    if not st.session_state.get("data_loaded"):
        st.info("Load SDTM data using the sidebar to begin.")
        _render_landing_cards()
        return

    adsl = st.session_state["adsl"]
    sdtm = st.session_state["sdtm_data"]
    _render_kpi_ribbon(adsl, sdtm)
    st.markdown("---")
    _render_domain_status(sdtm)


def _render_landing_cards():
    cols = st.columns(3)
    features = [
        ("Safety Analysis", "AE incidence (n/N), TEAE, Grade 3+, SAE, causality tables"),
        ("Graph RAG", "Inter-domain NetworkX knowledge graph with community detection"),
        ("Efficacy", "KM curves, waterfall, spider plots, CHG/PCHG derivations"),
        ("Lab & VS", "Shift tables, MAAVs, Hys Law, panel views, spaghetti plots"),
        ("Patient Profile", "4-panel timeline: exposure + AE + labs + tumor"),
        ("Oncology", "PFS/OS, RECIST waterfall, swimmer plot, response tables"),
    ]
    for i, (title, desc) in enumerate(features):
        with cols[i % 3]:
            st.markdown(
                f"**{title}**  \n{desc}",
                help=desc,
            )


def _render_kpi_ribbon(adsl, sdtm):
    n = len(adsl)
    ae = sdtm.get("ae")
    ex = sdtm.get("ex")
    lb = sdtm.get("lb")

    safety_n = int((adsl["SAFFL"] == "Y").sum()) if "SAFFL" in adsl.columns else n
    ae_n = len(ae) if ae is not None else 0
    sae_n = (
        int((ae["AESER"] == "Y").sum())
        if ae is not None and "AESER" in ae.columns
        else 0
    )
    lb_n = int(lb["USUBJID"].nunique()) if lb is not None and "USUBJID" in lb.columns else 0

    c1, c2, c3, c4, c5, c6 = st.columns(6)
    c1.metric("Subjects", n)
    c2.metric("Safety Pop", safety_n)
    c3.metric("AE Records", f"{ae_n:,}")
    c4.metric("SAEs", sae_n)
    c5.metric("Domains", len(sdtm))
    c6.metric("Subjects w/ Labs", lb_n)


def _render_domain_status(sdtm):
    st.markdown("#### Loaded Domains")
    expected = ["dm", "ae", "ex", "lb", "vs", "cm", "mh", "ds", "sv",
                "tr", "rs", "tu", "dv", "fa", "eg", "pc", "pp"]
    rows = []
    for d in expected:
        if d in sdtm:
            df = sdtm[d]
            subj = (
                int(df["USUBJID"].nunique())
                if "USUBJID" in df.columns
                else "-"
            )
            rows.append({
                "Domain": d.upper(),
                "Status": "Available",
                "Records": f"{len(df):,}",
                "Subjects": subj,
                "Variables": len(df.columns),
            })
        else:
            rows.append({
                "Domain": d.upper(),
                "Status": "Missing",
                "Records": "-",
                "Subjects": "-",
                "Variables": "-",
            })
    for d in sdtm:
        if d not in expected:
            df = sdtm[d]
            subj = (
                int(df["USUBJID"].nunique())
                if "USUBJID" in df.columns
                else "-"
            )
            rows.append({
                "Domain": d.upper(),
                "Status": "Loaded (custom)",
                "Records": f"{len(df):,}",
                "Subjects": subj,
                "Variables": len(df.columns),
            })

    df_status = pd.DataFrame(rows)

    def _color_status(val):
        if val == "Available":
            return "color: #22c55e"
        if val == "Missing":
            return "color: #ef4444"
        return "color: #f59e0b"

    styled = df_status.style.applymap(_color_status, subset=["Status"])
    st.dataframe(styled, use_container_width=True, hide_index=True, height=420)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    render_sidebar()
    render_home()


if __name__ == "__main__":
    main()
