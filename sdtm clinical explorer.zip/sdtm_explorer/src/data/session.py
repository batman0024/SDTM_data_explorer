# =============================================================================
# src/data/session.py  -  Centralised session state helpers
# =============================================================================

import streamlit as st
import pandas as pd


_DEFAULTS = {
    "data_loaded": False,
    "sdtm_data": {},
    "adsl": None,
    "sdtm_graph": None,
    "dark_mode": True,
    "pop_selection": "Safety (SAFFL=Y)",
    "sel_treatments": [],
    "selected_subject": None,
    "_audit_log": [],
}


def init_session():
    for key, val in _DEFAULTS.items():
        if key not in st.session_state:
            st.session_state[key] = val


def get_population_df() -> pd.DataFrame:
    """Return ADSL filtered to the selected analysis population."""
    adsl = st.session_state.get("adsl")
    if adsl is None or adsl.empty:
        return pd.DataFrame()

    pop = st.session_state.get("pop_selection", "All Subjects")
    trts = st.session_state.get("sel_treatments", [])

    df = adsl.copy()

    if "Safety" in pop and "SAFFL" in df.columns:
        df = df[df["SAFFL"] == "Y"]
    elif "ITT" in pop and "ITTFL" in df.columns:
        df = df[df["ITTFL"] == "Y"]
    elif "PP" in pop and "PPROTFL" in df.columns:
        df = df[df["PPROTFL"] == "Y"]

    trt_col = next((c for c in ["TRT01A", "ACTARM", "ARM"] if c in df.columns), None)
    if trts and trt_col:
        df = df[df[trt_col].isin(trts)]

    return df


def get_trt_col(adsl: pd.DataFrame) -> str:
    """Return the treatment variable name found in ADSL."""
    for col in ["TRT01A", "ACTARM", "ARM"]:
        if col in adsl.columns:
            return col
    return ""


def log_action(action: str, detail: str = ""):
    import datetime
    entry = {
        "timestamp": datetime.datetime.now().isoformat(timespec="seconds"),
        "action": action,
        "detail": detail,
    }
    st.session_state["_audit_log"].append(entry)
