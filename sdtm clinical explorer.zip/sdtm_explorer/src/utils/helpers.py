# =============================================================================
# src/utils/helpers.py  -  Shared utility functions
# =============================================================================

import pandas as pd
import numpy as np
import re
from typing import Optional, Any


def format_n_pct(n: int, N: int, decimals: int = 1) -> str:
    pct = n / N * 100 if N > 0 else 0.0
    return f"{n} ({pct:.{decimals}f}%)"


def detect_variable_type(series: pd.Series, max_cat: int = 20) -> str:
    """Return 'continuous', 'categorical', or 'datetime'."""
    if pd.api.types.is_datetime64_any_dtype(series):
        return "datetime"
    num = pd.to_numeric(series, errors="coerce")
    n_notnull = num.notna().sum()
    if n_notnull > 0 and (n_notnull / max(1, len(series))) > 0.5:
        n_unique = num.dropna().nunique()
        if n_unique > max_cat:
            return "continuous"
    return "categorical"


def get_domain_label(domain: str) -> str:
    labels = {
        "dm": "Demographics",
        "ae": "Adverse Events",
        "ex": "Exposure",
        "lb": "Lab Results",
        "vs": "Vital Signs",
        "cm": "Concomitant Medications",
        "mh": "Medical History",
        "ds": "Disposition",
        "sv": "Subject Visits",
        "tr": "Tumor Results",
        "rs": "Disease Response",
        "tu": "Tumor Identification",
        "dv": "Protocol Deviations",
        "fa": "Findings About",
        "eg": "ECG Test Results",
        "pc": "PK Concentrations",
        "pp": "PK Parameters",
        "ce": "Clinical Events",
    }
    return labels.get(domain.lower(), domain.upper())


def safe_date(val: Any) -> Optional[pd.Timestamp]:
    try:
        return pd.to_datetime(val, errors="coerce")
    except Exception:
        return None


def normalize_visit_order(series: pd.Series) -> pd.Series:
    """
    Try to sort VISIT labels logically:
    Screening < Baseline < Week N < End of Study
    """
    VISIT_ORDER = {
        "SCREEN": -2, "SCREENING": -2, "SCR": -2,
        "BASELINE": 0, "BASE": 0, "BL": 0, "DAY 1": 0,
        "END OF STUDY": 9999, "EOS": 9999, "EOT": 9998,
        "UNSCHEDULED": 9997, "EARLY TERMINATION": 9996,
    }

    def _key(v):
        s = str(v).strip().upper()
        if s in VISIT_ORDER:
            return VISIT_ORDER[s]
        # Extract numeric week/day
        m = re.search(r"WEEK\s*(\d+)", s)
        if m:
            return int(m.group(1)) * 7
        m = re.search(r"DAY\s*(\d+)", s)
        if m:
            return int(m.group(1))
        m = re.search(r"(\d+)", s)
        if m:
            return int(m.group(1))
        return 5000

    return series.map(_key)


def create_frequency_table(series: pd.Series) -> pd.DataFrame:
    vc = series.value_counts(dropna=True)
    pct = (vc / vc.sum() * 100).round(1)
    return pd.DataFrame({
        "Category": vc.index,
        "N": vc.values,
        "Percent": pct.values,
        "N (%)": [f"{n} ({p:.1f}%)" for n, p in zip(vc.values, pct.values)],
    })


def pfs_from_rs_ds(
    rs: Optional[pd.DataFrame],
    ds: Optional[pd.DataFrame],
    ex: pd.DataFrame,
    dm: Optional[pd.DataFrame] = None,
) -> pd.DataFrame:
    """
    Derive PFS time-to-event dataset from RS/DS/EX/DM.
    Returns DataFrame: USUBJID, ARM, PFS_MONTHS, EVENT, EVENT_TYPE
    """
    rows = []
    if ex is None or ex.empty or "EXSTDTC" not in ex.columns:
        return pd.DataFrame()

    ex2 = ex.copy()
    ex2.columns = [c.upper() for c in ex2.columns]
    ex2["EXSTDTC"] = pd.to_datetime(ex2["EXSTDTC"], errors="coerce")

    subjs = ex2["USUBJID"].dropna().unique() if "USUBJID" in ex2.columns else []

    for sid in subjs:
        sx = ex2[ex2["USUBJID"] == sid]
        start = sx["EXSTDTC"].min()
        if pd.isna(start):
            continue

        # Progression from RS
        prog_dt = None
        if rs is not None and not rs.empty and "RSSTRESC" in rs.columns:
            rs2 = rs.copy()
            rs2.columns = [c.upper() for c in rs2.columns]
            sr = rs2[rs2.get("USUBJID", pd.Series()) == sid] if "USUBJID" in rs2.columns else pd.DataFrame()
            if not sr.empty and "RSDTC" in sr.columns:
                prog_rows = sr[sr["RSSTRESC"].astype(str).str.upper().isin(
                    ["PD", "PROGRESSIVE DISEASE"]
                )]
                if not prog_rows.empty:
                    prog_dt = pd.to_datetime(prog_rows["RSDTC"], errors="coerce").min()

        # Death from DS
        death_dt = None
        if ds is not None and not ds.empty:
            ds2 = ds.copy()
            ds2.columns = [c.upper() for c in ds2.columns]
            sd = ds2[ds2.get("USUBJID", pd.Series()) == sid] if "USUBJID" in ds2.columns else pd.DataFrame()
            if not sd.empty and "DSDECOD" in sd.columns:
                death_rows = sd[
                    sd["DSDECOD"].astype(str).str.upper().str.contains("DEATH", na=False)
                ]
                if not death_rows.empty and "DSSTDTC" in sd.columns:
                    death_dt = pd.to_datetime(
                        death_rows["DSSTDTC"].iloc[0], errors="coerce"
                    )

        ev_dates = [d for d in [prog_dt, death_dt] if pd.notna(d)]
        if ev_dates:
            ev_date = min(ev_dates)
            event = 1
            ev_type = "Progression" if ev_date == prog_dt else "Death"
        else:
            event = 0
            ev_type = "Censored"
            ev_date = start  # will refine with last RS date

            if rs is not None and not rs.empty and "RSDTC" in rs.columns:
                rs3 = rs.copy()
                rs3.columns = [c.upper() for c in rs3.columns]
                sr = rs3[rs3.get("USUBJID", pd.Series()) == sid] if "USUBJID" in rs3.columns else pd.DataFrame()
                if not sr.empty:
                    last_rs = pd.to_datetime(sr["RSDTC"], errors="coerce").max()
                    if pd.notna(last_rs):
                        ev_date = last_rs

        months = max(0.0, (ev_date - start).days / 30.44)

        arm = ""
        if dm is not None and not dm.empty:
            dm2 = dm.copy()
            dm2.columns = [c.upper() for c in dm2.columns]
            for arm_col in ["TRT01A", "ARM", "ACTARM"]:
                if arm_col in dm2.columns:
                    row_dm = dm2[dm2.get("USUBJID", pd.Series()) == sid]
                    if not row_dm.empty:
                        arm = str(row_dm[arm_col].iloc[0])
                        break

        rows.append({
            "USUBJID": sid,
            "ARM": arm,
            "PFS_MONTHS": round(months, 3),
            "EVENT": event,
            "EVENT_TYPE": ev_type,
        })

    return pd.DataFrame(rows) if rows else pd.DataFrame()
