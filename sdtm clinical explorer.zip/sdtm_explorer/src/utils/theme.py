# =============================================================================
# src/utils/theme.py  -  Dark / Light mode CSS injection + toggle
# =============================================================================

import streamlit as st

DARK = {
    "bg":        "#0f172a",
    "card":      "#1e293b",
    "border":    "#334155",
    "text":      "#e2e8f0",
    "subtext":   "#94a3b8",
    "accent":    "#38bdf8",
    "accent2":   "#818cf8",
    "success":   "#22c55e",
    "warning":   "#f59e0b",
    "danger":    "#ef4444",
    "hover":     "#263147",
    "input":     "#1e293b",
    "sidebar_bg":"#0f172a",
    "metric_bg": "#1e293b",
}

LIGHT = {
    "bg":        "#f8fafc",
    "card":      "#ffffff",
    "border":    "#e2e8f0",
    "text":      "#1e293b",
    "subtext":   "#64748b",
    "accent":    "#2563eb",
    "accent2":   "#7c3aed",
    "success":   "#16a34a",
    "warning":   "#d97706",
    "danger":    "#dc2626",
    "hover":     "#f1f5f9",
    "input":     "#ffffff",
    "sidebar_bg":"#f1f5f9",
    "metric_bg": "#ffffff",
}


def apply_theme(dark: bool = True):
    c = DARK if dark else LIGHT
    css = f"""
    <style>
    /* ---- root ---- */
    .stApp {{
        background-color: {c["bg"]};
        color: {c["text"]};
    }}
    /* ---- sidebar ---- */
    section[data-testid="stSidebar"] {{
        background-color: {c["sidebar_bg"]};
        border-right: 1px solid {c["border"]};
    }}
    section[data-testid="stSidebar"] * {{
        color: {c["text"]} !important;
    }}
    /* ---- metrics ---- */
    div[data-testid="stMetric"] {{
        background-color: {c["metric_bg"]};
        border: 1px solid {c["border"]};
        border-radius: 10px;
        padding: 14px 18px;
    }}
    div[data-testid="stMetricLabel"] p {{
        color: {c["subtext"]} !important;
        font-size: 0.78rem !important;
        font-weight: 600 !important;
        text-transform: uppercase;
        letter-spacing: 0.4px;
    }}
    div[data-testid="stMetricValue"] {{
        color: {c["text"]} !important;
        font-size: 1.6rem !important;
        font-weight: 700 !important;
    }}
    /* ---- dataframes ---- */
    .stDataFrame {{
        border: 1px solid {c["border"]};
        border-radius: 8px;
    }}
    /* ---- inputs ---- */
    .stTextInput input, .stSelectbox div[data-baseweb="select"] {{
        background-color: {c["input"]} !important;
        border-color: {c["border"]} !important;
        color: {c["text"]} !important;
    }}
    /* ---- tabs ---- */
    .stTabs [data-baseweb="tab-list"] {{
        background-color: {c["card"]};
        border-radius: 8px;
        padding: 4px;
    }}
    .stTabs [data-baseweb="tab"] {{
        color: {c["subtext"]};
        font-weight: 600;
    }}
    .stTabs [aria-selected="true"] {{
        color: {c["accent"]} !important;
        background-color: {c["bg"]} !important;
        border-radius: 6px;
    }}
    /* ---- divider ---- */
    hr {{
        border-color: {c["border"]};
    }}
    /* ---- headings ---- */
    h1, h2, h3, h4 {{
        color: {c["text"]};
    }}
    /* ---- expander ---- */
    div[data-testid="stExpander"] {{
        border: 1px solid {c["border"]};
        border-radius: 8px;
        background-color: {c["card"]};
    }}
    /* ---- cards utility class ---- */
    .cde-card {{
        background: {c["card"]};
        border: 1px solid {c["border"]};
        border-radius: 12px;
        padding: 20px 22px;
        margin-bottom: 14px;
    }}
    .cde-badge-ok {{
        display:inline-block;
        background:{c["success"]}22;
        color:{c["success"]};
        border-radius:6px;
        padding:2px 9px;
        font-size:0.76rem;
        font-weight:700;
    }}
    .cde-badge-warn {{
        display:inline-block;
        background:{c["warning"]}22;
        color:{c["warning"]};
        border-radius:6px;
        padding:2px 9px;
        font-size:0.76rem;
        font-weight:700;
    }}
    .cde-badge-err {{
        display:inline-block;
        background:{c["danger"]}22;
        color:{c["danger"]};
        border-radius:6px;
        padding:2px 9px;
        font-size:0.76rem;
        font-weight:700;
    }}
    /* ---- plotly chart container ---- */
    .js-plotly-plot {{
        border-radius: 10px;
    }}
    /* ---- primary button ---- */
    .stButton > button[kind="primary"] {{
        background-color: {c["accent"]};
        color: {"#0f172a" if dark else "#ffffff"};
        border: none;
        font-weight: 700;
        border-radius: 8px;
    }}
    .stButton > button[kind="primary"]:hover {{
        opacity: 0.88;
    }}
    </style>
    """
    st.markdown(css, unsafe_allow_html=True)
    # Store colors so pages can access them for plot theming
    st.session_state["_theme_colors"] = c
    st.session_state["_theme_dark"] = dark


def render_theme_toggle():
    dark = st.session_state.get("dark_mode", True)
    label = "Light Mode" if dark else "Dark Mode"
    icon = "Sun" if dark else "Moon"
    if st.button(f"{icon}  {label}", use_container_width=True, key="__theme_toggle"):
        st.session_state["dark_mode"] = not dark
        st.rerun()


def get_plotly_template(dark: bool = True) -> str:
    return "plotly_dark" if dark else "plotly_white"


def get_colors() -> dict:
    return st.session_state.get("_theme_colors", DARK)
