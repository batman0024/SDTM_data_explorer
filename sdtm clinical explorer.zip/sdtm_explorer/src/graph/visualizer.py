# =============================================================================
# src/graph/visualizer.py  -  Plotly-based interactive graph rendering
# =============================================================================

import pandas as pd
import numpy as np
import logging
from typing import Dict, List, Optional, Any

try:
    import networkx as nx
    HAS_NX = True
except ImportError:
    HAS_NX = False

try:
    import plotly.graph_objects as go
    HAS_PX = True
except ImportError:
    HAS_PX = False

logger = logging.getLogger(__name__)

# Node type -> color mapping
NODE_COLORS = {
    "subject":      "#38bdf8",
    "ae_term":      "#ef4444",
    "soc":          "#f97316",
    "drug":         "#22c55e",
    "lab_test":     "#a855f7",
    "response":     "#fbbf24",
    "cm_drug":      "#6366f1",
    "mh_condition": "#ec4899",
    "unknown":      "#94a3b8",
}

NODE_SIZES = {
    "subject":      14,
    "ae_term":      18,
    "soc":          22,
    "drug":         18,
    "lab_test":     16,
    "response":     16,
    "cm_drug":      14,
    "mh_condition": 14,
    "unknown":      12,
}


def _get_layout(G, layout: str = "spring"):
    """Compute 2-D positions using chosen layout algorithm."""
    if not HAS_NX:
        return {}
    try:
        if layout == "spring":
            return nx.spring_layout(G, k=1.2, seed=42)
        if layout == "kamada_kawai":
            return nx.kamada_kawai_layout(G)
        if layout == "circular":
            return nx.circular_layout(G)
        if layout == "spectral":
            return nx.spectral_layout(G)
        return nx.spring_layout(G, seed=42)
    except Exception:
        return nx.spring_layout(G, seed=42)


def build_plotly_graph(
    G,
    layout: str = "spring",
    max_nodes: int = 300,
    dark: bool = True,
    highlight_subjects: Optional[List[str]] = None,
    title: str = "SDTM Inter-Domain Knowledge Graph",
) -> Optional[Any]:
    """
    Convert a NetworkX graph to an interactive Plotly figure.
    Returns go.Figure or None if prerequisites missing.
    """
    if not HAS_NX or not HAS_PX or G is None:
        return None

    # Sample nodes if graph is too large
    if G.number_of_nodes() > max_nodes:
        # Keep all non-subject nodes + sample subjects
        non_subj = [n for n in G.nodes if not n.startswith("subj::")]
        subj_nodes = [n for n in G.nodes if n.startswith("subj::")]
        rng = np.random.default_rng(42)
        sampled_subj = rng.choice(
            subj_nodes,
            size=min(len(subj_nodes), max_nodes - len(non_subj)),
            replace=False,
        ).tolist()
        keep = set(non_subj + sampled_subj)
        G = G.subgraph(keep)

    # Remove isolated nodes (no edges)
    G = G.subgraph([n for n in G.nodes if G.degree(n) > 0])

    if G.number_of_nodes() == 0:
        return None

    pos = _get_layout(G, layout)

    # Build edge traces grouped by edge type
    edge_traces = []
    edge_types_seen = set()
    for u, v, data in G.edges(data=True):
        if u not in pos or v not in pos:
            continue
        rel = data.get("rel", "")
        x0, y0 = pos[u]
        x1, y1 = pos[v]
        edge_types_seen.add(rel)
        edge_traces.append(
            go.Scatter(
                x=[x0, x1, None],
                y=[y0, y1, None],
                mode="lines",
                line=dict(
                    width=1,
                    color=_edge_color(rel, dark),
                ),
                hoverinfo="none",
                showlegend=False,
                opacity=0.5,
            )
        )

    # Build node traces per node type
    node_traces = []
    nt_groups: Dict[str, List] = {}
    for node in G.nodes:
        nd = G.nodes[node]
        nt = nd.get("node_type", "unknown")
        nt_groups.setdefault(nt, []).append(node)

    highlight_set = set()
    if highlight_subjects:
        highlight_set = {f"subj::{s}" for s in highlight_subjects}

    for nt, nodes in nt_groups.items():
        xs, ys, texts, hovers, colors, sizes = [], [], [], [], [], []
        for node in nodes:
            if node not in pos:
                continue
            nd = G.nodes[node]
            x, y = pos[node]
            xs.append(x)
            ys.append(y)
            label = nd.get("label", node)
            texts.append(label[:20] if len(label) > 20 else label)

            # Hover info
            degree = G.degree(node)
            hover = f"<b>{label}</b><br>Type: {nt}<br>Connections: {degree}"
            if nt == "subject":
                hover += f"<br>Arm: {nd.get('arm', '')}"
                hover += f"<br>Age: {nd.get('age', '')}"
                hover += f"<br>SAFety: {nd.get('saffl', '')}"
            hovers.append(hover)

            color = NODE_COLORS.get(nt, "#94a3b8")
            if node in highlight_set:
                color = "#facc15"
            colors.append(color)
            sz = NODE_SIZES.get(nt, 12)
            if node in highlight_set:
                sz = sz * 1.5
            sizes.append(sz)

        node_traces.append(
            go.Scatter(
                x=xs,
                y=ys,
                mode="markers+text",
                marker=dict(
                    size=sizes,
                    color=colors,
                    line=dict(width=1, color="#0f172a" if dark else "#ffffff"),
                ),
                text=texts,
                textposition="top center",
                textfont=dict(size=8, color="#e2e8f0" if dark else "#1e293b"),
                hovertext=hovers,
                hoverinfo="text",
                name=nt.replace("_", " ").title(),
                showlegend=True,
            )
        )

    # Legend for node types
    legend_traces = []
    for nt, color in NODE_COLORS.items():
        if nt in nt_groups:
            legend_traces.append(
                go.Scatter(
                    x=[None],
                    y=[None],
                    mode="markers",
                    marker=dict(size=10, color=color),
                    name=nt.replace("_", " ").title(),
                    showlegend=True,
                )
            )

    bg = "#0f172a" if dark else "#ffffff"
    paper_bg = "#1e293b" if dark else "#f8fafc"
    text_color = "#e2e8f0" if dark else "#1e293b"

    fig = go.Figure(
        data=edge_traces + node_traces + legend_traces,
    )
    fig.update_layout(
        title=dict(text=title, font=dict(color=text_color, size=15)),
        showlegend=True,
        hovermode="closest",
        margin=dict(l=20, r=20, t=50, b=20),
        paper_bgcolor=paper_bg,
        plot_bgcolor=bg,
        height=600,
        xaxis=dict(
            showgrid=False, zeroline=False, showticklabels=False,
            color=text_color,
        ),
        yaxis=dict(
            showgrid=False, zeroline=False, showticklabels=False,
            color=text_color,
        ),
        legend=dict(
            bgcolor=paper_bg,
            bordercolor="#334155" if dark else "#e2e8f0",
            borderwidth=1,
            font=dict(color=text_color, size=10),
        ),
    )
    return fig


def _edge_color(rel: str, dark: bool) -> str:
    palette = {
        "HAS_AE":           "#ef4444",
        "HAS_SAE":          "#dc2626",
        "RELATED_AE":       "#f97316",
        "RECEIVED_DRUG":    "#22c55e",
        "HAD_LAB":          "#a855f7",
        "HAD_RESPONSE":     "#fbbf24",
        "CONCOM_MED":       "#6366f1",
        "MED_HISTORY":      "#ec4899",
        "SAME_ARM":         "#334155" if dark else "#cbd5e1",
        "BELONGS_TO_SOC":   "#64748b",
    }
    return palette.get(rel, "#475569" if dark else "#94a3b8")


def build_ae_cooccurrence_heatmap(
    cooc_df: pd.DataFrame, dark: bool = True
) -> Optional[Any]:
    """Build a heatmap from AE co-occurrence data."""
    if not HAS_PX or cooc_df.empty:
        return None
    # Pivot to matrix
    all_terms = sorted(
        set(cooc_df["AE_1"].tolist() + cooc_df["AE_2"].tolist())
    )[:30]
    mat = pd.DataFrame(0, index=all_terms, columns=all_terms)
    for _, row in cooc_df.iterrows():
        a, b, n = row["AE_1"], row["AE_2"], row["Subjects"]
        if a in mat.index and b in mat.columns:
            mat.loc[a, b] = n
            mat.loc[b, a] = n

    bg = "#0f172a" if dark else "#ffffff"
    paper_bg = "#1e293b" if dark else "#f8fafc"
    text_color = "#e2e8f0" if dark else "#1e293b"

    fig = go.Figure(
        go.Heatmap(
            z=mat.values,
            x=mat.columns.tolist(),
            y=mat.index.tolist(),
            colorscale="Reds",
            showscale=True,
            hovertemplate="AE_1: %{y}<br>AE_2: %{x}<br>Subjects: %{z}<extra></extra>",
        )
    )
    fig.update_layout(
        title=dict(
            text="AE Co-occurrence Matrix (subjects sharing both AEs)",
            font=dict(color=text_color),
        ),
        paper_bgcolor=paper_bg,
        plot_bgcolor=bg,
        height=500,
        xaxis=dict(
            tickfont=dict(size=9, color=text_color),
            tickangle=45,
        ),
        yaxis=dict(
            tickfont=dict(size=9, color=text_color),
        ),
        margin=dict(l=150, b=150, t=60),
    )
    return fig
