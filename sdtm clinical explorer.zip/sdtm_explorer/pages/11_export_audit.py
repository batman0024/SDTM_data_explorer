# =============================================================================
# pages/11_export_audit.py  -  Export reports and audit trail
# =============================================================================

import streamlit as st
import pandas as pd
import io
import sys
import os
import datetime
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.data.session import init_session, get_population_df
from src.utils.theme import apply_theme, get_colors

init_session()
apply_theme(st.session_state.get("dark_mode", True))
dark = st.session_state.get("dark_mode", True)
c = get_colors()

st.title("Export & Audit Trail")

if not st.session_state.get("data_loaded"):
    st.warning("Load data first.")
    st.stop()

sdtm = st.session_state["sdtm_data"]
adsl = get_population_df()

tab1, tab2, tab3 = st.tabs(["Export Data", "Audit Log", "Session Info"])

# =========================================================
# Tab 1: Export
# =========================================================
with tab1:
    st.markdown("### Export SDTM Domains to Excel")
    selected_domains = st.multiselect(
        "Select domains to export",
        list(sdtm.keys()),
        default=list(sdtm.keys()),
        format_func=str.upper,
    )
    if st.button("Generate Excel Workbook", type="primary"):
        with st.spinner("Generating ..."):
            buf = io.BytesIO()
            with pd.ExcelWriter(buf, engine="openpyxl") as writer:
                for dom in selected_domains:
                    df = sdtm[dom]
                    sheet_name = dom.upper()[:31]
                    df.to_excel(writer, sheet_name=sheet_name, index=False)
                if not adsl.empty:
                    adsl.to_excel(writer, sheet_name="ADSL", index=False)
            buf.seek(0)
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        st.download_button(
            "Download Excel",
            buf,
            f"sdtm_export_{ts}.xlsx",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )

    st.markdown("---")
    st.markdown("### Export Population Dataset (ADSL)")
    if not adsl.empty:
        csv = adsl.to_csv(index=False).encode("utf-8")
        st.download_button("Download ADSL CSV", csv, "adsl.csv", "text/csv")
    else:
        st.info("No ADSL available.")

    st.markdown("---")
    st.markdown("### Export Domain Summary Statistics")
    if st.button("Generate Summary Report CSV"):
        rows = []
        for dom, df in sdtm.items():
            total_cells = len(df) * len(df.columns) or 1
            miss_pct = df.isna().sum().sum() / total_cells * 100
            rows.append({
                "Domain": dom.upper(),
                "Records": len(df),
                "Subjects": int(df["USUBJID"].nunique()) if "USUBJID" in df.columns else "N/A",
                "Variables": len(df.columns),
                "Missing_Pct": round(miss_pct, 2),
            })
        summary_df = pd.DataFrame(rows)
        csv = summary_df.to_csv(index=False).encode("utf-8")
        st.download_button("Download Domain Summary", csv, "domain_summary.csv")

# =========================================================
# Tab 2: Audit Log
# =========================================================
with tab2:
    st.markdown("### Session Audit Trail")
    from src.data.session import log_action
    log_action("PAGE_VIEW", "Export & Audit page opened")

    audit = st.session_state.get("_audit_log", [])
    if not audit:
        st.info("No audit entries yet.")
    else:
        audit_df = pd.DataFrame(audit)
        st.dataframe(audit_df, use_container_width=True, hide_index=True)
        log_text = "\n".join(
            f"[{r['timestamp']}] {r['action']}: {r['detail']}"
            for r in audit
        )
        st.download_button(
            "Download Audit Log",
            log_text.encode("utf-8"),
            f"audit_log_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.txt",
        )

# =========================================================
# Tab 3: Session Info
# =========================================================
with tab3:
    st.markdown("### Current Session Information")
    info = {
        "Domains loaded": ", ".join(k.upper() for k in sdtm.keys()),
        "Total subjects (ADSL)": len(adsl),
        "Population filter": st.session_state.get("pop_selection", ""),
        "Treatment filter": ", ".join(st.session_state.get("sel_treatments", [])),
        "Dark mode": str(st.session_state.get("dark_mode", True)),
        "Graph built": "Yes" if st.session_state.get("sdtm_graph") is not None else "No",
        "Timestamp": datetime.datetime.now().isoformat(),
    }
    for k, v in info.items():
        st.markdown(f"**{k}:** {v}")
