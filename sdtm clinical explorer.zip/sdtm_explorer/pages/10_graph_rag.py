# =============================================================================
# pages/10_graph_rag.py  -  SDTM Knowledge Graph + Inter-Domain Insights
# =============================================================================

import streamlit as st
import pandas as pd
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.data.session import init_session, get_population_df
from src.utils.theme import apply_theme, get_colors
from src.graph.builder import GraphAnalytics, HAS_NX
from src.graph.visualizer import (
    build_plotly_graph,
    build_ae_cooccurrence_heatmap,
)

init_session()
apply_theme(st.session_state.get("dark_mode", True))
dark = st.session_state.get("dark_mode", True)
c = get_colors()

st.title("Knowledge Graph & Cross-Domain Insights")
st.caption(
    "NetworkX-based inter-domain relationship graph. "
    "Nodes: Subjects, AE Terms, SOC, Drugs, Lab Tests, Responses. "
    "Edges encode clinical relationships across SDTM domains."
)

if not HAS_NX:
    st.error("networkx not installed. Run: pip install networkx")
    st.stop()

if not st.session_state.get("data_loaded"):
    st.warning("Load data from the Home page first.")
    st.stop()

G = st.session_state.get("sdtm_graph")
if G is None:
    st.error("Graph not built. Please reload data.")
    st.stop()

analytics = GraphAnalytics(G)
summary = analytics.get_graph_summary()

# ---- KPIs ----
k1, k2, k3, k4 = st.columns(4)
k1.metric("Total Nodes", summary.get("total_nodes", 0))
k2.metric("Total Edges", summary.get("total_edges", 0))
k3.metric("Graph Density", f"{summary.get('density', 0):.5f}")
nt = summary.get("node_types", {})
k4.metric("Node Types", len(nt))

st.markdown("---")

tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "Graph Visualization",
    "AE Co-occurrence",
    "Drug-AE Association",
    "Node Centrality",
    "Subject Query",
])

# ---- Tab 1: Graph visualization ----
with tab1:
    ctrl_c1, ctrl_c2, ctrl_c3 = st.columns(3)
    with ctrl_c1:
        layout_alg = st.selectbox(
            "Layout",
            ["spring", "kamada_kawai", "circular", "spectral"],
            key="graph_layout",
        )
    with ctrl_c2:
        max_nodes = st.slider("Max nodes displayed", 50, 500, 200, 50)
    with ctrl_c3:
        highlight_subj = st.text_input(
            "Highlight subject ID (optional)", placeholder="e.g., 01-001"
        )

    subj_list = [highlight_subj] if highlight_subj.strip() else None

    with st.spinner("Rendering graph ..."):
        fig = build_plotly_graph(
            G,
            layout=layout_alg,
            max_nodes=max_nodes,
            dark=dark,
            highlight_subjects=subj_list,
            title="SDTM Inter-Domain Knowledge Graph",
        )

    if fig:
        st.plotly_chart(fig, use_container_width=True, key="main_graph")
    else:
        st.info("Graph is empty or too small to render.")

    # Node type legend
    st.markdown("**Node Type Legend**")
    from src.graph.visualizer import NODE_COLORS
    leg_cols = st.columns(min(len(NODE_COLORS), 4))
    for i, (ntype, color) in enumerate(NODE_COLORS.items()):
        if ntype in nt:
            with leg_cols[i % 4]:
                n_count = nt.get(ntype, 0)
                st.markdown(
                    f"<span style='color:{color};font-weight:700;'>* {ntype.replace('_',' ').title()}</span>"
                    f" ({n_count})",
                    unsafe_allow_html=True,
                )

    with st.expander("Graph Statistics"):
        col_a, col_b = st.columns(2)
        with col_a:
            st.markdown("**Nodes by Type**")
            nt_df = pd.DataFrame(nt.items(), columns=["Node Type", "Count"])
            st.dataframe(nt_df, use_container_width=True, hide_index=True)
        with col_b:
            st.markdown("**Edges by Relationship**")
            et = summary.get("edge_types", {})
            et_df = pd.DataFrame(et.items(), columns=["Relationship", "Count"])
            st.dataframe(et_df, use_container_width=True, hide_index=True)

# ---- Tab 2: AE Co-occurrence ----
with tab2:
    st.markdown(
        "Which AE terms co-occur in the same subjects? "
        "High co-occurrence may indicate a syndrome or drug toxicity cluster."
    )
    min_subj = st.slider("Minimum shared subjects", 1, 20, 2, key="cooc_min")

    with st.spinner("Computing AE co-occurrence ..."):
        cooc = analytics.get_ae_cooccurrence(min_subjects=min_subj)

    if cooc.empty:
        st.info("No AE co-occurrence found at this threshold.")
    else:
        st.markdown(f"**{len(cooc)} AE pairs co-occurring in >= {min_subj} subjects**")
        st.dataframe(cooc.head(50), use_container_width=True, hide_index=True)

        fig_hm = build_ae_cooccurrence_heatmap(cooc, dark=dark)
        if fig_hm:
            st.plotly_chart(fig_hm, use_container_width=True)

# ---- Tab 3: Drug-AE Association ----
with tab3:
    st.markdown(
        "Which drugs are associated with which AE terms (via shared subjects)? "
        "This shows indirect pharmacovigilance signals from cross-domain linkage."
    )
    with st.spinner("Computing drug-AE associations ..."):
        drug_ae = analytics.get_drug_ae_association()

    if drug_ae.empty:
        st.info("No drug-AE associations computed. Ensure EX and AE domains are loaded.")
    else:
        col_f1, col_f2 = st.columns(2)
        drugs = ["All"] + sorted(drug_ae["Drug"].dropna().unique().tolist())
        with col_f1:
            sel_drug = st.selectbox("Filter by Drug", drugs)
        with col_f2:
            min_n = st.number_input("Min subjects", 1, 50, 2, step=1)

        df_show = drug_ae[drug_ae["N_Subjects"] >= min_n]
        if sel_drug != "All":
            df_show = df_show[df_show["Drug"] == sel_drug]

        st.dataframe(df_show.head(100), use_container_width=True, hide_index=True)

        if not df_show.empty:
            import plotly.graph_objects as go
            top = df_show.head(25)
            fig_da = go.Figure(go.Bar(
                x=top["N_Subjects"],
                y=top["AE_Term"] + " [" + top["Drug"] + "]",
                orientation="h",
                marker_color=c["accent"],
            ))
            layout_dark = {
                "paper_bgcolor": c["card"],
                "plot_bgcolor": c["bg"],
                "font": {"color": c["text"]},
                "margin": {"l": 280, "r": 30, "t": 50, "b": 40},
            }
            fig_da.update_layout(
                title="Drug-AE Associations (# shared subjects)",
                height=max(400, len(top) * 28),
                **layout_dark,
            )
            st.plotly_chart(fig_da, use_container_width=True)

# ---- Tab 4: Node Centrality ----
with tab4:
    st.markdown(
        "Most connected non-subject nodes. High degree = frequently shared clinical concept "
        "(e.g., a common AE term or a widely-used concomitant medication)."
    )
    with st.spinner("Computing centrality ..."):
        cent_df = analytics.get_node_centrality()

    if cent_df.empty:
        st.info("Centrality not computable.")
    else:
        type_filter = st.multiselect(
            "Filter by node type",
            sorted(cent_df["Type"].unique()),
            default=sorted(cent_df["Type"].unique()),
        )
        df_cent = cent_df[cent_df["Type"].isin(type_filter)]
        st.dataframe(df_cent, use_container_width=True, hide_index=True)

        if not df_cent.empty:
            import plotly.express as px
            fig_cent = px.scatter(
                df_cent.head(40),
                x="Degree",
                y="Centrality",
                color="Type",
                hover_name="Node",
                size="Degree",
                title="Node Degree vs Centrality",
                color_discrete_sequence=[c["accent"], c["accent2"], c["success"],
                                         c["warning"], c["danger"]],
            )
            fig_cent.update_layout(
                paper_bgcolor=c["card"],
                plot_bgcolor=c["bg"],
                font=dict(color=c["text"]),
            )
            st.plotly_chart(fig_cent, use_container_width=True)

# ---- Tab 5: Subject Neighbourhood Query ----
with tab5:
    st.markdown(
        "Enter a subject ID to explore their neighbourhood in the graph. "
        "Shows all clinical entities connected to this subject."
    )
    adsl = get_population_df()
    subjs = sorted(adsl["USUBJID"].dropna().unique()) if not adsl.empty else []

    sel_subj = st.selectbox("Subject", subjs, key="graph_subj_query") if subjs else st.text_input("Subject ID")

    depth = st.slider("Neighbourhood depth", 1, 3, 1)

    if sel_subj and st.button("Query Graph", type="primary"):
        with st.spinner("Building ego-graph ..."):
            ego = analytics.get_subject_neighbourhood(sel_subj, depth=depth)

        if ego is None or ego.number_of_nodes() == 0:
            st.info(f"Subject {sel_subj} not found in graph.")
        else:
            st.success(
                f"Found {ego.number_of_nodes()} nodes, "
                f"{ego.number_of_edges()} edges within depth {depth}"
            )
            fig_ego = build_plotly_graph(
                ego,
                layout="spring",
                max_nodes=200,
                dark=dark,
                highlight_subjects=[sel_subj],
                title=f"Subject {sel_subj} - Neighbourhood (depth {depth})",
            )
            if fig_ego:
                st.plotly_chart(fig_ego, use_container_width=True)

            # List connected nodes
            nodes_info = []
            for n in ego.nodes:
                nd = ego.nodes[n]
                if n != f"subj::{sel_subj}":
                    nodes_info.append({
                        "Entity": nd.get("label", n),
                        "Type": nd.get("node_type", ""),
                        "Connections": ego.degree(n),
                    })
            if nodes_info:
                st.markdown("**Connected entities:**")
                st.dataframe(
                    pd.DataFrame(nodes_info).sort_values("Type"),
                    use_container_width=True, hide_index=True,
                )

    # AE query via graph
    st.markdown("---")
    st.markdown("**Find subjects sharing an AE term:**")
    ae_domain = st.session_state["sdtm_data"].get("ae")
    pt_col = "AEDECOD" if ae_domain is not None and "AEDECOD" in ae_domain.columns else "AETERM"
    ae_terms = []
    if ae_domain is not None and pt_col in ae_domain.columns:
        ae_terms = sorted(ae_domain[pt_col].dropna().unique().tolist())

    if ae_terms:
        sel_ae = st.selectbox("AE Term", ae_terms, key="graph_ae_query")
        rel_filter = st.toggle("Drug-related only", value=False)
        if st.button("Find Subjects", key="btn_subj_ae"):
            result_subjs = analytics.query_subjects_with_ae(sel_ae, related_only=rel_filter)
            if result_subjs:
                st.success(f"{len(result_subjs)} subject(s) with {sel_ae}")
                st.write(result_subjs)
            else:
                st.info(f"No subjects found with '{sel_ae}'.")
