# =============================================================================
# pages/03_standard_tfls.py  -  CSR-quality standard tables
# =============================================================================

import streamlit as st
import pandas as pd
import numpy as np
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.data.session import init_session, get_population_df, get_trt_col
from src.utils.theme import apply_theme, get_colors
from src.analysis.descriptive import continuous_stats, categorical_stats
from src.analysis.safety import ae_summary_table, ae_incidence_table
from src.derivations.populations import identify_teae
from src.utils.helpers import format_n_pct, create_frequency_table

init_session()
apply_theme(st.session_state.get("dark_mode", True))
dark = st.session_state.get("dark_mode", True)
c = get_colors()

st.title("Standard Tables, Figures & Listings (TFLs)")

if not st.session_state.get("data_loaded"):
    st.warning("Load data first.")
    st.stop()

sdtm = st.session_state["sdtm_data"]
adsl = get_population_df()
trt_col = get_trt_col(adsl)

if adsl.empty:
    st.error("No subjects in selected population.")
    st.stop()

arms = sorted(adsl[trt_col].dropna().unique()) if trt_col else []
N_arms = adsl.groupby(trt_col)["USUBJID"].nunique().to_dict() if trt_col else {}
N_total = len(adsl)

pop_label = st.session_state.get("pop_selection", "All Subjects")

tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "Table 1: Demographics",
    "Table 2: AE Summary",
    "Table 3: Disposition",
    "Table 4: Exposure",
    "Listings",
])

# =========================================================
# Table 1: Demographics
# =========================================================
with tab1:
    st.caption(f"Population: {pop_label}  N = {N_total}")

    def _cont_row(label, series, group_series=None):
        rows = []
        arms_data = {}
        if trt_col and group_series is not None:
            for arm in arms:
                mask = group_series == arm
                arms_data[arm] = pd.to_numeric(series[mask], errors="coerce").dropna()
        total_data = pd.to_numeric(series, errors="coerce").dropna()

        def _stat_str(s):
            if len(s) == 0:
                return "0"
            return (
                f"N={len(s)}\n"
                f"Mean={s.mean():.1f}\n"
                f"SD={s.std():.1f}\n"
                f"Median={s.median():.1f}\n"
                f"Range=[{s.min():.1f}, {s.max():.1f}]"
            )

        row = {"Parameter": label, "Statistic": ""}
        stats_list = ["N", "Mean (SD)", "Median", "Range"]
        result_rows = []
        for stat in stats_list:
            r = {"Parameter": label if stat == "N" else "", "Statistic": stat}
            for arm in arms:
                s = arms_data.get(arm, pd.Series(dtype=float))
                n = len(s)
                if stat == "N":
                    r[arm] = str(n)
                elif stat == "Mean (SD)":
                    r[arm] = f"{s.mean():.1f} ({s.std():.1f})" if n > 1 else f"{s.mean():.1f}"
                elif stat == "Median":
                    r[arm] = f"{s.median():.1f}" if n > 0 else ""
                elif stat == "Range":
                    r[arm] = f"[{s.min():.1f}, {s.max():.1f}]" if n > 0 else ""
            s_t = total_data
            n_t = len(s_t)
            if stat == "N":
                r["Total"] = str(n_t)
            elif stat == "Mean (SD)":
                r["Total"] = f"{s_t.mean():.1f} ({s_t.std():.1f})" if n_t > 1 else ""
            elif stat == "Median":
                r["Total"] = f"{s_t.median():.1f}" if n_t > 0 else ""
            elif stat == "Range":
                r["Total"] = f"[{s_t.min():.1f}, {s_t.max():.1f}]" if n_t > 0 else ""
            result_rows.append(r)
        return result_rows

    def _cat_row(label, series, group_series=None):
        cats = sorted(series.dropna().unique())
        rows = []
        total_n = len(series.dropna())
        for cat in cats:
            r = {"Parameter": label if cat == cats[0] else "", "Statistic": str(cat)}
            for arm in arms:
                if trt_col and group_series is not None:
                    mask = group_series == arm
                    arm_s = series[mask]
                else:
                    arm_s = series
                n_arm = int((arm_s == cat).sum())
                N_arm = N_arms.get(arm, 1)
                r[arm] = format_n_pct(n_arm, N_arm)
            n_tot = int((series == cat).sum())
            r["Total"] = format_n_pct(n_tot, N_total)
            rows.append(r)
        return rows

    all_rows = []
    grp_series = adsl[trt_col] if trt_col and trt_col in adsl.columns else None

    # Age
    if "AGE" in adsl.columns:
        all_rows += _cont_row("Age (years)", adsl["AGE"], grp_series)
    # Sex
    if "SEX" in adsl.columns:
        all_rows += _cat_row("Sex", adsl["SEX"], grp_series)
    # Race
    if "RACE" in adsl.columns:
        all_rows += _cat_row("Race", adsl["RACE"], grp_series)
    # Ethnicity
    if "ETHNIC" in adsl.columns:
        all_rows += _cat_row("Ethnicity", adsl["ETHNIC"], grp_series)
    # Age groups
    if "AGEGR1" in adsl.columns:
        all_rows += _cat_row("Age Group", adsl["AGEGR1"], grp_series)
    # BMI
    if "BMI" in adsl.columns:
        all_rows += _cont_row("BMI (kg/m2)", adsl["BMI"], grp_series)

    if all_rows:
        df_t1 = pd.DataFrame(all_rows)
        st.dataframe(df_t1, use_container_width=True, hide_index=True, height=500)
        csv = df_t1.to_csv(index=False).encode("utf-8")
        st.download_button("Download Table 1 CSV", csv, "table1_demographics.csv")
    else:
        st.info("No demographic variables found in ADSL.")

# =========================================================
# Table 2: AE Summary
# =========================================================
with tab2:
    ae = sdtm.get("ae")
    if ae is None:
        st.info("AE domain not loaded.")
    else:
        ex = sdtm.get("ex")
        ae_teae = identify_teae(ae, ex)

        summ = ae_summary_table(ae_teae, adsl, trt_col)
        if not summ.empty:
            st.markdown(f"**{pop_label}  N = {N_total}**")
            st.dataframe(summ, use_container_width=True, hide_index=True)
            csv = summ.to_csv(index=False).encode("utf-8")
            st.download_button("Download AE Summary", csv, "table2_ae_summary.csv")

            st.markdown("---")
            st.markdown("#### AE Incidence by SOC/PT")
            inc = ae_incidence_table(ae_teae, adsl, trt_col, teae_only=True, min_pct=0.0)
            if not inc.empty:
                disp = [col for col in inc.columns if not col.startswith("_")]
                st.dataframe(inc[disp], use_container_width=True, hide_index=True, height=400)
                csv2 = inc[disp].to_csv(index=False).encode("utf-8")
                st.download_button("Download Incidence Table", csv2, "table2_ae_incidence.csv")

# =========================================================
# Table 3: Disposition
# =========================================================
with tab3:
    ds = sdtm.get("ds")
    if ds is None:
        st.info("DS domain not loaded.")
    else:
        pop_subjs = set(adsl["USUBJID"].dropna())
        ds2 = ds[ds["USUBJID"].isin(pop_subjs)].copy()
        if trt_col:
            ds2 = ds2.merge(adsl[["USUBJID", trt_col]].drop_duplicates(), on="USUBJID", how="left")

        disc_col = "DSDECOD" if "DSDECOD" in ds2.columns else "DSTERM"
        if disc_col in ds2.columns:
            rows_disp = []
            categories = sorted(ds2[disc_col].dropna().unique())
            for cat in categories:
                r = {"Disposition": str(cat)}
                for arm in arms:
                    if trt_col:
                        arm_ds = ds2[ds2[trt_col] == arm]
                    else:
                        arm_ds = ds2
                    n_arm = int(arm_ds[arm_ds[disc_col] == cat]["USUBJID"].nunique())
                    N_arm = N_arms.get(arm, 1)
                    r[arm] = format_n_pct(n_arm, N_arm)
                n_tot = int(ds2[ds2[disc_col] == cat]["USUBJID"].nunique())
                r["Total"] = format_n_pct(n_tot, N_total)
                rows_disp.append(r)
            if rows_disp:
                df_disp = pd.DataFrame(rows_disp)
                st.dataframe(df_disp, use_container_width=True, hide_index=True)
                csv = df_disp.to_csv(index=False).encode("utf-8")
                st.download_button("Download Disposition Table", csv, "table3_disposition.csv")
        else:
            st.info("DSDECOD/DSTERM not found in DS domain.")

# =========================================================
# Table 4: Exposure
# =========================================================
with tab4:
    ex = sdtm.get("ex")
    if ex is None:
        st.info("EX domain not loaded.")
    else:
        pop_subjs = set(adsl["USUBJID"].dropna())
        ex2 = ex[ex["USUBJID"].isin(pop_subjs)].copy()
        if trt_col:
            ex2 = ex2.merge(adsl[["USUBJID", trt_col, "TRTDURD"]].drop_duplicates(), on="USUBJID", how="left")

        rows_exp = []
        # Treatment duration
        if "TRTDURD" in adsl.columns:
            rows_exp += _cont_row("Treatment Duration (days)", adsl["TRTDURD"], grp_series)

        # Total dose
        if "EXDOSE" in ex2.columns:
            ex2["EXDOSE"] = pd.to_numeric(ex2["EXDOSE"], errors="coerce")
            total_dose = ex2.groupby("USUBJID")["EXDOSE"].sum().reset_index()
            total_dose.columns = ["USUBJID", "TOTAL_DOSE"]
            adsl_exp = adsl.merge(total_dose, on="USUBJID", how="left")
            rows_exp += _cont_row("Total Dose", adsl_exp["TOTAL_DOSE"], grp_series)

        if rows_exp:
            df_exp = pd.DataFrame(rows_exp)
            st.dataframe(df_exp, use_container_width=True, hide_index=True)
            csv = df_exp.to_csv(index=False).encode("utf-8")
            st.download_button("Download Exposure Table", csv, "table4_exposure.csv")
        else:
            st.info("Insufficient exposure data.")

# =========================================================
# Listings
# =========================================================
with tab5:
    st.markdown("### Data Listings")
    listing = st.selectbox("Select Listing", [
        "Listing: All AEs (sorted SOC / PT / Subject)",
        "Listing: SAEs",
        "Listing: Lab Values Outside Normal Range",
        "Listing: Disposition",
        "Listing: Exposure",
    ])

    ae = sdtm.get("ae")
    lb = sdtm.get("lb")
    ds = sdtm.get("ds")
    ex = sdtm.get("ex")
    pop_subjs = set(adsl["USUBJID"].dropna())

    if "AEs (sorted" in listing and ae is not None:
        ae_l = ae[ae["USUBJID"].isin(pop_subjs)].copy()
        pt_c = "AEDECOD" if "AEDECOD" in ae_l.columns else "AETERM"
        soc_c = "AEBODSYS" if "AEBODSYS" in ae_l.columns else None
        sort_cols = [c for c in [soc_c, pt_c, "USUBJID", "AESTDTC"] if c and c in ae_l.columns]
        ae_l = ae_l.sort_values(sort_cols)
        st.dataframe(ae_l, use_container_width=True, hide_index=True, height=500)
        st.download_button("Download", ae_l.to_csv(index=False).encode("utf-8"), "listing_ae.csv")

    elif "SAEs" in listing and ae is not None:
        ae_l = ae[ae["USUBJID"].isin(pop_subjs)].copy()
        if "AESER" in ae_l.columns:
            ae_l = ae_l[ae_l["AESER"].astype(str).str.upper().isin({"Y", "YES", "1"})]
        st.dataframe(ae_l, use_container_width=True, hide_index=True, height=500)
        st.download_button("Download", ae_l.to_csv(index=False).encode("utf-8"), "listing_sae.csv")

    elif "Lab Values" in listing and lb is not None:
        lb_l = lb[lb["USUBJID"].isin(pop_subjs)].copy()
        if "LBNRIND" in lb_l.columns:
            lb_l = lb_l[lb_l["LBNRIND"].astype(str).str.upper().isin({"LOW", "HIGH", "LOW LOW", "HIGH HIGH", "L", "H", "LL", "HH"})]
        st.dataframe(lb_l, use_container_width=True, hide_index=True, height=500)
        st.download_button("Download", lb_l.to_csv(index=False).encode("utf-8"), "listing_lab_abnormal.csv")

    elif "Disposition" in listing and ds is not None:
        ds_l = ds[ds["USUBJID"].isin(pop_subjs)].copy()
        st.dataframe(ds_l, use_container_width=True, hide_index=True, height=500)
        st.download_button("Download", ds_l.to_csv(index=False).encode("utf-8"), "listing_disposition.csv")

    elif "Exposure" in listing and ex is not None:
        ex_l = ex[ex["USUBJID"].isin(pop_subjs)].copy()
        st.dataframe(ex_l, use_container_width=True, hide_index=True, height=500)
        st.download_button("Download", ex_l.to_csv(index=False).encode("utf-8"), "listing_exposure.csv")
