# =============================================================================
# pages/08_efficacy.py  -  KM curves, waterfall, spider, forest plot
# =============================================================================

import streamlit as st
import pandas as pd
import numpy as np
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.data.session import init_session, get_population_df, get_trt_col
from src.utils.theme import apply_theme, get_colors
from src.analysis.descriptive import kaplan_meier, subgroup_stats
from src.analysis.plots import km_curve, waterfall_plot, spider_plot, forest_plot
from src.analysis.safety import derive_chg
from src.utils.helpers import pfs_from_rs_ds

init_session()
apply_theme(st.session_state.get("dark_mode", True))
dark = st.session_state.get("dark_mode", True)
c = get_colors()

st.title("Efficacy Analysis")

if not st.session_state.get("data_loaded"):
    st.warning("Load data first.")
    st.stop()

sdtm = st.session_state["sdtm_data"]
adsl = get_population_df()
trt_col = get_trt_col(adsl)

rs = sdtm.get("rs")
tr = sdtm.get("tr")
ds = sdtm.get("ds")
ex = sdtm.get("ex")
dm = sdtm.get("dm")

tab1, tab2, tab3, tab4 = st.tabs([
    "Kaplan-Meier",
    "Waterfall",
    "Spider Plot",
    "Subgroup Forest",
])

# =========================================================
# Tab 1: KM Curves
# =========================================================
with tab1:
    endpoint_opts = []
    if rs is not None:
        endpoint_opts.append("PFS (from RS/DS/EX)")
    if ds is not None:
        endpoint_opts.append("OS (from DS/EX)")
    if not endpoint_opts:
        st.info("RS or DS domain required for survival analysis.")
    else:
        endpoint = st.selectbox("Endpoint", endpoint_opts)
        col1, col2 = st.columns([2, 1])

        with col2:
            ci_show = st.toggle("Show 95% CI ribbon", value=True)
            tail_days = st.number_input("TEAE tail days", 0, 120, 30)

        with col1:
            if st.button("Run KM Analysis", type="primary"):
                with st.spinner("Computing KM ..."):
                    pfs_df = pfs_from_rs_ds(rs, ds, ex, dm)

                if pfs_df.empty:
                    st.error("Could not derive time-to-event data.")
                else:
                    if not adsl.empty and trt_col:
                        if "ARM" in pfs_df.columns and pfs_df["ARM"].isna().all():
                            adsl_arms = adsl[["USUBJID", trt_col]].drop_duplicates()
                            pfs_df = pfs_df.merge(adsl_arms, on="USUBJID", how="left")
                            pfs_df["ARM"] = pfs_df[trt_col]

                    km_res = kaplan_meier(
                        pfs_df["PFS_MONTHS"],
                        pfs_df["EVENT"],
                        group=pfs_df["ARM"] if "ARM" in pfs_df.columns else None,
                        label=endpoint.split("(")[0].strip(),
                    )
                    if km_res is None:
                        st.error("lifelines not installed. Run: pip install lifelines")
                    else:
                        if not ci_show:
                            for k in km_res:
                                if not k.startswith("_"):
                                    km_res[k]["ci"] = None

                        fig_km = km_curve(
                            km_res,
                            title=endpoint,
                            y_label="Probability",
                            x_label="Time (months)",
                            dark=dark,
                        )
                        if fig_km:
                            st.plotly_chart(fig_km, use_container_width=True)

                        # Summary table
                        rows = []
                        for grp, res in km_res.items():
                            if grp.startswith("_"):
                                continue
                            rows.append({
                                "Group": grp,
                                "Median (months)": f"{res['median']:.1f}",
                                "Events": int(pfs_df[pfs_df.get("ARM", pfs_df.get(trt_col, pd.Series())) == grp]["EVENT"].sum()) if "ARM" in pfs_df.columns else "",
                                "N": int(pfs_df[pfs_df.get("ARM", pd.Series()) == grp].shape[0]) if "ARM" in pfs_df.columns else "",
                            })
                        if rows:
                            st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

                        p = km_res.get("_logrank_p")
                        if p is not None:
                            st.markdown(
                                f"**Log-rank test p-value: "
                                f"<span style='color:{c['accent']}'>{p:.4f}</span>**",
                                unsafe_allow_html=True,
                            )

# =========================================================
# Tab 2: Waterfall
# =========================================================
with tab2:
    if tr is None or tr.empty:
        st.info("TR domain required for waterfall plot.")
    elif "TRORRES" not in tr.columns or "TRDTC" not in tr.columns:
        st.info("TR domain needs TRORRES and TRDTC columns.")
    else:
        st.markdown("Best percent change from baseline in sum of target lesion diameters.")
        tr2 = tr.copy()
        if not adsl.empty:
            tr2 = tr2[tr2["USUBJID"].isin(adsl["USUBJID"].tolist())]
            tr2 = tr2.merge(adsl[["USUBJID", trt_col]].drop_duplicates(), on="USUBJID", how="left")

        tr2["TRDTC"] = pd.to_datetime(tr2["TRDTC"], errors="coerce")
        tr2["TRORRES"] = pd.to_numeric(tr2["TRORRES"], errors="coerce")
        tr2 = tr2.dropna(subset=["TRORRES", "TRDTC"])

        sum_by_date = (
            tr2.groupby(["USUBJID", "TRDTC"])["TRORRES"].sum().reset_index()
        )
        if not adsl.empty and trt_col:
            sum_by_date = sum_by_date.merge(
                adsl[["USUBJID", trt_col]].drop_duplicates(), on="USUBJID", how="left"
            )

        # Baseline = first date per subject
        baseline = (
            sum_by_date.sort_values("TRDTC")
            .groupby("USUBJID")
            .first()
            .reset_index()[["USUBJID", "TRORRES"]]
            .rename(columns={"TRORRES": "BL_SUM"})
        )
        # Best response = best PCHG
        best = sum_by_date.merge(baseline, on="USUBJID", how="left")
        best["PCHG"] = (best["TRORRES"] - best["BL_SUM"]) / best["BL_SUM"] * 100
        best = best.dropna(subset=["PCHG"])
        best_resp = (
            best.sort_values("PCHG")
            .groupby("USUBJID")
            .first()
            .reset_index()[["USUBJID", "PCHG", trt_col]]
        )

        if not best_resp.empty:
            fig_wf = waterfall_plot(
                best_resp, "USUBJID", "PCHG",
                group_col=trt_col if trt_col else None,
                title="Waterfall: Best % Change in Tumor Sum of Diameters",
                dark=dark,
            )
            if fig_wf:
                st.plotly_chart(fig_wf, use_container_width=True)

            n_pr = int((best_resp["PCHG"] <= -30).sum())
            n_sd = int(((best_resp["PCHG"] > -30) & (best_resp["PCHG"] < 20)).sum())
            n_pd = int((best_resp["PCHG"] >= 20).sum())
            k1, k2, k3 = st.columns(3)
            k1.metric("PR (<=30%)", n_pr)
            k2.metric("SD", n_sd)
            k3.metric("PD (>=20%)", n_pd)

            st.dataframe(best_resp.sort_values("PCHG"), use_container_width=True, hide_index=True)
        else:
            st.info("No usable TR data after derivation.")

# =========================================================
# Tab 3: Spider Plot
# =========================================================
with tab3:
    if tr is None or tr.empty:
        st.info("TR domain required for spider plot.")
    else:
        tr3 = tr.copy()
        if not adsl.empty:
            tr3 = tr3[tr3["USUBJID"].isin(adsl["USUBJID"].tolist())]
            tr3 = tr3.merge(adsl[["USUBJID", trt_col]].drop_duplicates(), on="USUBJID", how="left")

        tr3["TRDTC"] = pd.to_datetime(tr3["TRDTC"], errors="coerce")
        tr3["TRORRES"] = pd.to_numeric(tr3["TRORRES"], errors="coerce")
        tr3 = tr3.dropna(subset=["TRORRES", "TRDTC"])

        sum3 = tr3.groupby(["USUBJID", "TRDTC"])["TRORRES"].sum().reset_index()
        if not adsl.empty and trt_col:
            sum3 = sum3.merge(adsl[["USUBJID", trt_col]].drop_duplicates(), on="USUBJID", how="left")

        baseline3 = (
            sum3.sort_values("TRDTC").groupby("USUBJID").first()
            .reset_index()[["USUBJID", "TRORRES"]].rename(columns={"TRORRES": "BL"})
        )
        sum3 = sum3.merge(baseline3, on="USUBJID", how="left")
        sum3["PCHG"] = (sum3["TRORRES"] - sum3["BL"]) / sum3["BL"] * 100

        max_subj = st.slider("Max subjects on spider plot", 10, 200, 50, 10)
        subjs_sp = sum3["USUBJID"].dropna().unique()[:max_subj]
        sum3_sp = sum3[sum3["USUBJID"].isin(subjs_sp)]

        fig_sp = spider_plot(
            sum3_sp, "USUBJID", "TRDTC", "PCHG",
            group_col=trt_col if trt_col else None,
            title="Spider Plot: Tumor Burden % Change from Baseline",
            dark=dark,
        )
        if fig_sp:
            st.plotly_chart(fig_sp, use_container_width=True)
        else:
            st.info("Could not render spider plot.")

# =========================================================
# Tab 4: Subgroup Forest Plot
# =========================================================
with tab4:
    st.markdown("Forest plot of treatment effect across subgroups.")
    if adsl.empty or not trt_col:
        st.info("ADSL with treatment column required.")
    else:
        endpoint_type = st.radio(
            "Endpoint type", ["Binary (any AE)", "Continuous (lab/VS)"], horizontal=True
        )

        if endpoint_type == "Binary (any AE)":
            ae_dom = sdtm.get("ae")
            if ae_dom is None:
                st.info("AE domain required.")
            else:
                has_ae = adsl["USUBJID"].isin(ae_dom["USUBJID"].dropna().unique())
                has_ae_idx = has_ae.reindex(adsl.index, fill_value=False)
                if st.button("Run Subgroup Analysis", type="primary"):
                    with st.spinner("Computing subgroup effects ..."):
                        sg = subgroup_stats(adsl, has_ae_idx, trt_col, endpoint_type="binary")
                    if not sg.empty:
                        st.dataframe(sg, use_container_width=True, hide_index=True)
                        fig_fp = forest_plot(
                            sg, "Subgroup", "Effect", "Lower", "Upper",
                            n_col="N",
                            title="Risk Difference: Any AE by Subgroup",
                            dark=dark,
                        )
                        if fig_fp:
                            st.plotly_chart(fig_fp, use_container_width=True)
                    else:
                        st.info("Subgroup analysis returned no results.")

        else:
            lb_dom = sdtm.get("lb")
            vs_dom = sdtm.get("vs")
            available_domains = {}
            if lb_dom is not None and "LBTESTCD" in lb_dom.columns:
                for t in lb_dom["LBTESTCD"].dropna().unique()[:20]:
                    available_domains[f"LB: {t}"] = ("lb", t)
            if vs_dom is not None and "VSTESTCD" in vs_dom.columns:
                for t in vs_dom["VSTESTCD"].dropna().unique()[:10]:
                    available_domains[f"VS: {t}"] = ("vs", t)

            if not available_domains:
                st.info("No lab/VS parameters found.")
            else:
                param_sel = st.selectbox("Parameter", list(available_domains.keys()))
                dom_key, testcd = available_domains[param_sel]
                dom_df = sdtm.get(dom_key)
                testcd_col = "LBTESTCD" if dom_key == "lb" else "VSTESTCD"
                val_col = "LBSTRESN" if dom_key == "lb" else "VSSTRESN"

                if st.button("Run Subgroup Analysis", type="primary", key="sg_cont"):
                    with st.spinner("Computing ..."):
                        param_data = dom_df[dom_df[testcd_col] == testcd]
                        mean_per_subj = (
                            param_data.groupby("USUBJID")[val_col]
                            .apply(lambda s: pd.to_numeric(s, errors="coerce").mean())
                        )
                        endpoint_s = mean_per_subj.reindex(adsl["USUBJID"].values)
                        endpoint_s.index = adsl.index
                        sg = subgroup_stats(adsl, endpoint_s, trt_col, endpoint_type="continuous")
                    if not sg.empty:
                        st.dataframe(sg, use_container_width=True, hide_index=True)
                        fig_fp = forest_plot(
                            sg, "Subgroup", "Effect", "Lower", "Upper",
                            n_col="N",
                            title=f"Mean Difference: {param_sel} by Subgroup",
                            dark=dark,
                        )
                        if fig_fp:
                            st.plotly_chart(fig_fp, use_container_width=True)
                    else:
                        st.info("No results.")
