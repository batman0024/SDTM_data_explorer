# =============================================================================
# pages/01_data_overview.py  -  Domain inspection + quality checks
# =============================================================================

import streamlit as st
import pandas as pd
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.data.session import init_session, get_population_df
from src.utils.theme import apply_theme, get_colors
from src.utils.helpers import get_domain_label, detect_variable_type, create_frequency_table
from src.analysis.descriptive import continuous_stats
from src.analysis.plots import bar_chart

init_session()
apply_theme(st.session_state.get("dark_mode", True))
dark = st.session_state.get("dark_mode", True)
c = get_colors()

st.title("SDTM Data Overview")

if not st.session_state.get("data_loaded"):
    st.warning("Load data from the Home page first.")
    st.stop()

sdtm = st.session_state["sdtm_data"]
domains = sorted(sdtm.keys())

domain = st.selectbox(
    "Select Domain",
    domains,
    format_func=lambda x: f"{x.upper()} - {get_domain_label(x)}",
)
df = sdtm[domain]

# ---- KPIs ----
k1, k2, k3, k4 = st.columns(4)
n_subj = int(df["USUBJID"].nunique()) if "USUBJID" in df.columns else "-"
total_cells = len(df) * len(df.columns) or 1
miss_pct = df.isna().sum().sum() / total_cells * 100

k1.metric("Records", f"{len(df):,}")
k2.metric("Subjects", f"{n_subj:,}" if isinstance(n_subj, int) else n_subj)
k3.metric("Variables", len(df.columns))
k4.metric("Missing %", f"{miss_pct:.1f}%")

st.markdown("---")
tab1, tab2, tab3, tab4 = st.tabs(["Preview", "Distribution", "Quality", "CDISC Checks"])

# ---- Tab 1: Preview ----
with tab1:
    n_rows = st.number_input("Rows to display", 10, 5000, 100, step=50)
    st.dataframe(df.head(n_rows), use_container_width=True, height=420)
    csv = df.to_csv(index=False).encode("utf-8")
    st.download_button("Download CSV", csv, f"{domain}.csv", "text/csv")

# ---- Tab 2: Distribution ----
with tab2:
    col = st.selectbox("Variable", df.columns.tolist(), key="dist_col")
    vtype = detect_variable_type(df[col])
    st.caption(f"Detected type: **{vtype}**")

    col_a, col_b = st.columns([2, 1])
    with col_b:
        if vtype == "continuous":
            stats = continuous_stats(df[col])
            st.dataframe(stats.T.rename(columns={0: "Value"}),
                         use_container_width=True)
        else:
            ft = create_frequency_table(df[col])
            st.dataframe(ft, use_container_width=True, hide_index=True)

    with col_a:
        if vtype == "continuous":
            import plotly.graph_objects as go
            fig_h = go.Figure(go.Histogram(
                x=pd.to_numeric(df[col], errors="coerce"),
                nbinsx=30,
                marker_color=c["accent"],
            ))
            fig_h.update_layout(
                title=f"{col} Distribution",
                paper_bgcolor=c["card"],
                plot_bgcolor=c["bg"],
                font=dict(color=c["text"]),
                margin=dict(l=40, r=20, t=40, b=40),
            )
            st.plotly_chart(fig_h, use_container_width=True)
        else:
            vc = df[col].value_counts().head(20).reset_index()
            vc.columns = ["Category", "Count"]
            fig_b = bar_chart(vc, "Category", "Count", title=f"{col} Frequency", dark=dark)
            if fig_b:
                st.plotly_chart(fig_b, use_container_width=True)

# ---- Tab 3: Missing Data Quality ----
with tab3:
    miss = df.isna().sum().reset_index()
    miss.columns = ["Variable", "Missing_N"]
    miss["Missing_Pct"] = (miss["Missing_N"] / len(df) * 100).round(1)
    miss = miss[miss["Missing_N"] > 0].sort_values("Missing_Pct", ascending=False)

    if miss.empty:
        st.success("No missing values detected in this domain.")
    else:
        st.dataframe(miss, use_container_width=True, hide_index=True)
        fig_miss = bar_chart(
            miss.head(20), "Variable", "Missing_Pct",
            title="Missing % per Variable", dark=dark, orientation="h"
        )
        if fig_miss:
            st.plotly_chart(fig_miss, use_container_width=True)

    st.markdown("**Unique values per variable:**")
    uniq = pd.DataFrame({
        "Variable": df.columns,
        "Unique_Values": [df[c].nunique() for c in df.columns],
        "Example": [str(df[c].dropna().iloc[0]) if df[c].notna().any() else "" for c in df.columns],
    })
    st.dataframe(uniq, use_container_width=True, hide_index=True)

# ---- Tab 4: CDISC Conformance Checks ----
with tab4:
    dom_upper = domain.upper()
    checks = []

    # 1. USUBJID present
    if "USUBJID" in df.columns:
        checks.append({"Rule": "USUBJID present", "Status": "PASS", "Detail": f"{df['USUBJID'].nunique()} unique subjects"})
    else:
        checks.append({"Rule": "USUBJID present", "Status": "FAIL", "Detail": "USUBJID column missing"})

    # 2. DOMAIN column value consistent
    if "DOMAIN" in df.columns:
        dom_vals = df["DOMAIN"].dropna().unique()
        if len(dom_vals) == 1 and dom_vals[0].upper() == dom_upper:
            checks.append({"Rule": "DOMAIN value consistent", "Status": "PASS", "Detail": f"DOMAIN = {dom_vals[0]}"})
        else:
            checks.append({"Rule": "DOMAIN value consistent", "Status": "WARN", "Detail": f"Values: {dom_vals}"})
    else:
        checks.append({"Rule": "DOMAIN column present", "Status": "WARN", "Detail": "DOMAIN column not found"})

    # 3. Date format (ISO 8601)
    dtc_cols = [c for c in df.columns if c.upper().endswith("DTC")]
    for dtc in dtc_cols:
        sample = df[dtc].dropna().astype(str).head(10)
        bad = sample[~sample.str.match(r"\d{4}(-\d{2}(-\d{2})?)?$", na=False)]
        if bad.empty:
            checks.append({"Rule": f"{dtc} ISO 8601 format", "Status": "PASS", "Detail": "All values match yyyy(-mm(-dd))"})
        else:
            checks.append({"Rule": f"{dtc} ISO 8601 format", "Status": "WARN", "Detail": f"Non-conformant: {bad.head(3).tolist()}"})

    # 4. Sequence variable uniqueness
    seq_col = f"{dom_upper}SEQ"
    if seq_col in df.columns:
        dups = df.duplicated(subset=["USUBJID", seq_col]) if "USUBJID" in df.columns else df.duplicated(subset=[seq_col])
        n_dups = dups.sum()
        if n_dups == 0:
            checks.append({"Rule": f"{seq_col} unique", "Status": "PASS", "Detail": "No duplicates"})
        else:
            checks.append({"Rule": f"{seq_col} unique", "Status": "FAIL", "Detail": f"{n_dups} duplicate SEQ values"})

    # 5. Controlled terminology for common flags
    for col, allowed in [("AESER", {"Y", "N"}), ("AEREL", None), ("LBNRIND", {"LOW", "NORMAL", "HIGH", "LOW LOW", "HIGH HIGH"})]:
        if col in df.columns:
            vals = set(df[col].dropna().astype(str).str.upper().unique())
            if allowed and not vals.issubset(allowed):
                outside = vals - allowed
                checks.append({"Rule": f"{col} controlled terminology", "Status": "WARN", "Detail": f"Non-standard values: {outside}"})
            else:
                checks.append({"Rule": f"{col} controlled terminology", "Status": "PASS", "Detail": f"Values: {vals}"})

    checks_df = pd.DataFrame(checks)

    def _color_status(v):
        if v == "PASS":
            return f"color: {c['success']}"
        if v == "FAIL":
            return f"color: {c['danger']}"
        return f"color: {c['warning']}"

    styled = checks_df.style.applymap(_color_status, subset=["Status"])
    st.dataframe(styled, use_container_width=True, hide_index=True)

    pass_n = (checks_df["Status"] == "PASS").sum()
    fail_n = (checks_df["Status"] == "FAIL").sum()
    warn_n = (checks_df["Status"] == "WARN").sum()
    st.markdown(
        f"**Score:** "
        f"<span style='color:{c['success']}'>{pass_n} Pass</span> | "
        f"<span style='color:{c['warning']}'>{warn_n} Warn</span> | "
        f"<span style='color:{c['danger']}'>{fail_n} Fail</span>",
        unsafe_allow_html=True,
    )
