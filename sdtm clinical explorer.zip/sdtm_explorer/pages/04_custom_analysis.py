# =============================================================================
# pages/04_custom_analysis.py  -  Ad-hoc cross-domain analysis builder
# =============================================================================

import streamlit as st
import pandas as pd
import numpy as np
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.data.session import init_session, get_population_df, get_trt_col
from src.utils.theme import apply_theme, get_colors
from src.utils.helpers import detect_variable_type, create_frequency_table
from src.analysis.descriptive import (
    continuous_stats,
    categorical_stats,
    mean_ci_by_visit,
)
from src.analysis.plots import (
    bar_chart,
    line_trend,
    box_plot,
    spaghetti_plot,
)

init_session()
apply_theme(st.session_state.get("dark_mode", True))
dark = st.session_state.get("dark_mode", True)
c = get_colors()

st.title("Custom Analysis Builder")
st.caption(
    "Build ad-hoc analyses across any loaded SDTM domain. "
    "Summarise variables, compare across treatment arms, and explore trends over time."
)

if not st.session_state.get("data_loaded"):
    st.warning("Load data from the Home page first.")
    st.stop()

sdtm = st.session_state["sdtm_data"]
adsl = get_population_df()
trt_col = get_trt_col(adsl)

# ---- Analysis type selector ----
analysis_type = st.radio(
    "Analysis type",
    ["Summary Statistics", "Frequency Table", "Trend Over Time", "Cross-Tabulation", "Scatter / Correlation"],
    horizontal=True,
)

st.markdown("---")

# =========================================================
# 1. Summary Statistics
# =========================================================
if analysis_type == "Summary Statistics":
    col1, col2 = st.columns([1, 2])
    with col1:
        domain = st.selectbox("Domain", sorted(sdtm.keys()), format_func=str.upper, key="ss_dom")
        df = sdtm[domain]
        num_cols = [c2 for c2 in df.columns if detect_variable_type(df[c2]) == "continuous"]
        if not num_cols:
            st.info("No continuous variables detected in this domain.")
            st.stop()
        var = st.selectbox("Variable", num_cols, key="ss_var")
        by_trt = st.toggle("Stratify by Treatment", value=bool(trt_col), key="ss_by")
        filter_pop = st.toggle("Restrict to analysis population", value=True, key="ss_pop")

    with col2:
        df2 = df.copy()
        if filter_pop and not adsl.empty:
            df2 = df2[df2["USUBJID"].isin(adsl["USUBJID"].tolist())] if "USUBJID" in df2.columns else df2
        if by_trt and trt_col and not adsl.empty:
            df2 = df2.merge(adsl[["USUBJID", trt_col]].drop_duplicates(), on="USUBJID", how="left")

        group = df2[trt_col] if by_trt and trt_col and trt_col in df2.columns else None
        result = continuous_stats(df2[var], group=group)
        st.dataframe(result, use_container_width=True, hide_index=True)
        st.download_button(
            "Download CSV",
            result.to_csv(index=False).encode("utf-8"),
            f"summary_{domain}_{var}.csv",
        )

        # Histogram
        import plotly.graph_objects as go
        series = pd.to_numeric(df2[var], errors="coerce").dropna()
        fig_h = go.Figure(go.Histogram(
            x=series, nbinsx=30, marker_color=c["accent"],
        ))
        fig_h.update_layout(
            title=f"{var} - Distribution",
            paper_bgcolor=c["card"], plot_bgcolor=c["bg"],
            font=dict(color=c["text"]),
            xaxis_title=var, yaxis_title="Count",
            margin=dict(l=50, r=20, t=50, b=40),
        )
        st.plotly_chart(fig_h, use_container_width=True)

        # Box by group
        if group is not None:
            fig_b = box_plot(df2, y_col=var, x_col=trt_col, group_col=trt_col,
                             title=f"{var} by Treatment", dark=dark)
            if fig_b:
                st.plotly_chart(fig_b, use_container_width=True)

# =========================================================
# 2. Frequency Table
# =========================================================
elif analysis_type == "Frequency Table":
    col1, col2 = st.columns([1, 2])
    with col1:
        domain = st.selectbox("Domain", sorted(sdtm.keys()), format_func=str.upper, key="ft_dom")
        df = sdtm[domain]
        cat_cols = [c2 for c2 in df.columns if detect_variable_type(df[c2]) == "categorical"]
        if not cat_cols:
            cat_cols = df.columns.tolist()
        var = st.selectbox("Variable", cat_cols, key="ft_var")
        by_trt = st.toggle("Stratify by Treatment", value=bool(trt_col), key="ft_by")
        filter_pop = st.toggle("Restrict to analysis population", value=True, key="ft_pop")

    with col2:
        df2 = df.copy()
        if filter_pop and not adsl.empty and "USUBJID" in df2.columns:
            df2 = df2[df2["USUBJID"].isin(adsl["USUBJID"].tolist())]
        if by_trt and trt_col and not adsl.empty and "USUBJID" in df2.columns:
            df2 = df2.merge(adsl[["USUBJID", trt_col]].drop_duplicates(), on="USUBJID", how="left")

        group = df2[trt_col] if by_trt and trt_col and trt_col in df2.columns else None
        result = categorical_stats(df2[var], group=group)
        st.dataframe(result, use_container_width=True, hide_index=True)
        st.download_button(
            "Download CSV",
            result.to_csv(index=False).encode("utf-8"),
            f"freqtable_{domain}_{var}.csv",
        )

        # Bar chart
        if group is None:
            ft = create_frequency_table(df2[var])
            ft_sorted = ft.nlargest(20, "N")
            fig_b = bar_chart(ft_sorted, "Category", "N",
                              title=f"{var} Frequency", dark=dark)
            if fig_b:
                st.plotly_chart(fig_b, use_container_width=True)
        else:
            pivot = result.pivot_table(index="Category", columns="Group", values="n", aggfunc="sum", fill_value=0)
            pivot = pivot.reset_index()
            fig_b = bar_chart(
                pivot.melt(id_vars="Category", var_name=trt_col, value_name="n"),
                "Category", "n", group_col=trt_col,
                title=f"{var} by Treatment",
                dark=dark,
            )
            if fig_b:
                st.plotly_chart(fig_b, use_container_width=True)

# =========================================================
# 3. Trend Over Time
# =========================================================
elif analysis_type == "Trend Over Time":
    col1, col2, col3 = st.columns(3)
    with col1:
        domain = st.selectbox("Domain", sorted(sdtm.keys()), format_func=str.upper, key="tr_dom")
        df = sdtm[domain]
    with col2:
        num_cols = [c2 for c2 in df.columns if detect_variable_type(df[c2]) == "continuous"]
        var = st.selectbox("Value variable", num_cols, key="tr_var") if num_cols else None
    with col3:
        # Detect time/visit columns
        time_candidates = [c2 for c2 in df.columns if
                           any(k in c2.upper() for k in ["VISIT", "DTC", "DAY", "DY", "TIME"])]
        time_col = st.selectbox("Time / Visit column", time_candidates, key="tr_time") if time_candidates else None

    if var and time_col:
        df2 = df.copy()
        df2[var] = pd.to_numeric(df2[var], errors="coerce")
        if not adsl.empty and "USUBJID" in df2.columns:
            df2 = df2[df2["USUBJID"].isin(adsl["USUBJID"].tolist())]
        if trt_col and not adsl.empty and "USUBJID" in df2.columns:
            df2 = df2.merge(adsl[["USUBJID", trt_col]].drop_duplicates(), on="USUBJID", how="left")

        chart_type = st.radio("Chart", ["Mean +- CI", "Spaghetti", "Box per Visit"], horizontal=True)

        if chart_type == "Mean +- CI":
            summ = mean_ci_by_visit(df2, var, time_col,
                                    group_col=trt_col if trt_col and trt_col in df2.columns else None)
            if not summ.empty:
                fig = line_trend(
                    summ, time_col, "Mean",
                    group_col=trt_col if trt_col and trt_col in df2.columns else None,
                    lower_col="Lower_CI", upper_col="Upper_CI",
                    title=f"{var} Mean over {time_col}",
                    y_label=var, dark=dark,
                )
                if fig:
                    st.plotly_chart(fig, use_container_width=True)
                st.dataframe(summ, use_container_width=True, hide_index=True)
            else:
                st.info("Insufficient data.")

        elif chart_type == "Spaghetti":
            if "USUBJID" in df2.columns:
                fig = spaghetti_plot(
                    df2, time_col, var,
                    group_col=trt_col if trt_col and trt_col in df2.columns else None,
                    title=f"{var} individual trajectories over {time_col}",
                    dark=dark,
                )
                if fig:
                    st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("USUBJID required for spaghetti plot.")

        elif chart_type == "Box per Visit":
            fig = box_plot(df2, y_col=var, x_col=time_col,
                           group_col=trt_col if trt_col and trt_col in df2.columns else None,
                           title=f"{var} distribution per {time_col}", dark=dark)
            if fig:
                st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("Select a domain with numeric values and a time/visit column.")

# =========================================================
# 4. Cross-Tabulation
# =========================================================
elif analysis_type == "Cross-Tabulation":
    st.markdown("Cross-tabulate two categorical variables from any domain.")
    col1, col2, col3 = st.columns(3)
    with col1:
        domain = st.selectbox("Domain", sorted(sdtm.keys()), format_func=str.upper, key="ct_dom")
        df = sdtm[domain]
    with col2:
        row_var = st.selectbox("Row variable", df.columns.tolist(), key="ct_row")
    with col3:
        col_var = st.selectbox("Column variable",
                               [c2 for c2 in df.columns.tolist() if c2 != row_var],
                               key="ct_col")

    if row_var and col_var:
        df2 = df.copy()
        if not adsl.empty and "USUBJID" in df2.columns:
            df2 = df2[df2["USUBJID"].isin(adsl["USUBJID"].tolist())]

        ct = pd.crosstab(
            df2[row_var].astype(str).str[:30],
            df2[col_var].astype(str).str[:30],
            margins=True,
        )
        st.dataframe(ct, use_container_width=True)
        st.download_button(
            "Download CSV",
            ct.to_csv().encode("utf-8"),
            f"crosstab_{row_var}_{col_var}.csv",
        )

        # Chi-square test
        if st.toggle("Run Chi-square test", key="ct_chi"):
            try:
                from scipy.stats import chi2_contingency
                ct_no_margin = pd.crosstab(df2[row_var], df2[col_var])
                chi2, p, dof, expected = chi2_contingency(ct_no_margin)
                st.markdown(
                    f"Chi-square = **{chi2:.3f}**, df = {dof}, "
                    f"p-value = **{p:.4f}**"
                )
            except ImportError:
                st.warning("scipy required for chi-square: pip install scipy")
            except Exception as e:
                st.warning(f"Chi-square failed: {e}")

# =========================================================
# 5. Scatter / Correlation
# =========================================================
elif analysis_type == "Scatter / Correlation":
    st.markdown("Explore correlation between two numeric variables (from the same or merged domains).")

    col1, col2 = st.columns(2)
    with col1:
        dom_x = st.selectbox("X domain", sorted(sdtm.keys()), format_func=str.upper, key="sc_domx")
        df_x = sdtm[dom_x]
        num_x = [c2 for c2 in df_x.columns if detect_variable_type(df_x[c2]) == "continuous"]
        var_x = st.selectbox("X variable", num_x, key="sc_x") if num_x else None
    with col2:
        dom_y = st.selectbox("Y domain", sorted(sdtm.keys()), format_func=str.upper, key="sc_domy")
        df_y = sdtm[dom_y]
        num_y = [c2 for c2 in df_y.columns if detect_variable_type(df_y[c2]) == "continuous"]
        var_y = st.selectbox("Y variable", num_y, key="sc_y") if num_y else None

    if var_x and var_y:
        # Aggregate to subject-level for cross-domain correlation
        def _subj_mean(df, var):
            df2 = df.copy()
            df2[var] = pd.to_numeric(df2[var], errors="coerce")
            if not adsl.empty and "USUBJID" in df2.columns:
                df2 = df2[df2["USUBJID"].isin(adsl["USUBJID"].tolist())]
            if "USUBJID" in df2.columns:
                return df2.groupby("USUBJID")[var].mean().reset_index().rename(columns={var: var})
            return df2[[var]].assign(USUBJID="unknown")

        sx = _subj_mean(df_x, var_x)
        sy = _subj_mean(df_y, var_y)

        if "USUBJID" in sx.columns and "USUBJID" in sy.columns:
            merged = sx.merge(sy, on="USUBJID", how="inner")
        else:
            merged = pd.concat([sx.rename(columns={var_x: var_x}),
                                 sy.rename(columns={var_y: var_y})], axis=1)

        if merged.empty:
            st.info("No common subjects between selected domains.")
        else:
            if trt_col and not adsl.empty and "USUBJID" in merged.columns:
                merged = merged.merge(
                    adsl[["USUBJID", trt_col]].drop_duplicates(), on="USUBJID", how="left"
                )

            import plotly.express as px
            fig_sc = px.scatter(
                merged, x=var_x, y=var_y,
                color=trt_col if trt_col and trt_col in merged.columns else None,
                hover_data=["USUBJID"] if "USUBJID" in merged.columns else None,
                trendline="ols" if st.toggle("Add trend line (OLS)", value=True) else None,
                title=f"{var_x} vs {var_y}",
                color_discrete_sequence=[c["accent"], c["accent2"],
                                         c["success"], c["warning"]],
                template="plotly_dark" if dark else "plotly_white",
            )
            fig_sc.update_layout(
                paper_bgcolor=c["card"], plot_bgcolor=c["bg"],
                font=dict(color=c["text"]),
            )
            st.plotly_chart(fig_sc, use_container_width=True)

            # Pearson correlation
            x_s = pd.to_numeric(merged[var_x], errors="coerce")
            y_s = pd.to_numeric(merged[var_y], errors="coerce")
            mask = x_s.notna() & y_s.notna()
            if mask.sum() > 2:
                r = x_s[mask].corr(y_s[mask])
                n_corr = mask.sum()
                st.metric(f"Pearson r (N={n_corr})", f"{r:.4f}")
                try:
                    from scipy.stats import pearsonr
                    _, p_corr = pearsonr(x_s[mask], y_s[mask])
                    st.caption(f"p-value = {p_corr:.4f}")
                except ImportError:
                    pass
