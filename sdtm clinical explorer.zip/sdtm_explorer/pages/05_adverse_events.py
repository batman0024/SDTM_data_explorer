# =============================================================================
# pages/05_adverse_events.py  -  ICH-compliant AE safety analysis
# =============================================================================

import streamlit as st
import pandas as pd
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.data.session import init_session, get_population_df, get_trt_col
from src.utils.theme import apply_theme, get_colors
from src.analysis.safety import (
    ae_incidence_table,
    ae_summary_table,
    build_shift_table,
    normalize_grade,
    is_causally_related,
    is_serious,
)
from src.derivations.populations import identify_teae
from src.analysis.plots import (
    incidence_bar,
    ae_timeline,
    swimmer_plot,
    bar_chart,
)
from src.utils.helpers import format_n_pct

init_session()
apply_theme(st.session_state.get("dark_mode", True))
dark = st.session_state.get("dark_mode", True)
c = get_colors()

st.title("Adverse Events Analysis")

if not st.session_state.get("data_loaded"):
    st.warning("Load data from the Home page first.")
    st.stop()

sdtm = st.session_state["sdtm_data"]
ae_raw = sdtm.get("ae")
ex = sdtm.get("ex")

if ae_raw is None or ae_raw.empty:
    st.error("AE domain not available.")
    st.stop()

adsl = get_population_df()
if adsl.empty:
    st.error("No subjects in selected population.")
    st.stop()

trt_col = get_trt_col(adsl)

# ---- TEAE identification ----
ae = identify_teae(ae_raw, ex, tail_days=30)

# ---- Global filter controls ----
with st.expander("Analysis Controls", expanded=True):
    c1, c2, c3 = st.columns(3)
    with c1:
        teae_only = st.toggle("TEAE only", value=True,
                              help="Filter to Treatment-Emergent AEs (AEs starting on/after first dose)")
    with c2:
        min_pct = st.slider("Minimum incidence %", 0.0, 20.0, 0.0, 0.5)
    with c3:
        grade_min = st.selectbox("Minimum grade", [0, 1, 2, 3, 4], index=0,
                                 format_func=lambda x: f"Grade {x}+" if x > 0 else "All grades")

# ---- KPI ribbon ----
pop_n = len(adsl)
ae_pop = ae[ae["USUBJID"].isin(adsl["USUBJID"].tolist())]
if teae_only and "TEAE" in ae_pop.columns:
    ae_filt = ae_pop[ae_pop["TEAE"].astype(bool)]
else:
    ae_filt = ae_pop

n_subj_ae = ae_filt["USUBJID"].nunique()
n_sae = int(ae_filt[is_serious(ae_filt["AESER"])]["USUBJID"].nunique()) if "AESER" in ae_filt.columns else 0
grade_col_name = "AETOXGR" if "AETOXGR" in ae_filt.columns else ("AESEV" if "AESEV" in ae_filt.columns else None)
n_g3 = 0
if grade_col_name:
    n_g3 = int(ae_filt[normalize_grade(ae_filt[grade_col_name]).ge(3)]["USUBJID"].nunique())
n_rel = 0
for rel_col in ["AEREL", "AERELNS"]:
    if rel_col in ae_filt.columns:
        n_rel = int(ae_filt[is_causally_related(ae_filt[rel_col])]["USUBJID"].nunique())
        break

col1, col2, col3, col4, col5 = st.columns(5)
col1.metric("Population N", pop_n)
col2.metric("Subjects w/ AE", format_n_pct(n_subj_ae, pop_n))
col3.metric("Subjects w/ SAE", format_n_pct(n_sae, pop_n))
col4.metric(f"Grade 3+ AE", format_n_pct(n_g3, pop_n))
col5.metric("Related AE", format_n_pct(n_rel, pop_n))

st.markdown("---")

tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
    "AE Summary",
    "Incidence Table",
    "AE by SOC/PT",
    "Timeline",
    "Swimmer Plot",
    "Narrative",
])

# ---- Tab 1: Summary ----
with tab1:
    summ = ae_summary_table(ae_filt, adsl, trt_col)
    if not summ.empty:
        st.dataframe(summ, use_container_width=True, hide_index=True)
        csv = summ.to_csv(index=False).encode("utf-8")
        st.download_button("Download AE Summary", csv, "ae_summary.csv")
    else:
        st.info("Summary not available.")

# ---- Tab 2: Full Incidence Table ----
with tab2:
    st.caption(
        "Subject-level incidence: each subject counted ONCE per Preferred Term. "
        "n (%) = subjects with AE / N in population."
    )
    inc = ae_incidence_table(ae_filt, adsl, trt_col, teae_only=teae_only,
                             min_pct=min_pct, grade_min=grade_min)
    if not inc.empty:
        display_cols = [c2 for c2 in inc.columns if not c2.startswith("_")]
        st.dataframe(inc[display_cols], use_container_width=True, hide_index=True, height=500)
        csv = inc[display_cols].to_csv(index=False).encode("utf-8")
        st.download_button("Download Incidence Table", csv, "ae_incidence.csv")
    else:
        st.info("Incidence table not available.")

# ---- Tab 3: SOC/PT Explorer ----
with tab3:
    pt_col = "AEDECOD" if "AEDECOD" in ae_filt.columns else "AETERM"
    soc_col = "AEBODSYS" if "AEBODSYS" in ae_filt.columns else None

    view = st.radio("View", ["By SOC", "By PT (Top N)"], horizontal=True)

    if view == "By SOC" and soc_col:
        soc_subj = (
            ae_filt.groupby(soc_col)["USUBJID"].nunique()
            .reset_index()
            .rename(columns={"USUBJID": "N_Subjects"})
            .sort_values("N_Subjects", ascending=False)
        )
        soc_subj["Pct"] = (soc_subj["N_Subjects"] / pop_n * 100).round(1)
        st.dataframe(soc_subj, use_container_width=True, hide_index=True)
        fig = incidence_bar(soc_subj, soc_col, "Pct",
                            title="Subjects with AE (%) by System Organ Class",
                            dark=dark, top_n=20)
        if fig:
            st.plotly_chart(fig, use_container_width=True)
    else:
        top_n = st.slider("Top N PTs", 5, 50, 20, key="top_n_pt")
        pt_subj = (
            ae_filt.groupby(pt_col)["USUBJID"].nunique()
            .reset_index()
            .rename(columns={"USUBJID": "N_Subjects"})
            .nlargest(top_n, "N_Subjects")
        )
        pt_subj["Pct"] = (pt_subj["N_Subjects"] / pop_n * 100).round(1)
        if trt_col:
            pt_arm = (
                ae_filt.groupby([pt_col, trt_col])["USUBJID"]
                .nunique()
                .reset_index()
                .rename(columns={"USUBJID": "N"})
            )
            pt_arm["Pct_Arm"] = pt_arm.apply(
                lambda r: r["N"] / adsl[adsl[trt_col] == r[trt_col]]["USUBJID"].nunique() * 100,
                axis=1,
            ).round(1)
            top_pts = pt_subj[pt_col].tolist()
            pt_arm = pt_arm[pt_arm[pt_col].isin(top_pts)]
            fig = incidence_bar(pt_arm, pt_col, "Pct_Arm", group_col=trt_col,
                                title="PT Incidence (%) by Treatment Arm",
                                dark=dark, top_n=top_n)
        else:
            fig = incidence_bar(pt_subj, pt_col, "Pct",
                                title=f"Top {top_n} Adverse Events (Subject Incidence %)",
                                dark=dark, top_n=top_n)
        if fig:
            st.plotly_chart(fig, use_container_width=True)

# ---- Tab 4: AE Timeline (per subject) ----
with tab4:
    subjs = sorted(ae_filt["USUBJID"].dropna().unique())
    if not subjs:
        st.info("No subjects with AEs in current population.")
    else:
        sel = st.selectbox("Subject", subjs, key="ae_timeline_subj")
        sub_ae = ae_filt[ae_filt["USUBJID"] == sel]
        grade_c = "AETOXGR" if "AETOXGR" in sub_ae.columns else "AESEV"
        pt_lbl = "AEDECOD" if "AEDECOD" in sub_ae.columns else "AETERM"

        rfstdtc = None
        if "TRTSDT" in adsl.columns:
            row = adsl[adsl["USUBJID"] == sel]
            if not row.empty:
                rfstdtc = row["TRTSDT"].iloc[0]

        fig_tl = ae_timeline(
            sub_ae, label_col=pt_lbl, grade_col=grade_c,
            rfstdtc=rfstdtc, dark=dark,
            title=f"AE Timeline - {sel}",
        )
        if fig_tl:
            st.plotly_chart(fig_tl, use_container_width=True)
        else:
            st.info("No plottable AE data for this subject.")

# ---- Tab 5: Swimmer Plot ----
with tab5:
    if "TRTSDT" in adsl.columns and "TRTEDT" in adsl.columns:
        fig_sw = swimmer_plot(
            adsl, subj_col="USUBJID",
            start_col="TRTSDT", end_col="TRTEDT",
            group_col=trt_col if trt_col else None,
            dark=dark, title="Treatment Duration Swimmer Plot",
        )
        if fig_sw:
            st.plotly_chart(fig_sw, use_container_width=True)
        else:
            st.info("Unable to render swimmer plot.")
    else:
        st.info("Treatment start/end dates (TRTSDT/TRTEDT) required in ADSL.")

# ---- Tab 6: SAE Narrative ----
with tab6:
    st.markdown("### SAE Auto-Narrative Generator")
    sae_subj = ae_filt[
        is_serious(ae_filt["AESER"]) if "AESER" in ae_filt.columns
        else pd.Series(False, index=ae_filt.index)
    ]["USUBJID"].dropna().unique()

    if len(sae_subj) == 0:
        st.info("No SAEs found in current population filter.")
    else:
        sel_sae = st.selectbox("Subject with SAE", sorted(sae_subj))
        subj_ae = ae_filt[ae_filt["USUBJID"] == sel_sae]
        sae_rows = subj_ae[
            is_serious(subj_ae["AESER"])
        ] if "AESER" in subj_ae.columns else subj_ae

        adsl_row = adsl[adsl["USUBJID"] == sel_sae]
        age = str(adsl_row["AGE"].iloc[0]) if not adsl_row.empty and "AGE" in adsl_row.columns else "N/A"
        sex = str(adsl_row["SEX"].iloc[0]) if not adsl_row.empty and "SEX" in adsl_row.columns else "N/A"
        arm = str(adsl_row[trt_col].iloc[0]) if not adsl_row.empty and trt_col else "N/A"

        for _, row in sae_rows.iterrows():
            pt = row.get("AEDECOD", row.get("AETERM", "Unknown"))
            start = str(row.get("AESTDTC", "N/A"))
            end = str(row.get("AEENDTC", "Ongoing"))
            grade = str(row.get("AETOXGR", row.get("AESEV", "N/A")))
            rel = str(row.get("AEREL", "N/A"))
            outcome = str(row.get("AEOUT", "N/A"))
            action = str(row.get("AEACN", "None"))

            narrative = (
                f"Subject {sel_sae}, a {age}-year-old {sex} assigned to {arm}, "
                f"experienced {pt} (Grade {grade}, {rel}) beginning {start} "
                f"(end: {end}). "
                f"Outcome: {outcome}. Action taken: {action}."
            )
            with st.expander(f"SAE: {pt}"):
                st.markdown(narrative)
                st.dataframe(
                    pd.DataFrame([row]).T.rename(columns={row.name: "Value"}),
                    use_container_width=True,
                )
