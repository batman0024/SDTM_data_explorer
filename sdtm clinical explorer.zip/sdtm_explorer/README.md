# SDTM Clinical Data Explorer
## Production-Grade Interactive Dashboard

### Architecture Overview

```
sdtm_explorer/
|-- app.py                          # Main entry point (Home dashboard)
|-- requirements.txt                # Python dependencies
|-- config/
|   |-- study_config.yaml           # Study-specific parameters (customize per program)
|-- .streamlit/
|   |-- config.toml                 # Streamlit theme defaults
|-- pages/
|   |-- 01_data_overview.py         # Domain inspection + CDISC conformance checks
|   |-- 02_subject_explorer.py      # Per-subject drill-down across all domains
|   |-- 03_standard_tfls.py         # CSR-quality tables (demographics, AE, disposition)
|   |-- 05_adverse_events.py        # ICH-compliant AE: n/N, TEAE, causality, swimmer plot
|   |-- 06_lab_explorer.py          # Labs: shift table, CHG/PCHG, MAAVs, Hys Law, panels
|   |-- 07_vital_signs.py           # VS: trends, boxplots, spaghetti, clinical flagging
|   |-- 08_efficacy.py              # KM curves, waterfall, spider plot, subgroup forest
|   |-- 09_patient_profile.py       # 5-panel timeline: phases + EX + AE + LB + TR
|   |-- 10_graph_rag.py             # NetworkX knowledge graph + inter-domain queries
|   |-- 11_export_audit.py          # Excel/CSV export + audit trail
|-- src/
|   |-- data/
|   |   |-- loader.py               # Robust multi-format SDTM loader (XPT/SAS7BDAT/CSV)
|   |   |-- session.py              # Streamlit session state management
|   |-- derivations/
|   |   |-- populations.py          # ADSL creation, SAFFL/ITTFL, CHG/PCHG, study day
|   |-- analysis/
|   |   |-- safety.py               # AE incidence (n/N), TEAE, CTCAE norm, shift table
|   |   |-- descriptive.py          # Continuous/categorical stats, KM, subgroup effects
|   |   |-- plots.py                # All Plotly visualizations (dark/light theme-aware)
|   |-- graph/
|   |   |-- builder.py              # NetworkX graph construction + analytics queries
|   |   |-- visualizer.py           # Plotly-based graph rendering + heatmap
|   |-- utils/
|   |   |-- theme.py                # Dark/light mode CSS injection + toggle
|   |   |-- helpers.py              # Shared utilities (dates, visit sort, narratives)
```

### Installation

```bash
# 1. Clone or unzip the project
cd sdtm_explorer

# 2. Create virtual environment
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run the application
streamlit run app.py
```

### Data Loading

Supported formats:
- SAS XPORT v5 (.xpt)
- SAS7BDAT (.sas7bdat)
- CSV (.csv)
- CSV gzipped (.csv.gz)

Two loading modes:
- Upload files directly in the sidebar (multi-file)
- Point to a local folder path containing SDTM files

### Key Capabilities

**Statistical Correctness (ICH E9)**
- AE incidence uses subject-level n/N (not record count)
- TEAE correctly identified from first dose date (EX.EXSTDTC)
- Shift tables use worst post-baseline (not mode)
- CTCAE grade normalized from text and numeric variants
- CHG/PCHG derived with proper baseline definition (BLFL or pre-dose)
- KM curves via lifelines with median + 95% CI + log-rank p

**Graph RAG (NetworkX)**
- Heterogeneous knowledge graph: Subject, AE_Term, SOC, Drug, Lab_Test, Response
- Edge types: HAS_AE, HAS_SAE, RELATED_AE, RECEIVED_DRUG, HAD_LAB, HAD_RESPONSE, CONCOM_MED
- AE co-occurrence matrix (shared subjects)
- Drug-AE association from cross-domain linkage
- Node centrality and community detection
- Subject neighbourhood ego-graph
- Inter-domain subject query: "find all subjects with this AE + that lab abnormality"

**Dark / Light Mode**
- Toggle in sidebar on every page
- CSS injected via apply_theme(); Plotly template switched automatically
- Colors stored in session_state for consistent theming across all charts

### Configuration

Edit `config/study_config.yaml` to customize:
- Population flag variable names (SAFFL, ITTFL, etc.)
- Treatment variable name (TRT01A, ARM, etc.)
- Lab panel groupings
- MAAV thresholds per lab parameter
- VS clinical thresholds
- AE CTCAE grade mapping

### Dependencies

| Library | Purpose |
|---|---|
| streamlit | Web application framework |
| pandas / numpy | Data manipulation |
| plotly | Interactive visualizations |
| pyreadstat | SAS XPT and SAS7BDAT reading |
| networkx | Knowledge graph construction |
| lifelines | Kaplan-Meier survival analysis |
| scipy | Statistical tests (chi-square, t-test) |
| statsmodels | ANCOVA, regression |
| openpyxl | Excel export |
| kaleido | Static figure export (SVG/PDF) |

### Pages Reference

| Page | Key Analysis |
|---|---|
| Home | KPI ribbon, domain status, data loading |
| Data Overview | Per-domain inspection, CDISC checks, distributions |
| Subject Explorer | Cross-domain per-subject drill-down |
| Standard TFLs | Table 1 demographics, AE summary, disposition, listings |
| Adverse Events | ICH n/N incidence, SAE narrative, swimmer plot |
| Lab Explorer | Shift table (correct), MAAVs, Hys Law, spaghetti |
| Vital Signs | BP classification, clinical flagging, CHG trend |
| Efficacy | KM (PFS/OS), waterfall, spider, forest subgroup |
| Patient Profile | 5-panel timeline with phase + EX + AE + LB + TR |
| Graph RAG | Knowledge graph, co-occurrence, drug-AE, centrality |
| Export / Audit | Excel export, CSV listings, audit trail download |
