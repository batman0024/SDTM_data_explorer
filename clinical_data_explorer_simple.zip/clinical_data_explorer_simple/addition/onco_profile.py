# -*- coding: utf-8 -*-
#!/usr/bin/env python3
"""
SDTM Oncology Analysis Dashboard – Streamlit Application

A Streamlit app for oncology-focused visualizations and summaries from SDTM data,
with robust file loading and graceful error handling.

Author: SDTM Analytics Team
Version: 1.3.0
"""

from __future__ import annotations

import io
import re
import logging
import warnings
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, List

import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import streamlit as st

# -----------------------------------------------------------------------------
# Global setup
# -----------------------------------------------------------------------------
warnings.filterwarnings("ignore")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

st.set_page_config(
    page_title="SDTM Oncology Analysis Dashboard",
    page_icon="🏥",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""<style></style>""", unsafe_allow_html=True)

# -----------------------------------------------------------------------------
# Utility classes
# -----------------------------------------------------------------------------
class AnalysisLogger:
    """Collects logs, warnings, and an execution summary across the session."""

    def __init__(self):
        self.logs = []
        self.errors = []
        self.warnings = []
        self.summary = {
            "timestamp": datetime.now().isoformat(),
            "domains_loaded": {},
            "analyses_completed": [],
            "analyses_failed": [],
            "total_warnings": 0,
            "total_errors": 0,
        }

    def log(self, level: str, message: str):
        entry = {
            "timestamp": datetime.now().isoformat(),
            "level": level,
            "message": message,
        }
        self.logs.append(entry)
        if level == "ERROR":
            self.errors.append(message)
            self.summary["total_errors"] += 1
        elif level == "WARNING":
            self.warnings.append(message)
            self.summary["total_warnings"] += 1
        logger.log(getattr(logging, level, logging.INFO), message)

    def log_domain_load(self, domain: str, success: bool, records: int = 0, error: Optional[str] = None):
        self.summary["domains_loaded"][domain] = {
            "success": success,
            "records": records,
            "error": error,
        }
        if success:
            self.log("INFO", f"Domain {domain} loaded: {records} records")
        else:
            self.log("ERROR", f"Domain {domain} failed: {error}")

    def log_analysis_complete(self, name: str, success: bool):
        if success:
            self.summary["analyses_completed"].append(name)
            self.log("INFO", f"Analysis completed: {name}")
        else:
            self.summary["analyses_failed"].append(name)
            self.log("ERROR", f"Analysis failed: {name}")

    def get_summary_text(self) -> str:
        lines = [
            "=" * 80,
            "ANALYSIS EXECUTION SUMMARY",
            "=" * 80,
            f"Timestamp: {self.summary['timestamp']}",
            "",
            "DOMAINS LOADED:",
            "-" * 80,
        ]
        for domain, info in self.summary["domains_loaded"].items():
            status = "✓" if info["success"] else "✗"
            lines.append(f"{status} {domain}: {info['records']} records")
        lines.extend([
            "",
            "ANALYSES:",
            "-" * 80,
            f"Completed: {len(self.summary['analyses_completed'])}",
            f"Failed: {len(self.summary['analyses_failed'])}",
            f"Total Warnings: {self.summary['total_warnings']}",
            f"Total Errors: {self.summary['total_errors']}",
            "",
            "=" * 80,
        ])
        return "\n".join(lines)

# -----------------------------------------------------------------------------
# Robust SDTM loader
# -----------------------------------------------------------------------------
class SDTMDataLoader:
    """Load SDTM domains from uploaded files and normalize columns."""

    def __init__(self, logger: AnalysisLogger):
        self.logger = logger
        self.domains: Dict[str, pd.DataFrame] = {}

    # -- specific readers --
    def _read_sas7bdat(self, uploaded):
        try:
            import pyreadstat
        except ImportError as ie:
            raise RuntimeError(
                "pyreadstat is required to read .sas7bdat. Install with: pip install pyreadstat"
            ) from ie

        import tempfile
        with tempfile.NamedTemporaryFile(suffix=".sas7bdat", delete=False) as tmp:
            tmp.write(uploaded.getbuffer())
            tmp_path = tmp.name

        try:
            df, _ = pyreadstat.read_sas7bdat(tmp_path)
            return df
        finally:
            try:
                Path(tmp_path).unlink(missing_ok=True)
            except Exception:
                pass

    def _read_xpt(self, uploaded):
        bio = io.BytesIO(uploaded.getbuffer())
        df = pd.read_sas(bio, format="xport", encoding="utf-8")
        return df

    def _read_csv(self, uploaded, compression: Optional[str] = None):
        if compression == "gzip":
            return pd.read_csv(uploaded, compression="gzip")
        return pd.read_csv(uploaded)

    def _read_excel(self, uploaded, sheet_name: Optional[str] = None):
        return pd.read_excel(uploaded, sheet_name=sheet_name)

    # -- main loader --
    def load_from_uploaded_files(
        self,
        uploaded_files: Dict[str, io.BytesIO],
        sheet_name: Optional[str] = None
    ) -> Dict[str, pd.DataFrame]:
        """
        Domain name is the base filename (before extension) uppercased.
        """
        domains: Dict[str, pd.DataFrame] = {}
        self.logger.log("INFO", f"Received {len(uploaded_files)} file(s) for loading")

        for file_name, file_obj in uploaded_files.items():
            try:
                lower_name = file_name.lower()
                domain_name = file_name.split(".")[0].upper()

                df = None
                if lower_name.endswith(".sas7bdat"):
                    df = self._read_sas7bdat(file_obj)
                elif lower_name.endswith(".xpt"):
                    df = self._read_xpt(file_obj)
                elif lower_name.endswith(".csv.gz"):
                    df = self._read_csv(file_obj, compression="gzip")  # fixed
                elif lower_name.endswith(".csv"):
                    df = self._read_csv(file_obj)
                elif lower_name.endswith(".xlsx") or lower_name.endswith(".xls"):
                    df = self._read_excel(file_obj, sheet_name=sheet_name)
                else:
                    self.logger.log("WARNING", f"Unsupported file format: {file_name}")
                    continue

                if df is not None and isinstance(df, pd.DataFrame) and not df.empty:
                    # normalize column names: strip + uppercase
                    try:
                        df.columns = [str(c).strip().upper() for c in df.columns]
                    except Exception:
                        pass
                    # quick fix for occasional USSUBJID typo
                    if "USSUBJID" in df.columns and "USUBJID" not in df.columns:
                        df = df.rename(columns={"USSUBJID": "USUBJID"})
                    domains[domain_name] = df
                    self.logger.log_domain_load(domain_name, True, len(df))
                else:
                    self.logger.log_domain_load(domain_name, False, 0, "Empty or invalid dataframe")

            except Exception as e:
                self.logger.log_domain_load(file_name, False, 0, str(e))

        self.domains = domains
        return domains

# -----------------------------------------------------------------------------
# Shared helpers
# -----------------------------------------------------------------------------
def _safe_to_datetime(series: pd.Series) -> pd.Series:
    return pd.to_datetime(series, errors="coerce") if series is not None else pd.Series(dtype="datetime64[ns]")

# -----------------------------------------------------------------------------
# Oncology calculations
# -----------------------------------------------------------------------------
def identify_teae(ae_data: pd.DataFrame, ex_data: pd.DataFrame) -> pd.DataFrame:
    """TEAE: AESTDTC >= first EXSTDTC (unless AEENRF says BEFORE)."""
    try:
        first_dose = ex_data.groupby("USUBJID")["EXSTDTC"].min().reset_index()
        first_dose.columns = ["USUBJID", "TRTSDT"]

        ae = ae_data.merge(first_dose, on="USUBJID", how="left")
        ae["AESTDTC"] = pd.to_datetime(ae["AESTDTC"], errors="coerce")
        ae["TRTSDT"] = pd.to_datetime(ae["TRTSDT"], errors="coerce")

        if "AEENRF" in ae.columns:
            ae["AEENRF_FLAG"] = ae["AEENRF"].astype(str).str.upper().fillna("AFTER")
        else:
            ae["AEENRF_FLAG"] = "AFTER"

        ae["TEAE"] = (ae["AESTDTC"] >= ae["TRTSDT"]) & (ae["AEENRF_FLAG"] != "BEFORE")
        return ae
    except Exception as e:
        logger.error(f"TEAE identification failed: {e}")
        out = ae_data.copy()
        out["TEAE"] = True
        return out

def calculate_response_from_tr(tr: pd.DataFrame) -> pd.DataFrame:
    """Simple RECIST-like response from TR."""
    try:
        rows = []
        req = {"USUBJID", "VISIT", "TRORRES"}
        if not req.issubset(set(tr.columns)):
            return pd.DataFrame()

        for sid in tr["USUBJID"].unique():
            s = tr[tr["USUBJID"] == sid].copy()
            base_visits = ["SCREENING", "BASELINE", "SCREEN"]
            base = s[s["VISIT"].astype(str).str.upper().isin(base_visits)]
            if base.empty:
                base = s.iloc[[0]]
            bsum = pd.to_numeric(base["TRORRES"], errors="coerce").sum()
            if bsum == 0:
                continue

            for v in s["VISIT"].astype(str).unique():
                d = s[s["VISIT"].astype(str) == v]
                csum = pd.to_numeric(d["TRORRES"], errors="coerce").sum()
                pct = (csum - bsum) / bsum * 100 if bsum else None

                if csum == 0:
                    resp = "CR"
                elif pct is not None and pct <= -30:
                    resp = "PR"
                elif pct is not None and pct >= 20:
                    resp = "PD"
                else:
                    resp = "SD"

                rsdtc = d["TRDTC"].iloc[0] if "TRDTC" in d.columns and not d["TRDTC"].empty else None
                rows.append({
                    "USUBJID": sid,
                    "VISIT": v,
                    "RSDTC": rsdtc,
                    "RSSTRESC": resp,
                    "PCT_CHANGE": pct,
                })
        return pd.DataFrame(rows)
    except Exception as e:
        logger.error(f"Response calculation from TR failed: {e}")
        return pd.DataFrame()

def calculate_pfs_data(
    rs: Optional[pd.DataFrame],
    ds: Optional[pd.DataFrame],
    ex: pd.DataFrame,
    dm: Optional[pd.DataFrame]
) -> pd.DataFrame:
    """Event if PD or death; otherwise censor at last RS date (or start)."""
    rows = []
    try:
        if dm is not None and "USUBJID" in dm.columns and not dm.empty:
            subjects = dm["USUBJID"].unique()
        elif ex is not None and "USUBJID" in ex.columns:
            subjects = ex["USUBJID"].unique()
        else:
            subjects = []

        for sid in subjects:
            try:
                sx = ex[ex["USUBJID"] == sid]
                if sx.empty or "EXSTDTC" not in sx.columns:
                    continue
                start = pd.to_datetime(sx["EXSTDTC"].min(), errors="coerce")
                if pd.isna(start):
                    continue

                progression_date = None
                if rs is not None and not rs.empty and "USUBJID" in rs.columns:
                    sr = rs[rs["USUBJID"] == sid].copy()
                    if not sr.empty and "RSSTRESC" in sr.columns:
                        if "RSDTC" in sr.columns:
                            sr["RSDTC"] = pd.to_datetime(sr["RSDTC"], errors="coerce")
                        prog = sr[sr["RSSTRESC"].astype(str).isin(["PD", "PROGRESSIVE DISEASE"])]
                        if not prog.empty and "RSDTC" in prog.columns:
                            progression_date = prog["RSDTC"].min()

                death_date = None
                if ds is not None and not ds.empty and "USUBJID" in ds.columns:
                    sd = ds[ds["USSUBJID" if "USSUBJID" in ds.columns else "USUBJID"] == sid]
                    if not sd.empty and "DSDECOD" in sd.columns:
                        mask = sd["DSDECOD"].astype(str).str.upper().str.contains("DEATH", na=False)
                        if mask.any() and "DSSTDTC" in sd.columns:
                            death_date = pd.to_datetime(sd.loc[mask, "DSSTDTC"].iloc[0], errors="coerce")

                ev_dates = [d for d in [progression_date, death_date] if pd.notna(d)]
                if ev_dates:
                    ev_date = min(ev_dates)
                    event = 1
                    ev_type = "Progression" if ev_date == progression_date else "Death"
                else:
                    event = 0
                    ev_type = "Censored"
                    if rs is not None and not rs.empty and "USUBJID" in rs.columns:
                        sr = rs[rs["USUBJID"] == sid].copy()
                        if not sr.empty and "RSDTC" in sr.columns:
                            sr["RSDTC"] = pd.to_datetime(sr["RSDTC"], errors="coerce")
                            ev_date = sr["RSDTC"].max()
                        else:
                            ev_date = start
                    else:
                        ev_date = start

                months = max(0.0, (ev_date - start).days / 30.44)
                arm = None
                if dm is not None and "ARM" in dm.columns:
                    sdm = dm[dm["USUBJID"] == sid]
                    if not sdm.empty:
                        arm = sdm["ARM"].iloc[0]

                rows.append({
                    "USUBJID": sid,
                    "PFS_MONTHS": months,
                    "EVENT": event,
                    "EVENT_TYPE": ev_type,
                    "ARM": arm,
                })
            except Exception as e:
                logger.warning(f"PFS calculation failed for {sid}: {e}")
                continue
    except Exception as e:
        logger.error(f"PFS calculation failed: {e}")

    return pd.DataFrame(rows)

# -----------------------------------------------------------------------------
# Exposure helpers
# -----------------------------------------------------------------------------
def derive_first_last_treatment(ex: pd.DataFrame) -> pd.DataFrame:
    """
    Returns per-subject first and last treatment dates.
    Uses EXSTDTC for start, EXENDTC (if available) else EXSTDTC for end.
    """
    df = ex.copy()
    df.columns = [c.strip().upper() for c in df.columns]
    if "USUBJID" not in df.columns or "EXSTDTC" not in df.columns:
        return pd.DataFrame(columns=["USUBJID", "TRTSDT", "TRTEDT"])

    df["EXSTDTC"] = _safe_to_datetime(df["EXSTDTC"])
    if "EXENDTC" in df.columns:
        df["EXENDTC"] = _safe_to_datetime(df["EXENDTC"])
    else:
        df["EXENDTC"] = df["EXSTDTC"]

    g = df.groupby("USUBJID")
    out = g.agg(TRTSDT=("EXSTDTC", "min"), TRTEDT=("EXENDTC", "max")).reset_index()
    return out

def build_exposure_metrics(ex: pd.DataFrame, dm: Optional[pd.DataFrame] = None,
                           gap_days: int = 7) -> pd.DataFrame:
    """
    Per-subject exposure metrics:
     - first/last dose dates
     - exposure_days
     - administrations (rows)
     - total_dose (sum EXDOSE if present)
     - avg_dose (if EXDOSE)
     - interruptions (gaps > gap_days between administrations)
     - ARM (if DM provided)
    """
    if ex is None or ex.empty:
        return pd.DataFrame()

    df = ex.copy()
    df.columns = [c.strip().upper() for c in df.columns]
    if "USUBJID" not in df.columns or "EXSTDTC" not in df.columns:
        return pd.DataFrame()

    df["EXSTDTC"] = _safe_to_datetime(df["EXSTDTC"])
    df["EXENDTC"] = _safe_to_datetime(df["EXENDTC"]) if "EXENDTC" in df.columns else df["EXSTDTC"]
    df["EXDOSE_NUM"] = pd.to_numeric(df.get("EXDOSE", pd.Series(index=df.index)), errors="coerce")

    metrics = []
    for sid, s in df.sort_values(["USUBJID", "EXSTDTC"]).groupby("USUBJID"):
        s = s.copy()
        first_dt = s["EXSTDTC"].min()
        last_dt  = s["EXENDTC"].max()
        n_admin  = len(s)
        exposure_days = (last_dt - first_dt).days + 1 if pd.notna(first_dt) and pd.notna(last_dt) else None
        total_dose = s["EXDOSE_NUM"].sum(skipna=True)
        avg_dose = total_dose / n_admin if n_admin > 0 and pd.notna(total_dose) else None

        # interruptions: gap > gap_days from previous end to next start
        s["prev_end"] = s["EXENDTC"].shift(1)
        gaps = (s["EXSTDTC"] - s["prev_end"]).dt.days
        interruptions = int((gaps > gap_days).fillna(False).sum())

        metrics.append({
            "USUBJID": sid,
            "FIRST_DOSE": first_dt,
            "LAST_DOSE": last_dt,
            "EXPOSURE_DAYS": exposure_days,
            "ADMINISTRATIONS": n_admin,
            "TOTAL_DOSE": total_dose if pd.notna(total_dose) else None,
            "AVG_DOSE": avg_dose,
            "INTERRUPTIONS": interruptions,
        })

    met = pd.DataFrame(metrics)
    if dm is not None and not dm.empty and {"USUBJID", "ARM"}.issubset(dm.columns):
        met = met.merge(dm[["USUBJID", "ARM"]], on="USUBJID", how="left")

    return met

def create_exposure_dashboard(ex: pd.DataFrame, dm: Optional[pd.DataFrame]) -> dict:
    """
    Returns {'success', 'figure_main', 'figure_by_arm', 'table', 'warnings', 'errors'}
    """
    result = {"success": False, "figure_main": None, "figure_by_arm": None,
              "table": pd.DataFrame(), "warnings": [], "errors": []}
    try:
        met = build_exposure_metrics(ex, dm)
        if met.empty:
            result["warnings"].append("EX domain missing required columns (USUBJID/EXSTDTC).")
            return result

        # Main: histogram of exposure days
        if met["EXPOSURE_DAYS"].notna().any():
            hist = go.Figure(go.Histogram(
                x=met["EXPOSURE_DAYS"], nbinsx=30, marker_color="steelblue"
            ))
            hist.update_layout(
                title="Exposure Duration (days)",
                xaxis_title="Days", yaxis_title="Subjects",
                template="plotly_white", height=400
            )
            result["figure_main"] = hist

        # By arm: box of exposure days
        if "ARM" in met.columns and met["EXPOSURE_DAYS"].notna().any():
            box = go.Figure()
            for arm, s in met.groupby("ARM"):
                box.add_trace(go.Box(
                    y=s["EXPOSURE_DAYS"], name=str(arm),
                    boxmean=True, marker_color="seagreen"
                ))
            box.update_layout(
                title="Exposure Duration by Arm",
                yaxis_title="Days", template="plotly_white", height=400
            )
            result["figure_by_arm"] = box

        # Tabular metrics
        cols_order = ["USUBJID", "ARM", "FIRST_DOSE", "LAST_DOSE",
                      "EXPOSURE_DAYS", "ADMINISTRATIONS", "TOTAL_DOSE", "AVG_DOSE", "INTERRUPTIONS"]
        show_cols = [c for c in cols_order if c in met.columns]
        result["table"] = met[show_cols].sort_values(["EXPOSURE_DAYS", "ADMINISTRATIONS"], ascending=[False, False])
        result["success"] = True
    except Exception as e:
        result["errors"].append(str(e))
    return result

# -----------------------------------------------------------------------------
# Prior therapy helpers
# -----------------------------------------------------------------------------
def _text_series(df: pd.DataFrame, candidates: list[str]) -> pd.Series:
    """
    Return the first existing column (uppercased) from candidates as uppercase text,
    else an empty Series.
    """
    for c in candidates:
        if c in df.columns:
            return df[c].astype(str).str.upper().fillna("")
    return pd.Series([""] * len(df), index=df.index)

def derive_prior_therapies(mh: Optional[pd.DataFrame], cm: Optional[pd.DataFrame]) -> dict:
    """
    Heuristic categorization of prior therapies into SYSTEMIC / RADIATION / SURGERY / OTHER.
    Looks at MH(MHDECOD/MHTERM) and CM(CMDECOD/CMTRT).
    Returns: {'per_subject': DataFrame, 'category_counts': DataFrame, 'top_drugs': DataFrame}
    """
    mh_df = mh.copy() if mh is not None else pd.DataFrame()
    cm_df = cm.copy() if cm is not None else pd.DataFrame()

    for df in (mh_df, cm_df):
        if not df.empty:
            df.columns = [c.strip().upper() for c in df.columns]

    # Unified long table: USUBJID, SRC (MH/CM), TERM
    out_rows = []

    if not mh_df.empty and "USUBJID" in mh_df.columns:
        term = _text_series(mh_df, ["MHDECOD", "MHTERM"])
        for u, t in zip(mh_df["USUBJID"].astype(str), term):
            out_rows.append({"USUBJID": u, "SRC": "MH", "TERM": t})

    if not cm_df.empty and "USUBJID" in cm_df.columns:
        term = _text_series(cm_df, ["CMDECOD", "CMTRT"])
        for u, t in zip(cm_df["USUBJID"].astype(str), term):
            out_rows.append({"USUBJID": u, "SRC": "CM", "TERM": t})

    if not out_rows:
        return {"per_subject": pd.DataFrame(), "category_counts": pd.DataFrame(), "top_drugs": pd.DataFrame()}

    long = pd.DataFrame(out_rows)

    # Simple keyword sets (expand per program/TA as needed)
    kw_radiation = r"(RADIATION|RADIOTHERAPY|RADIOTHERAPEUTIC|XRT|IRRADIATION)"
    kw_surgery   = r"(SURGERY|RESECTION|OPERAT|EXCISION|LOBECTOMY|MASTECTOMY)"
    kw_systemic  = r"(CHEMO|CHEMOTHERAPY|PLATIN|PACLITAXEL|DOCETAXEL|GEMCITABINE|IRINOTECAN|DOXORUBICIN|TRASTUZUMAB|BEVACIZUMAB|NIVOLUMAB|PEMBROLIZUMAB|IMATINIB|ERLOTINIB|GEFITINIB|SORAFENIB|SUNITINIB|LETROZOLE|TAMOXIFEN|FULVESTRANT|ABIRATERONE|ENZALUTAMIDE)"
    # classify
    long["SYSTEMIC"]  = long["TERM"].str.contains(kw_systemic,  regex=True, na=False)
    long["RADIATION"] = long["TERM"].str.contains(kw_radiation, regex=True, na=False)
    long["SURGERY"]   = long["TERM"].str.contains(kw_surgery,   regex=True, na=False)
    long["OTHER"]     = ~(long["SYSTEMIC"] | long["RADIATION"] | long["SURGERY"])

    # per-subject flags
    per_subj = long.groupby("USUBJID").agg({
        "SYSTEMIC": "any",
        "RADIATION": "any",
        "SURGERY": "any",
        "OTHER": "any"
    }).reset_index()

    # category counts (# subjects with category)
    cats = []
    for c in ["SYSTEMIC", "RADIATION", "SURGERY", "OTHER"]:
        cats.append({"Category": c, "Subjects": int(per_subj[c].sum())})
    category_counts = pd.DataFrame(cats)

    # top drugs/terms from CM (if available)
    top_drugs = pd.DataFrame()
    if not cm_df.empty:
        cm_term = _text_series(cm_df, ["CMDECOD", "CMTRT"])
        if not cm_term.empty:
            top = cm_term.value_counts().head(20)
            top_drugs = top.reset_index()
            top_drugs.columns = ["TERM", "COUNT"]

    return {"per_subject": per_subj, "category_counts": category_counts, "top_drugs": top_drugs}

def create_prior_therapy_dashboard(mh: Optional[pd.DataFrame], cm: Optional[pd.DataFrame]) -> dict:
    """
    Returns {'success', 'fig_categories', 'top_table', 'per_subject_table', 'warnings', 'errors'}
    """
    result = {"success": False, "fig_categories": None, "top_table": pd.DataFrame(),
              "per_subject_table": pd.DataFrame(), "warnings": [], "errors": []}
    try:
        out = derive_prior_therapies(mh, cm)
        per_subj = out["per_subject"]
        cat      = out["category_counts"]
        top      = out["top_drugs"]

        if per_subj.empty and cat.empty and top.empty:
            result["warnings"].append("No recognizable prior therapies in MH/CM.")
            return result

        if not cat.empty:
            bar = go.Figure(go.Bar(x=cat["Category"], y=cat["Subjects"], marker_color="teal"))
            bar.update_layout(title="Subjects with Prior Therapy by Category",
                              xaxis_title="Category", yaxis_title="Subjects",
                              template="plotly_white", height=380)
            result["fig_categories"] = bar

        result["per_subject_table"] = per_subj
        result["top_table"] = top
        result["success"] = True
    except Exception as e:
        result["errors"].append(str(e))
    return result

# -----------------------------------------------------------------------------
# Cross-domain helpers
# -----------------------------------------------------------------------------
def build_ae_on_treatment(ae: pd.DataFrame, ex: pd.DataFrame, tail_days: int = 30) -> pd.DataFrame:
    """
    Merge AE with first/last treatment window; flag ON_TREATMENT if
    AESTDTC in [TRTSDT, TRTEDT + tail_days].
    """
    if ae is None or ae.empty or ex is None or ex.empty:
        return pd.DataFrame()

    a = ae.copy()
    a.columns = [c.strip().upper() for c in a.columns]
    if "USUBJID" not in a.columns or "AESTDTC" not in a.columns:
        return pd.DataFrame()

    a["AESTDTC"] = _safe_to_datetime(a["AESTDTC"])
    trt = derive_first_last_treatment(ex)
    if trt.empty:
        return pd.DataFrame()

    m = a.merge(trt, on="USUBJID", how="left")
    m["TRTEDT_PLUS"] = m["TRTEDT"] + pd.to_timedelta(tail_days, unit="D")
    m["ON_TREATMENT"] = (m["AESTDTC"] >= m["TRTSDT"]) & (m["AESTDTC"] <= m["TRTEDT_PLUS"])
    return m

def best_response_from_rs(rs: pd.DataFrame) -> pd.DataFrame:
    """
    Best response per subject using priority CR>PR>SD>PD>NE; if multiple, keep best.
    """
    if rs is None or rs.empty:
        return pd.DataFrame(columns=["USUBJID", "BEST_RSP"])
    r = rs.copy()
    r.columns = [c.strip().upper() for c in r.columns]
    if "USUBJID" not in r.columns or "RSSTRESC" not in r.columns:
        return pd.DataFrame(columns=["USUBJID", "BEST_RSP"])

    pri = {"CR": 1, "PR": 2, "SD": 3, "PD": 4, "NE": 5}
    r["RESP_N"] = r["RSSTRESC"].astype(str).str.upper().map(pri).fillna(99)
    best = r.sort_values(["USUBJID", "RESP_N"]).groupby("USUBJID").agg(BEST_RSP=("RSSTRESC", "first")).reset_index()
    best["BEST_RSP"] = best["BEST_RSP"].astype(str).str.upper()
    return best

def create_cross_domain_dashboard(ae: Optional[pd.DataFrame], ex: Optional[pd.DataFrame],
                                  rs: Optional[pd.DataFrame], dm: Optional[pd.DataFrame],
                                  tail_days: int = 30) -> dict:
    """
    Returns {'success', 'fig_arm', 'fig_rsp', 'warnings', 'errors'}
    """
    result = {"success": False, "fig_arm": None, "fig_rsp": None, "warnings": [], "errors": []}
    try:
        if ae is None or ae.empty or ex is None or ex.empty:
            result["warnings"].append("Need AE and EX to compute on‑treatment AEs.")
            return result

        ae_trt = build_ae_on_treatment(ae, ex, tail_days=tail_days)
        if ae_trt.empty:
            result["warnings"].append("Unable to derive on‑treatment window (missing EX dates).")
            return result

        # AE incidence by Arm
        if dm is not None and {"USUBJID", "ARM"}.issubset(dm.columns):
            a = ae_trt.merge(dm[["USUBJID", "ARM"]], on="USUBJID", how="left")
            arm_counts = a.groupby("ARM")["USUBJID"].nunique()
            arm_on     = a[a["ON_TREATMENT"]].groupby("ARM")["USUBJID"].nunique()
            df_arm = pd.DataFrame({
                "ARM": arm_counts.index.astype(str),
                "Any AE": arm_counts.values,
                "On‑Treatment AE": arm_on.reindex(arm_counts.index).fillna(0).astype(int).values
            })
            fig1 = go.Figure()
            fig1.add_bar(x=df_arm["ARM"], y=df_arm["Any AE"], name="Any AE", marker_color="lightgray")
            fig1.add_bar(x=df_arm["ARM"], y=df_arm["On‑Treatment AE"], name="On‑Treatment AE", marker_color="tomato")
            fig1.update_layout(barmode="group", title="AE Incidence by Arm",
                               xaxis_title="Arm", yaxis_title="Subjects",
                               template="plotly_white", height=400)
            result["fig_arm"] = fig1
        else:
            result["warnings"].append("DM with ARM missing; skipping 'by Arm' panel.")

        # AE incidence by best response
        if rs is not None and not rs.empty:
            best = best_response_from_rs(rs)
            if not best.empty:
                b = ae_trt.merge(best, on="USUBJID", how="left")
                rsp_counts = b.groupby("BEST_RSP")["USUBJID"].nunique()
                rsp_on     = b[b["ON_TREATMENT"]].groupby("BEST_RSP")["USUBJID"].nunique()
                idx = rsp_counts.index.astype(str)
                df_rsp = pd.DataFrame({
                    "RESP": idx,
                    "Any AE": rsp_counts.values,
                    "On‑Treatment AE": rsp_on.reindex(idx).fillna(0).astype(int).values
                })
                fig2 = go.Figure()
                fig2.add_bar(x=df_rsp["RESP"], y=df_rsp["Any AE"], name="Any AE", marker_color="lightgray")
                fig2.add_bar(x=df_rsp["RESP"], y=df_rsp["On‑Treatment AE"], name="On‑Treatment AE", marker_color="steelblue")
                fig2.update_layout(barmode="group", title="AE Incidence vs Best Response",
                                   xaxis_title="Best Response", yaxis_title="Subjects",
                                   template="plotly_white", height=400)
                result["fig_rsp"] = fig2
        else:
            result["warnings"].append("RS missing; skipping 'by Best Response' panel.")

        result["success"] = True
    except Exception as e:
        result["errors"].append(str(e))
    return result

# -----------------------------------------------------------------------------
# AE overview and tables
# -----------------------------------------------------------------------------
def create_placeholder_figure(title: str, message: str) -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(
        text=f"**{message}**\nThis analysis was skipped due to missing or insufficient data.",
        xref="paper", yref="paper", x=0.5, y=0.5, showarrow=False,
        font=dict(size=14, color="gray"), align="center"
    )
    fig.update_layout(
        title=title + " (Not Available)",
        xaxis=dict(showgrid=False, showticklabels=False, zeroline=False),
        yaxis=dict(showgrid=False, showticklabels=False, zeroline=False),
        height=400, template="plotly_white"
    )
    return fig

def create_ae_overview_dashboard(
    ae: pd.DataFrame, dm: Optional[pd.DataFrame], ex: Optional[pd.DataFrame]
) -> dict:
    result = {"success": False, "figure": None, "errors": [], "warnings": [], "metadata": {}}
    try:
        if ae is None or ae.empty:
            result["errors"].append("AE domain not available")
            result["figure"] = create_placeholder_figure("AE Overview", "AE domain not available")
            return result

        # TEAE identification if EX available
        if ex is not None and not ex.empty:
            if "USSUBJID" in ex.columns and "USUBJID" not in ex.columns:
                ex = ex.rename(columns={"USSUBJID": "USUBJID"})
        if ex is not None and not ex.empty and {"USUBJID", "EXSTDTC"}.issubset(ex.columns):
            ae = identify_teae(ae, ex)
            teae = ae[ae["TEAE"] == True]
        else:
            result["warnings"].append("EX domain not available – using all AEs")
            teae = ae.copy()
            teae["TEAE"] = True

        fig = make_subplots(
            rows=2, cols=2,
            subplot_titles=(
                "AE Incidence by System Organ Class",
                "AE Distribution by Grade",
                "Most Frequent Adverse Events",
                "AE by Treatment Arm",
            ),
            specs=[[{"type": "bar"}, {"type": "bar"}],
                   [{"type": "bar"}, {"type": "bar"}]],
            vertical_spacing=0.15, horizontal_spacing=0.12
        )

        # SOC
        soc_col = "AESOC" if "AESOC" in teae.columns else ("AEBODSYS" if "AEBODSYS" in teae.columns else None)
        if soc_col:
            soc_counts = teae.groupby(soc_col)["USUBJID"].nunique().sort_values(ascending=True).tail(15)
            fig.add_bar(y=soc_counts.index, x=soc_counts.values, orientation="h",
                        marker_color="steelblue", row=1, col=1)
        else:
            result["warnings"].append("SOC column not available")

        # Grade distribution
        grade_col = "AETOXGR" if "AETOXGR" in teae.columns else ("AESEV" if "AESEV" in teae.columns else None)
        if grade_col:
            grade_counts = teae[grade_col].astype(str).str.upper().value_counts().sort_index()
            colors = {
                "1": "#FFFFCC", "2": "#FFCC66", "3": "#FF9933", "4": "#FF3300", "5": "#990000",
                "MILD": "#FFFFCC", "MODERATE": "#FFCC66", "SEVERE": "#FF3300",
                "LIFE-THREATENING": "#FF3300", "DEATH": "#990000",
            }
            fig.add_bar(
                x=grade_counts.index.astype(str),
                y=grade_counts.values,
                marker_color=[colors.get(str(x), "gray") for x in grade_counts.index],
                row=1, col=2
            )
        else:
            result["warnings"].append("Grade column not available")

        # Top AE terms
        ae_col = "AEDECOD" if "AEDECOD" in teae.columns else ("AETERM" if "AETERM" in teae.columns else None)
        if ae_col:
            top_aes = teae.groupby(ae_col)["USUBJID"].nunique().sort_values(ascending=True).tail(15)
            fig.add_bar(
                y=top_aes.index, x=top_aes.values, orientation="h",
                marker_color="indianred", row=2, col=1
            )

        # Arm breakdown
        if dm is not None and {"USUBJID", "ARM"}.issubset(dm.columns):
            ae_arm = teae.merge(dm[["USUBJID", "ARM"]], on="USUBJID", how="left")
            arm_counts = ae_arm.groupby("ARM")["USUBJID"].nunique().sort_index()
            fig.add_bar(x=arm_counts.index.astype(str), y=arm_counts.values,
                        marker_color="seagreen", row=2, col=2)
        else:
            result["warnings"].append("Treatment arm data not available")

        fig.update_layout(
            height=800, title_text="Adverse Events Overview Dashboard",
            showlegend=False, template="plotly_white"
        )
        fig.update_xaxes(title_text="Number of Subjects", row=1, col=1)
        fig.update_xaxes(title_text="Grade", row=1, col=2)
        fig.update_xaxes(title_text="Number of Subjects", row=2, col=1)
        fig.update_xaxes(title_text="Treatment Arm", row=2, col=2)

        result["metadata"] = {
            "total_subjects": teae["USUBJID"].nunique(),
            "total_aes": len(teae),
            "subjects_with_ae": teae["USUBJID"].nunique(),
        }
        result["figure"] = fig
        result["success"] = True
    except Exception as e:
        result["errors"].append(f"Dashboard creation failed: {e}")
        result["figure"] = create_placeholder_figure("AE Overview", f"Error: {e}")
    return result

def create_ae_summary_table(ae: Optional[pd.DataFrame], dm: Optional[pd.DataFrame]) -> pd.DataFrame:
    """
    Robust AE summary:
      - Subjects with ≥1 TEAE
      - Subjects with ≥3 TEAE (AETOXGR numeric or AESEV textual)
      - Subjects with ≥1 SAE (AESER truthy variants)
      - Subjects with ≥1 Related AE (AEREL/AERELNS truthy variants)
    """
    try:
        if ae is None or ae.empty:
            return pd.DataFrame()

        df = ae.copy()
        df.columns = [str(c).strip().upper() for c in df.columns]

        def pick_col(cands: list[str]) -> Optional[str]:
            for c in cands:
                if c in df.columns:
                    return c
            for c in cands:
                alt = c.replace(" ", "")
                for col in df.columns:
                    if col.replace(" ", "") == alt:
                        return col
            return None

        usubjid_col = pick_col(["USUBJID", "SUBJECT", "SUBJECTID", "SUBJID"])
        if usubjid_col is None:
            study_col = pick_col(["STUDYID", "STUDY"])
            subj_col  = pick_col(["SUBJID", "SUBJECT", "SUBJECTID"])
            if study_col and subj_col:
                df["USUBJID"] = df[study_col].astype(str).str.strip() + "-" + df[subj_col].astype(str).str.strip()
                usubjid_col = "USUBJID"
            else:
                return pd.DataFrame({"Category": ["(AE missing USUBJID/SUBJID)"], "n (%)": ["—"]})

        teae_mask = df.get("TEAE", True)
        if isinstance(teae_mask, pd.Series):
            teae_mask = teae_mask.fillna(False)
        else:
            teae_mask = pd.Series([True] * len(df), index=df.index)
        teae = df.loc[teae_mask].copy()

        total_subjects = teae[usubjid_col].nunique()
        rows = [{"Category": "Subjects with ≥1 TEAE", "n (%)": f"{total_subjects} (100.0%)"}]

        # ≥3 TEAE via AETOXGR or AESEV
        grade_col = pick_col(["AETOXGR", "AESEV", "AESEVN", "CTCAE_GRADE", "CTCAEGRADE"])
        if grade_col:
            g = teae[grade_col].astype(str).str.strip().str.upper()
            sev_map = {
                "MILD": 1, "GRADE 1": 1, "G1": 1,
                "MODERATE": 2, "GRADE 2": 2, "G2": 2,
                "SEVERE": 3, "GRADE 3": 3, "G3": 3,
                "LIFE-THREATENING": 4, "GRADE 4": 4, "G4": 4,
                "DEATH": 5, "GRADE 5": 5, "G5": 5
            }
            numeric = pd.to_numeric(g, errors="coerce")
            need_map = numeric.isna()
            mapped = g[need_map].map(sev_map)
            sev = numeric.copy()
            sev[need_map] = mapped
            grade3p_subjects = teae.loc[sev.fillna(0) >= 3, usubjid_col].nunique()
            pct_g3 = (grade3p_subjects / total_subjects * 100) if total_subjects > 0 else 0
            rows.append({"Category": "Subjects with ≥3 TEAE", "n (%)": f"{grade3p_subjects} ({pct_g3:.1f}%)"})

        # SAE via AESER (truthy)
        sae_col = pick_col(["AESER", "SAE", "SAEFLAG", "SERIOUSYN"])
        if sae_col:
            s = teae[sae_col].astype(str).str.strip().str.upper()
            truthy = {"Y", "YES", "1", "TRUE", "T"}
            sae_subjects = teae.loc[s.isin(truthy), usubjid_col].nunique()
            pct_sae = (sae_subjects / total_subjects * 100) if total_subjects > 0 else 0
            rows.append({"Category": "Subjects with ≥1 SAE", "n (%)": f"{sae_subjects} ({pct_sae:.1f}%)"})

        # Related via AEREL/AERELNS
        rel_col = pick_col(["AEREL", "AERELNS", "AERELC", "AERELFL", "RELATEDYN"])
        if rel_col:
            r = teae[rel_col].astype(str).str.strip().str.upper()
            related_terms = {"RELATED", "PROBABLE", "POSSIBLE", "DEFINITE", "Y", "YES", "1", "TRUE", "T"}
            negative_terms = {"NOT RELATED", "UNRELATED", "NO", "N", "0", "FALSE", "F"}
            mask_rel = r.isin(related_terms) & (~r.isin(negative_terms))
            rel_subjects = teae.loc[mask_rel, usubjid_col].nunique()
            pct_rel = (rel_subjects / total_subjects * 100) if total_subjects > 0 else 0
            rows.append({"Category": "Subjects with ≥1 Related AE", "n (%)": f"{rel_subjects} ({pct_rel:.1f}%)"})

        return pd.DataFrame(rows)

    except Exception as e:
        logger.error(f"AE summary table creation failed: {e}")
        return pd.DataFrame()

def create_response_summary_table(rs: Optional[pd.DataFrame], tr: Optional[pd.DataFrame]) -> pd.DataFrame:
    try:
        if (rs is None or rs.empty) and (tr is not None and not tr.empty):
            rs = calculate_response_from_tr(tr)
        if rs is None or rs.empty or "RSSTRESC" not in rs.columns or "USUBJID" not in rs.columns:
            return pd.DataFrame()

        best = rs.groupby("USUBJID")["RSSTRESC"].first()
        counts = best.value_counts()
        total = len(best)

        out = []
        for resp in ["CR", "PR", "SD", "PD", "NE"]:
            n = counts.get(resp, 0)
            pct = (n / total * 100) if total > 0 else 0
            out.append({"Response": resp, "n": n, "%": f"{pct:.1f}%"})

        orr = counts.get("CR", 0) + counts.get("PR", 0)
        dcr = orr + counts.get("SD", 0)
        orr_pct = (orr / total * 100) if total > 0 else 0
        dcr_pct = (dcr / total * 100) if total > 0 else 0

        out.append({"Response": "---", "n": "---", "%": "---"})
        out.append({"Response": "ORR (CR + PR)", "n": orr, "%": f"{orr_pct:.1f}%"})
        out.append({"Response": "DCR (CR + PR + SD)", "n": dcr, "%": f"{dcr_pct:.1f}%"})
        return pd.DataFrame(out)
    except Exception as e:
        logger.error(f"Response summary table creation failed: {e}")
        return pd.DataFrame()

# -----------------------------------------------------------------------------
# Pages
# -----------------------------------------------------------------------------
def show_home_page():
    st.markdown("\n# 🏥 SDTM Oncology Analysis Dashboard\n", unsafe_allow_html=True)

    if not st.session_state.domains:
        st.info("👉 Please upload SDTM datasets using the 'Data Upload' section in the sidebar.")
        st.markdown("### 📚 About This Dashboard")
        st.write(
            """
            This interactive dashboard provides oncology-specific analysis of SDTM datasets including:
            - **Adverse Events**: TEAEs, grade distribution, top AEs, incidence by SOC and Arm
            - **Efficacy**: TR-derived responses, spider plot, simple PFS curve
            - **Data Quality**: Domain availability and missingness overview
            - **Downloads**: Execution log and summaries
            """
        )
        return

    dom = st.session_state.domains
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        if "DM" in dom and "USUBJID" in dom["DM"].columns:
            st.metric("Total Subjects", f"{dom['DM']['USUBJID'].nunique()}")
    with c2:
        if "AE" in dom:
            st.metric("Total AE Records", f"{len(dom['AE'])}")
    with c3:
        if "RS" in dom:
            st.metric("Response Assessments", f"{len(dom['RS'])}")
        elif "TR" in dom:
            st.metric("TR Assessments", f"{len(dom['TR'])}")
    with c4:
        st.metric("Domains Loaded", f"{len(dom)}")

    st.markdown("## 🗂️ Loaded Domains", unsafe_allow_html=True)
    info = []
    for k, df in dom.items():
        info.append({
            "Domain": k,
            "Records": len(df),
            "Subjects": df["USUBJID"].nunique() if "USUBJID" in df.columns else "N/A",
            "Variables": len(df.columns),
        })
    if info:
        st.dataframe(pd.DataFrame(info), use_container_width=True)

def show_data_upload_page():
    st.markdown("\n# 📁 Data Upload\n", unsafe_allow_html=True)
    st.write(
        """
        Upload your SDTM datasets.

        **Supported**  
        - SAS: `.sas7bdat` (requires `pyreadstat`), `.xpt`  
        - CSV: `.csv`, `.csv.gz`  
        - Excel: `.xlsx`, `.xls`

        *Tip:* Enter a sheet name for Excel if your data isn't in the first sheet.
        """
    )

    excel_sheet = st.text_input(
        "Excel sheet name (optional, leave blank for first sheet):",
        value=""
    )

    uploaded_files = st.file_uploader(
        "Choose SDTM files",
        accept_multiple_files=True,
        type=["sas7bdat", "xpt", "csv", "gz", "xlsx", "xls"],
    )

    if uploaded_files:
        st.info(f"Selected files: {', '.join(f.name for f in uploaded_files)}")

    if uploaded_files and st.button("🔄 Load Datasets", type="primary"):
        with st.spinner("Loading datasets..."):
            file_dict = {file.name: file for file in uploaded_files}
            loader = SDTMDataLoader(st.session_state.analysis_logger)
            sheet_arg: Optional[str] = excel_sheet.strip() or None

            domains = loader.load_from_uploaded_files(file_dict, sheet_name=sheet_arg)
            st.session_state.domains = domains

            if domains:
                st.success(f"✅ Successfully loaded {len(domains)} domain(s)")
                st.markdown("### Loaded Domains Summary")
                for domain, df in domains.items():
                    with st.expander(f"📊 {domain} – {len(df)} records"):
                        cols_preview = ", ".join([str(c) for c in df.columns.tolist()[:10]])
                        if len(df.columns) > 10:
                            cols_preview += "..."
                        st.write(f"**Variables:** {cols_preview}")
                        st.write(f"**Subjects:** {df['USUBJID'].nunique() if 'USUBJID' in df.columns else 'N/A'}")
                        st.dataframe(df.head(5), use_container_width=True)
            else:
                st.error("❌ No domains were successfully loaded")

        if st.session_state.analysis_logger.errors or st.session_state.analysis_logger.warnings:
            with st.expander("⚠️ View Loader Messages"):
                for w in st.session_state.analysis_logger.warnings:
                    st.warning(w)
                for e in st.session_state.analysis_logger.errors:
                    st.error(e)

def show_data_quality_page():
    st.markdown("\n# 📊 Data Quality Report\n", unsafe_allow_html=True)
    if not st.session_state.domains:
        st.warning("⚠️ No data loaded. Please upload datasets first.")
        return

    domains = st.session_state.domains
    st.markdown("### Domain Availability")
    expected = ["DM", "AE", "EX", "RS", "TR", "DS", "CM", "MH", "LB", "VS", "SV"]
    avail = []
    for d in expected:
        if d in domains:
            df = domains[d]
            avail.append({
                "Domain": d, "Status": "✅ Available", "Records": len(df),
                "Subjects": df["USUBJID"].nunique() if "USUBJID" in df.columns else "N/A",
                "Completeness": "100%"
            })
        else:
            avail.append({"Domain": d, "Status": "❌ Missing", "Records": 0, "Subjects": 0, "Completeness": "0%"})
    st.dataframe(pd.DataFrame(avail), use_container_width=True)

    st.markdown("### Missing Data Analysis")
    for dname, df in domains.items():
        with st.expander(f"📋 {dname} Missing Data"):
            if len(df) == 0:
                st.info("Domain is empty.")
                continue
            missing_pct = (df.isna().sum() / len(df) * 100).sort_values(ascending=False)
            missing_pct = missing_pct[missing_pct > 0]
            if not missing_pct.empty:
                fig = go.Figure(go.Bar(x=missing_pct.values, y=missing_pct.index, orientation="h", marker_color="indianred"))
                fig.update_layout(
                    title=f"{dname} – Variables with Missing Data",
                    xaxis_title="% Missing", yaxis_title="Variable",
                    height=max(300, int(len(missing_pct) * 25)),
                    template="plotly_white"
                )
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.success("✅ No missing data detected")

def show_adverse_events_page():
    st.markdown("\n# ⚠️ Adverse Events Analysis\n", unsafe_allow_html=True)
    if not st.session_state.domains:
        st.warning("⚠️ No data loaded. Please upload datasets first.")
        return

    domains = st.session_state.domains
    if "AE" not in domains:
        st.error("❌ AE domain not available. Cannot perform adverse events analysis.")
        return

    # AE debug helper to quickly see columns/sample
    with st.expander("🔎 AE debug (columns & sample)"):
        ae_df = domains.get("AE")
        if ae_df is not None:
            st.write("Columns:", list(ae_df.columns))
            st.write("Shape:", ae_df.shape)
            st.dataframe(ae_df.head(10), use_container_width=True)
        else:
            st.info("AE not loaded.")

    analysis_type = st.selectbox(
        "Select Analysis Type:",
        ["Overview Dashboard", "AE Summary Tables"]
    )

    if st.button("🔄 Generate Analysis", type="primary"):
        with st.spinner("Generating analysis..."):
            if analysis_type == "Overview Dashboard":
                result = create_ae_overview_dashboard(domains.get("AE"), domains.get("DM"), domains.get("EX"))
                if result["figure"] is not None:
                    st.plotly_chart(result["figure"], use_container_width=True)
                if result["metadata"]:
                    c1, c2, c3 = st.columns(3)
                    with c1:
                        st.metric("Total Subjects", result["metadata"].get("total_subjects", 0))
                    with c2:
                        st.metric("Subjects with AE", result["metadata"].get("subjects_with_ae", 0))
                    with c3:
                        st.metric("Total AEs", result["metadata"].get("total_aes", 0))
                if result["warnings"]:
                    with st.expander("⚠️ Warnings"):
                        for w in result["warnings"]:
                            st.warning(w)
                if result["errors"]:
                    with st.expander("❌ Errors"):
                        for e in result["errors"]:
                            st.error(e)

            elif analysis_type == "AE Summary Tables":
                ae_summary = create_ae_summary_table(domains.get("AE"), domains.get("DM"))
                if not ae_summary.empty:
                    st.markdown("### AE Summary Table")
                    st.dataframe(ae_summary, use_container_width=True)
                else:
                    st.info("Unable to generate summary table")

def show_efficacy_page():
    st.markdown("\n# 📈 Efficacy Analysis\n", unsafe_allow_html=True)
    if not st.session_state.domains:
        st.warning("⚠️ No data loaded. Please upload datasets first.")
        return

    domains = st.session_state.domains
    has_rs = "RS" in domains
    has_tr = "TR" in domains
    if not has_rs and not has_tr:
        st.error("❌ Neither RS nor TR domain available. Cannot perform efficacy analysis.")
        return

    analysis_type = st.selectbox(
        "Select Analysis Type:",
        ["Spider Plot", "Progression-Free Survival", "Response Summary Table"]
    )

    if st.button("🔄 Generate Analysis", type="primary"):
        with st.spinner("Generating analysis..."):
            if analysis_type == "Spider Plot":
                result = create_spider_plot(domains.get("TR"))
                if result["figure"] is not None:
                    st.plotly_chart(result["figure"], use_container_width=True)

            elif analysis_type == "Progression-Free Survival":
                pfs_df = calculate_pfs_data(domains.get("RS"), domains.get("DS"), domains.get("EX"), domains.get("DM"))
                if not pfs_df.empty:
                    result = create_km_curve(pfs_df)
                    if result["figure"] is not None:
                        st.plotly_chart(result["figure"], use_container_width=True)

                    st.markdown("### PFS Summary Statistics")
                    c1, c2, c3 = st.columns(3)
                    with c1:
                        st.metric("Total Subjects", len(pfs_df))
                    with c2:
                        st.metric("Events", int(pfs_df["EVENT"].sum()))
                    with c3:
                        st.metric("Median PFS (months)", f"{pfs_df['PFS_MONTHS'].median():.1f}")
                else:
                    st.error("Unable to calculate PFS data")

            elif analysis_type == "Response Summary Table":
                resp_tbl = create_response_summary_table(domains.get("RS"), domains.get("TR"))
                if not resp_tbl.empty:
                    st.markdown("### Response Summary")
                    st.dataframe(resp_tbl, use_container_width=True)
                else:
                    st.info("Unable to generate response summary")

def show_exposure_page():
    st.markdown("\n# 💊 Treatment Exposure Analysis\n", unsafe_allow_html=True)
    if not st.session_state.domains:
        st.warning("⚠️ No data loaded. Please upload datasets first.")
        return
    if "EX" not in st.session_state.domains:
        st.error("❌ EX domain not available. Cannot perform exposure analysis.")
        return

    ex = st.session_state.domains["EX"]
    dm = st.session_state.domains.get("DM")

    with st.spinner("Computing exposure metrics..."):
        result = create_exposure_dashboard(ex, dm)

    if result["warnings"]:
        for w in result["warnings"]:
            st.warning(w)
    if result["errors"]:
        for e in result["errors"]:
            st.error(e)

    if result["success"]:
        col1, col2 = st.columns(2)
        with col1:
            if result["figure_main"] is not None:
                st.plotly_chart(result["figure_main"], use_container_width=True)
        with col2:
            if result["figure_by_arm"] is not None:
                st.plotly_chart(result["figure_by_arm"], use_container_width=True)

        st.markdown("### Exposure Metrics (per subject)")
        st.dataframe(result["table"], use_container_width=True)

def show_prior_therapy_page():
    st.markdown("\n# 🔬 Prior Anticancer Therapy Analysis\n", unsafe_allow_html=True)
    if not st.session_state.domains:
        st.warning("⚠️ No data loaded. Please upload datasets first.")
        return

    mh = st.session_state.domains.get("MH")
    cm = st.session_state.domains.get("CM")
    if mh is None and cm is None:
        st.error("❌ MH and/or CM domains not available.")
        return

    with st.spinner("Analyzing prior therapies..."):
        result = create_prior_therapy_dashboard(mh, cm)

    if result["warnings"]:
        for w in result["warnings"]:
            st.warning(w)
    if result["errors"]:
        for e in result["errors"]:
            st.error(e)

    if result["success"]:
        if result["fig_categories"] is not None:
            st.plotly_chart(result["fig_categories"], use_container_width=True)

        col1, col2 = st.columns(2)
        with col1:
            st.markdown("### Per‑Subject Prior Therapy Flags")
            st.dataframe(result["per_subject_table"], use_container_width=True)
        with col2:
            if not result["top_table"].empty:
                st.markdown("### Top Prior Medications (from CM)")
                st.dataframe(result["top_table"], use_container_width=True)

def show_cross_domain_page():
    st.markdown("\n# 🔗 Cross‑Domain Relationship Analysis\n", unsafe_allow_html=True)
    if not st.session_state.domains:
        st.warning("⚠️ No data loaded. Please upload datasets first.")
        return

    ae = st.session_state.domains.get("AE")
    ex = st.session_state.domains.get("EX")
    rs = st.session_state.domains.get("RS")
    dm = st.session_state.domains.get("DM")

    tail_days = st.number_input(
        "Days after last dose to still count AE as 'on‑treatment':",
        min_value=0, max_value=120, value=30, step=5
    )

    with st.spinner("Computing cross‑domain relationships..."):
        result = create_cross_domain_dashboard(ae, ex, rs, dm, tail_days=int(tail_days))

    if result["warnings"]:
        for w in result["warnings"]:
            st.warning(w)
    if result["errors"]:
        for e in result["errors"]:
            st.error(e)

    col1, col2 = st.columns(2)
    with col1:
        if result["fig_arm"] is not None:
            st.plotly_chart(result["fig_arm"], use_container_width=True)
    with col2:
        if result["fig_rsp"] is not None:
            st.plotly_chart(result["fig_rsp"], use_container_width=True)

def show_patient_profiles_page():
    st.markdown("\n# 👤 Patient Profiles\n", unsafe_allow_html=True)
    if not st.session_state.domains:
        st.warning("⚠️ No data loaded. Please upload datasets first.")
        return

    dom = st.session_state.domains
    if "DM" not in dom:
        st.error("❌ DM domain required for patient profiles.")
        return

    dm = dom["DM"]
    if "USUBJID" not in dm.columns or dm.empty:
        st.error("❌ DM is missing USUBJID or has no records.")
        return

    all_subjects = dm["USUBJID"].dropna().astype(str).unique()
    st.markdown("### Select Subject for Profile")
    sid = st.selectbox("Subject ID:", sorted(all_subjects))

    if st.button("📄 Generate Profile", type="primary"):
        with st.spinner("Generating patient profile..."):
            st.markdown(f"### Patient Profile: {sid}")

            # Demographics
            try:
                subj_dm = dm[dm["USUBJID"].astype(str) == sid]
                if not subj_dm.empty:
                    st.markdown("#### Demographics")
                    c1, c2, c3, c4 = st.columns(4)
                    with c1:
                        st.metric("Age", subj_dm["AGE"].iloc[0] if "AGE" in subj_dm.columns else "N/A")
                    with c2:
                        st.metric("Sex", subj_dm["SEX"].iloc[0] if "SEX" in subj_dm.columns else "N/A")
                    with c3:
                        st.metric("Race", subj_dm["RACE"].iloc[0] if "RACE" in subj_dm.columns else "N/A")
                    with c4:
                        st.metric("Arm", subj_dm["ARM"].iloc[0] if "ARM" in subj_dm.columns else "N/A")
            except Exception as e:
                st.warning(f"Demographics view issue: {e}")

            # Subject AEs
            if "AE" in dom:
                try:
                    ae = dom["AE"]
                    if "USUBJID" in ae.columns:
                        subj_ae = ae[ae["USUBJID"].astype(str) == sid]
                        if not subj_ae.empty:
                            st.markdown("#### Adverse Events")
                            if all(c in subj_ae.columns for c in ["AETERM", "AESTDTC"]):
                                cols = [c for c in ["AETERM", "AESTDTC", "AETOXGR", "AESER", "AEREL"] if c in subj_ae.columns]
                                st.dataframe(subj_ae[cols], use_container_width=True)
                            else:
                                st.dataframe(subj_ae, use_container_width=True)
                except Exception as e:
                    st.warning(f"AE view issue: {e}")

            # Subject RS
            if "RS" in dom:
                try:
                    rs = dom["RS"]
                    if "USUBJID" in rs.columns:
                        subj_rs = rs[rs["USUBJID"].astype(str) == sid]
                        if not subj_rs.empty:
                            st.markdown("#### Response Assessments")
                            st.dataframe(subj_rs, use_container_width=True)
                except Exception as e:
                    st.warning(f"RS view issue: {e}")

def show_downloads_page():
    st.markdown("\n# 📥 Download Reports\n", unsafe_allow_html=True)
    if not st.session_state.domains:
        st.warning("⚠️ No data loaded. Please upload datasets first.")
        return

    st.markdown("### Available Downloads")
    c1, c2 = st.columns(2)

    with c1:
        st.markdown("#### 📊 Summary Statistics (Excel)")
        if st.button("Generate Excel Summary", use_container_width=True):
            with st.spinner("Generating Excel file..."):
                try:
                    output = io.BytesIO()
                    with pd.ExcelWriter(output, engine="openpyxl") as writer:
                        for domain, df in st.session_state.domains.items():
                            df.to_excel(writer, sheet_name=domain[:31], index=False)
                    output.seek(0)
                    st.download_button(
                        label="⬇️ Download Excel File",
                        data=output,
                        file_name=f"sdtm_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx",
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    )
                except Exception as e:
                    st.error(f"Excel generation failed: {e}")

    with c2:
        st.markdown("#### 📄 Execution Log (text)")
        if st.button("Generate Execution Log", use_container_width=True):
            log_text = st.session_state.analysis_logger.get_summary_text()
            st.download_button(
                label="⬇️ Download Log File",
                data=log_text,
                file_name=f"execution_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt",
                mime="text/plain",
            )

# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------
def main():
    if "analysis_logger" not in st.session_state:
        st.session_state.analysis_logger = AnalysisLogger()
    if "domains" not in st.session_state:
        st.session_state.domains = {}
    if "analysis_results" not in st.session_state:
        st.session_state.analysis_results = {}

    st.sidebar.title("📋 Navigation")
    page = st.sidebar.radio(
        "Select Section:",
        [
            "🏠 Home",
            "📁 Data Upload",
            "📊 Data Quality",
            "⚠️ Adverse Events",
            "📈 Efficacy Analysis",
            "💊 Treatment Exposure",
            "🔬 Prior Therapies",
            "🔗 Cross‑Domain Analysis",
            "👤 Patient Profiles",
            "📥 Download Reports",
        ],
    )

    if page == "🏠 Home":
        show_home_page()
    elif page == "📁 Data Upload":
        show_data_upload_page()
    elif page == "📊 Data Quality":
        show_data_quality_page()
    elif page == "⚠️ Adverse Events":
        show_adverse_events_page()
    elif page == "📈 Efficacy Analysis":
        show_efficacy_page()
    elif page == "💊 Treatment Exposure":
        show_exposure_page()
    elif page == "🔬 Prior Therapies":
        show_prior_therapy_page()
    elif page == "🔗 Cross‑Domain Analysis":
        show_cross_domain_page()
    elif page == "👤 Patient Profiles":
        show_patient_profiles_page()
    elif page == "📥 Download Reports":
        show_downloads_page()

if __name__ == "__main__":
    main()