# -*- coding: utf-8 -*-
# ENHANCED Patient Profile — SDTM SAS multi-uploader
# No CM panel, no synthetic example, no RS overlay/day marks
# AE: thin center line + start label (no "Adverse event:" prefix), ▲ toxicity, ◆ causality
# First/Last dose dark vlines + visit-wise vertical lines (from SV if present; else inferred)
# Author: Nilesh + M365 Copilot
# Last updated: 2026-01-31

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from datetime import datetime, timedelta
import re
from typing import Dict, List, Optional, Tuple

# ---------- Page Configuration ----------
st.set_page_config(page_title="ENHANCED Patient Profile", layout="wide", page_icon="🏥")

# ---------- Constants / Palette ----------
SAS_ORIGIN = datetime(1960, 1, 1)
GRID_DTICK_DAYS = 14  # vertical grid every N days for the date-axis
MAX_VISIT_VLINES = 25  # cap to avoid clutter

PALETTE = {
    "dose": "#1d4ed8",
    "timeline": {"screening": "#74c69d", "treatment": "#6c757d", "followup": "#e9c46a"},
    "ae_grade": {"1": "#ffd166", "2": "#fb8500", "3": "#ef233c", "4": "#9d0208", "UNK": "#8d99ae"},
    "ae_line": "#495057",                 # thin center line drawn on top of AE duration
    "ae_guideline": "rgba(0,0,0,0.08)",   # faint row guideline
    "lesions": ["#f77f00", "#1d3557", "#6a4c93", "#e63946", "#00a896", "#ff6b6b", "#4cc9f0", "#8338ec"],
    "sumdiam": "#2b2d42",
    "grid": "rgba(0,0,0,0.08)",
    # Causality colors (AEREL) for ◆ markers
    "ae_causality": {
        "RELATED": "#d62828",
        "PROBABLY RELATED": "#f77f00",
        "POSSIBLY RELATED": "#fcbf49",
        "UNLIKELY RELATED": "#adb5bd",
        "NOT RELATED": "#6c757d",
        "UNKNOWN": "#adb5bd"
    }
}

# ---------- Helpers ----------
def parse_date(val):
    """Parse ISO strings, pandas timestamps, or SAS numeric date (days since 1960-01-01)."""
    if val is None:
        return None
    if isinstance(val, (pd.Timestamp, datetime)):
        return pd.to_datetime(val)
    s = str(val).strip()
    if s == "" or s.upper() in {"NA", "NAN", "NONE"}:
        return None
    if isinstance(val, (int, float)) and not pd.isna(val):
        try:
            return SAS_ORIGIN + timedelta(days=int(val))
        except Exception:
            pass
    try:
        return pd.to_datetime(s.split("T")[0], errors="coerce")
    except Exception:
        return None

def as_py_dt(x):
    """Return native datetime for Plotly shapes/annotations (avoid pandas.Timestamp arithmetic)."""
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return None
    if isinstance(x, pd.Timestamp):
        return x.to_pydatetime()
    try:
        xdt = pd.to_datetime(x)
        return xdt.to_pydatetime() if isinstance(xdt, pd.Timestamp) else xdt
    except Exception:
        return x

def upper(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [c.upper() for c in df.columns]
    return df

def read_one(uploaded) -> Optional[pd.DataFrame]:
    """Read one file (XPT/SAS7BDAT/CSV/XLSX) and standardize columns (uppercase)."""
    if uploaded is None:
        return None
    name = uploaded.name.lower()
    try:
        if name.endswith(".xpt"):
            df = pd.read_sas(uploaded, format="xport")
        elif name.endswith(".sas7bdat"):
            df = pd.read_sas(uploaded, format="sas7bdat", encoding="latin1")
        elif name.endswith(".csv"):
            df = pd.read_csv(uploaded)
        elif name.endswith((".xlsx", ".xls")):
            df = pd.read_excel(uploaded)
        else:
            return None
        return upper(pd.DataFrame(df))
    except Exception as e:
        st.error(f"Error reading {uploaded.name}: {e}")
        return None

def infer_domain(file_name: str, df: pd.DataFrame) -> Optional[str]:
    """Infer SDTM domain from filename or DOMAIN column."""
    stem = re.sub(r"\.(xpt|sas7bdat|csv|xlsx|xls)$", "", file_name, flags=re.I).lower()
    for dom in ["dm", "ae", "ex", "tr", "sv", "tu"]:  # RS intentionally unused in visuals
        if re.search(rf"(?:^|[_\W]){dom}(?:[_\W]|$)", stem):
            return dom.upper()
    if "DOMAIN" in df.columns:
        vals = [str(v).upper() for v in df["DOMAIN"].dropna().unique().tolist()]
        if len(vals) == 1 and len(vals[0]) <= 4:
            return vals[0]
    return None

def collect_domains(files) -> Dict[str, pd.DataFrame]:
    """Read multiple files and return domain->DataFrame dict (concatenate repeats)."""
    domap: Dict[str, pd.DataFrame] = {}
    for up in files:
        df = read_one(up)
        if df is None or df.empty:
            continue
        dom = infer_domain(up.name, df)
        if not dom:
            continue
        domap[dom] = upper(pd.concat([domap[dom], df], ignore_index=True)) if dom in domap else df
    return domap

def first_nonnull(series):
    for x in series:
        if pd.notna(x):
            return x
    return None

def find_rfstdtc(domap: Dict[str, pd.DataFrame], usubjid: str) -> Optional[pd.Timestamp]:
    """RFSTDTC: prefer DM.RFSTDTC else earliest among EX/AE/TR dates."""
    if "DM" in domap and not domap["DM"].empty:
        dm = domap["DM"]
        if {"USUBJID", "RFSTDTC"}.issubset(dm.columns):
            cand = dm.loc[dm["USUBJID"] == usubjid, "RFSTDTC"]
            if not cand.empty:
                dt = parse_date(first_nonnull(cand))
                if dt is not None:
                    return pd.to_datetime(dt)
    date_cols = [("EX", "EXSTDTC"), ("AE", "AESTDTC"), ("TR", "TRDTC")]
    dts = []
    for dom, col in date_cols:
        if dom in domap and not domap[dom].empty and {"USUBJID", col}.issubset(domap[dom].columns):
            dd = domap[dom].loc[domap[dom]["USUBJID"] == usubjid, col].dropna().map(parse_date)
            dd = dd.dropna()
            if not dd.empty:
                dts.append(dd.min())
    return min(dts) if dts else None

def to_day(ser, anchor: Optional[pd.Timestamp]) -> pd.Series:
    ser = pd.to_datetime(ser.map(parse_date))
    if anchor is None:
        return pd.Series([np.nan]*len(ser), index=ser.index)
    return (ser - anchor).dt.days + 1

def get_patients(domap: Dict[str, pd.DataFrame]) -> List[str]:
    ids = set()
    for df in domap.values():
        if "USUBJID" in df.columns:
            ids.update([str(x) for x in df["USUBJID"].dropna().unique().tolist()])
    return sorted(ids)

def ae_color(grade_or_sev: str) -> str:
    g = (grade_or_sev or "").strip().upper()
    if g in {"4", "GRADE 4"}: return PALETTE["ae_grade"]["4"]
    if g in {"3", "GRADE 3"}: return PALETTE["ae_grade"]["3"]
    if g in {"2", "GRADE 2"}: return PALETTE["ae_grade"]["2"]
    if g in {"1", "GRADE 1"}: return PALETTE["ae_grade"]["1"]
    return PALETTE["ae_grade"]["UNK"]

def ae_causality_color(val: Optional[str]) -> str:
    v = (val or "UNKNOWN").strip().upper()
    return PALETTE["ae_causality"].get(v, PALETTE["ae_causality"]["UNKNOWN"])

def tr_lesions(tr_subj: pd.DataFrame) -> pd.DataFrame:
    """Per-lesion table (uses TRLNKID if present, else TRTESTCD as label)."""
    if tr_subj.empty or "TRDTC" not in tr_subj.columns:
        return pd.DataFrame()
    df = tr_subj.copy()
    df["DT"] = df["TRDTC"].map(parse_date)
    lesion_cols = [c for c in ["TRLNKID", "TRGRPID", "TRLNKGRP", "TRGRP"] if c in df.columns]
    if lesion_cols:
        lid = lesion_cols[0]
        df["LESION"] = df[lid].astype(str)
    else:
        if "TRTESTCD" in df.columns:
            df["LESION"] = df["TRTESTCD"].astype(str)
        else:
            df["LESION"] = "Lesion"
    df["VAL"] = pd.to_numeric(df["TRORRES"], errors="coerce")
    df = df.dropna(subset=["DT", "VAL"])
    return df[["DT", "LESION", "VAL"]].sort_values(["LESION", "DT"])

def tr_sumline(tr_subj: pd.DataFrame) -> pd.DataFrame:
    """Sum of diameters series; uses TRTESTCD='SUMDIAM' if available, else sums numeric TRORRES per date."""
    if tr_subj.empty or "TRDTC" not in tr_subj.columns:
        return pd.DataFrame()
    df = tr_subj.copy()
    df["DT"] = df["TRDTC"].map(parse_date)
    if "TRTESTCD" in df.columns and (df["TRTESTCD"].astype(str).str.upper() == "SUMDIAM").any():
        use = df[df["TRTESTCD"].astype(str).str.upper() == "SUMDIAM"][["DT", "TRORRES"]].copy()
        use["VALUE"] = pd.to_numeric(use["TRORRES"], errors="coerce")
        return use.dropna().groupby("DT", as_index=False)["VALUE"].first().sort_values("DT")
    tmp = df[["DT", "TRORRES"]].copy()
    tmp["VALUE"] = pd.to_numeric(tmp["TRORRES"], errors="coerce")
    return tmp.dropna().groupby("DT", as_index=False)["VALUE"].sum().sort_values("DT")

def safe_minmax(*series_list):
    vals = []
    for s in series_list:
        if s is None:
            continue
        ss = pd.to_datetime(pd.Series(s).map(parse_date)).dropna()
        if not ss.empty:
            vals.extend(ss.tolist())
    if not vals:
        return None, None
    return min(vals), max(vals)

# --- Visit line collector ---
def collect_visit_lines(domap: Dict[str, pd.DataFrame], usubjid: str) -> List[Tuple[datetime, str]]:
    """
    Prefer SV (Subject Visits): SVSTDTC/SVENDTC + VISIT label.
    Fallback: infer from domains where VISIT & date coexist (EX/AE/TR).
    Returns list of (datetime, label), capped to MAX_VISIT_VLINES.
    """
    visits: List[Tuple[datetime, str]] = []

    # SV preferred
    sv = domap.get("SV", pd.DataFrame())
    if not sv.empty and "USUBJID" in sv.columns:
        svp = sv[sv["USUBJID"].astype(str) == str(usubjid)].copy()
        if not svp.empty:
            if "SVSTDTC" in svp.columns:
                svp["DT"] = svp["SVSTDTC"].map(parse_date)
            elif "SVENDTC" in svp.columns:
                svp["DT"] = svp["SVENDTC"].map(parse_date)
            else:
                svp["DT"] = pd.NaT
            if "VISIT" in svp.columns:
                svp["VLBL"] = svp["VISIT"].astype(str)
            elif "SVVISIT" in svp.columns:
                svp["VLBL"] = svp["SVVISIT"].astype(str)
            else:
                svp["VLBL"] = "Visit"
            svp = svp.dropna(subset=["DT"])
            for _, r in svp.sort_values("DT").iterrows():
                visits.append((as_py_dt(r["DT"]), r["VLBL"]))

    # If no SV-based visits, try to infer from EX/AE/TR where VISIT and date coexist
    if not visits:
        for dom, dtc, vis in [("EX", "EXSTDTC", "VISIT"),
                              ("AE", "AESTDTC", "VISIT"),
                              ("TR", "TRDTC", "VISIT")]:
            df = domap.get(dom, pd.DataFrame())
            if df.empty or "USUBJID" not in df.columns or dtc not in df.columns:
                continue
            sub = df[df["USUBJID"].astype(str) == str(usubjid)].copy()
            if sub.empty:
                continue
            if vis in sub.columns:
                sub["DT"] = sub[dtc].map(parse_date)
                sub = sub.dropna(subset=["DT", vis])
                if not sub.empty:
                    # group by date+visit to dedup
                    g = sub.groupby(["DT", vis], as_index=False).size().sort_values("DT")
                    for _, r in g.iterrows():
                        visits.append((as_py_dt(r["DT"]), str(r[vis])))

    # De-duplicate and cap
    uniq, seen = [], set()
    for dt, lab in visits:
        if dt is None:
            continue
        key = (dt, lab)
        if key in seen:
            continue
        seen.add(key)
        uniq.append((dt, lab))
    return uniq[:MAX_VISIT_VLINES]

# ---------- Sidebar (uploads only; no synthetic example) ----------
st.sidebar.header("📂 Load SDTM Domains (SAS)")
uploads = st.sidebar.file_uploader(
    "Drag & drop all domains (.xpt/.sas7bdat). CSV/XLSX accepted for quick trials.",
    type=["xpt", "sas7bdat", "csv", "xlsx", "xls"], accept_multiple_files=True
)

if not uploads:
    st.info("Please upload SDTM domains (at least DM, EX, AE; TR optional) to render the patient profile.")
    st.stop()

domap = collect_domains(uploads)
if not domap:
    st.warning("No recognizable SDTM domains were found in the uploaded files.")
    st.stop()

# ---------- Patient selection ----------
patients = get_patients(domap)
if not patients:
    st.warning("No USUBJID found across uploaded domains.")
    st.stop()
selected_patient = st.sidebar.selectbox("Select Patient (USUBJID)", patients, index=0)

def subj(df, pid):
    if df is None or df.empty or pid is None:
        return pd.DataFrame()
    if "USUBJID" not in df.columns:
        return pd.DataFrame()
    return df[df["USUBJID"].astype(str) == str(pid)].copy()

ex = subj(domap.get("EX"), selected_patient)
ae = subj(domap.get("AE"), selected_patient)
tr = subj(domap.get("TR"), selected_patient)
dm = subj(domap.get("DM"), selected_patient)
# RS intentionally unused in visuals

rfstdtc = find_rfstdtc(domap, selected_patient)

# ---------- Date span & title ----------
all_date_cols = []
for df, col in [(ex, "EXSTDTC"), (ex, "EXENDTC"),
                (ae, "AESTDTC"), (ae, "AEENDTC"),
                (tr, "TRDTC")]:
    if not df.empty and col in df.columns:
        all_date_cols.extend(df[col].tolist())
study_start, study_end = safe_minmax(all_date_cols)
if study_start is None:
    study_start = rfstdtc
if study_end is None and rfstdtc is not None:
    study_end = rfstdtc + timedelta(days=60)
total_days = (study_end - study_start).days + 1 if study_start and study_end else None

st.title(f"ENHANCED Patient Profile • {selected_patient}")
subtitle = f"Study: {study_start.date() if study_start else 'N/A'} → {study_end.date() if study_end else 'N/A'}"
if total_days:
    subtitle += f" ({total_days} days)"
st.caption(subtitle)

# ---------- Tabs ----------
tab1, tab2, tab3 = st.tabs(["🧭 Detailed Timeline", "📉 Tumor Analysis", "🗃️ Raw Data"])

with tab1:
    # ----- 4-PANEL FIGURE -----
    fig = make_subplots(
        rows=4, cols=1, shared_xaxes=True, vertical_spacing=0.06,
        subplot_titles=(
            "1. Study Timeline & Milestones",
            "2. Drug Exposure Timeline",
            "3. Adverse Events (line + duration; ▲ toxicity, ◆ causality)",
            "4. Tumor Measurements (with % change)"
        ),
        row_heights=[0.15, 0.18, 0.37, 0.30]
    )

    # --- Vertical lines for First/Last Dose + Visit-wise lines ---
    # Identify last dose (prefer EXENDTC else EXSTDTC max)
    last_dose_date = None
    if not ex.empty:
        if "EXENDTC" in ex.columns and ex["EXENDTC"].notna().any():
            last_dose_date = pd.to_datetime(ex["EXENDTC"].map(parse_date)).dropna().max()
        else:
            last_dose_date = pd.to_datetime(ex["EXSTDTC"].map(parse_date)).dropna().max()

    rfstdtc_py = as_py_dt(rfstdtc)
    last_dose_py = as_py_dt(last_dose_date)

    # First/Last dose as dark vertical lines (black)
    if rfstdtc_py:
        fig.add_vline(x=rfstdtc_py, line_dash="dot", line_color="#111111", line_width=2)
        fig.add_annotation(x=rfstdtc_py, y=1.04, xref="x", yref="paper",
                           text=f"First Dose: {rfstdtc_py.date()}",
                           showarrow=False, font=dict(color="#111111"))
    if last_dose_py:
        fig.add_vline(x=last_dose_py, line_dash="dot", line_color="#111111", line_width=2)
        fig.add_annotation(x=last_dose_py, y=1.04, xref="x", yref="paper",
                           text=f"Last Dose: {last_dose_py.date()}",
                           showarrow=False, font=dict(color="#111111"))

    # Visit-wise vertical lines (SV preferred; else inferred from EX/AE/TR)
    visit_lines = collect_visit_lines(domap, selected_patient)
    for dt, lab in visit_lines:
        # avoid duplicating first/last dose line labels if same date
        if (rfstdtc_py and dt == rfstdtc_py) or (last_dose_py and dt == last_dose_py):
            continue
        fig.add_vline(x=dt, line_dash="solid", line_color="#444444", line_width=1)
        fig.add_annotation(x=dt, y=1.02, xref="x", yref="paper",
                           text=str(lab), showarrow=False, font=dict(color="#444444", size=10))

    # ---------------- Panel 1: Study phases ----------------
    if study_start and study_end:
        scr_end = rfstdtc or study_start
        trt_start = rfstdtc or study_start
        trt_end = last_dose_date or trt_start
        fu_start = trt_end

        # base rail
        fig.add_trace(go.Scatter(
            x=[study_start, study_end], y=["Timeline", "Timeline"],
            mode="lines", line=dict(color="#ced4da", width=16), hoverinfo="skip", showlegend=False
        ), row=1, col=1)

        # screening
        if study_start and scr_end and study_start < scr_end:
            fig.add_trace(go.Scatter(
                x=[study_start, scr_end], y=["Timeline", "Timeline"],
                mode="lines", line=dict(color=PALETTE["timeline"]["screening"], width=20),
                showlegend=False, hovertemplate=f"Screening: {study_start.date()} → {scr_end.date()}<extra></extra>"
            ), row=1, col=1)
            fig.add_annotation(row=1, col=1, x=as_py_dt(study_start + (scr_end - study_start)/2), y="Timeline",
                               text="Screening", showarrow=False, font=dict(color="black"))

        # treatment
        if trt_start and trt_end and trt_end >= trt_start:
            fig.add_trace(go.Scatter(
                x=[trt_start, trt_end], y=["Timeline", "Timeline"],
                mode="lines", line=dict(color=PALETTE["timeline"]["treatment"], width=20),
                showlegend=False, hovertemplate=f"Treatment: {trt_start.date()} → {trt_end.date()}<extra></extra>"
            ), row=1, col=1)
            fig.add_annotation(row=1, col=1, x=as_py_dt(trt_start + (trt_end - trt_start)/2), y="Timeline",
                               text="Treatment Phase", showarrow=False, font=dict(color="white"))

        # follow-up
        if fu_start and study_end and study_end > fu_start:
            fig.add_trace(go.Scatter(
                x=[fu_start, study_end], y=["Timeline", "Timeline"],
                mode="lines", line=dict(color=PALETTE["timeline"]["followup"], width=20),
                showlegend=False, hovertemplate=f"Follow-up: {fu_start.date()} → {study_end.date()}<extra></extra>"
            ), row=1, col=1)
            fig.add_annotation(row=1, col=1, x=as_py_dt(fu_start + (study_end - fu_start)/2), y="Timeline",
                               text="Follow-up", showarrow=False, font=dict(color="black"))

    # ---------------- Panel 2: Drug Exposure Timeline ----------------
    if not ex.empty and "EXSTDTC" in ex.columns:
        exp = ex.copy()
        exp["DT0"] = exp["EXSTDTC"].map(parse_date)
        exp = exp.dropna(subset=["DT0"]).sort_values("DT0")
        for _, r in exp.iterrows():
            label = r["EXTRT"] if "EXTRT" in r and pd.notna(r["EXTRT"]) else "Study Drug Infusion"
            fig.add_trace(
                go.Scatter(
                    x=[r["DT0"]], y=["Dose"], mode="markers",
                    marker=dict(symbol="diamond", size=18, color=PALETTE["dose"], line=dict(color="white", width=1)),
                    name="Dose (EX)", legendgroup="EX", showlegend=True,
                    hovertemplate=f"{label}<br>{pd.to_datetime(r['DT0']).date()}<extra></extra>"
                ),
                row=2, col=1
            )

    # ---------------- Panel 3: Adverse Events (line + band + symbols) ----------------
    if not ae.empty and "AESTDTC" in ae.columns:
        aep = ae.copy()
        aep["DT0"] = aep["AESTDTC"].map(parse_date)
        aep["DT1"] = aep["AEENDTC"].map(parse_date) if "AEENDTC" in aep.columns else aep["DT0"] + timedelta(days=2)
        aep["LABEL"] = aep.apply(lambda r: r["AETERM"] if "AETERM" in r and pd.notna(r["AETERM"])
                                 else (r["AEDECOD"] if "AEDECOD" in r and pd.notna(r["AEDECOD"]) else "AE"), axis=1)
        aep["GRADE"] = aep.apply(lambda r: r["AETOXGR"] if "AETOXGR" in r and pd.notna(r["AETOXGR"])
                                 else (r["AESEV"] if "AESEV" in r and pd.notna(r["AESEV"]) else ""), axis=1)
        aep["CAUSAL"] = aep["AEREL"] if "AEREL" in aep.columns else ""
        aep = aep.dropna(subset=["DT0"]).sort_values(["DT0", "LABEL"])

        for _, r in aep.iterrows():
            x0 = r["DT0"]
            x1 = r["DT1"]
            label = r["LABEL"]
            grade = str(r["GRADE"]).strip()
            bar_color = ae_color(grade)
            if pd.isna(x1) or x1 < x0:
                x1 = x0 + timedelta(days=2)

            # faint row guideline
            if study_start and study_end:
                fig.add_trace(
                    go.Scatter(
                        x=[study_start, study_end], y=[label, label],
                        mode="lines", line=dict(width=1, color=PALETTE["ae_guideline"]),
                        showlegend=False, hoverinfo="skip"
                    ),
                    row=3, col=1
                )

            # duration band (color by grade)
            fig.add_trace(
                go.Scatter(
                    x=[x0, x1], y=[label, label],
                    mode="lines", line=dict(width=14, color=bar_color),
                    name=f"AE: {label}", legendgroup="AE", showlegend=False,
                    hovertemplate=f"{label}<br>{grade if grade else 'Grade/Severity N/A'}"
                                  f"<br>{pd.to_datetime(x0).date()} → {pd.to_datetime(x1).date()}<extra></extra>"
                ),
                row=3, col=1
            )

            # center thin line
            fig.add_trace(
                go.Scatter(
                    x=[x0, x1], y=[label, label],
                    mode="lines", line=dict(width=2, color=PALETTE['ae_line']),
                    showlegend=False, hoverinfo="skip"
                ),
                row=3, col=1
            )

            # start-of-line label: just the AE term (no "Adverse event:")
            tag_x = x0 - timedelta(days=0.5) if study_start and x0 and x0 > study_start else x0
            fig.add_annotation(
                row=3, col=1, x=as_py_dt(tag_x), y=label,
                text=f"<b>{label}</b>",
                showarrow=False, xanchor="right",
                bgcolor="rgba(255,255,255,0.95)", bordercolor="#adb5bd", borderwidth=1, borderpad=3,
                font=dict(color="#212529", size=11)
            )

            # symbols on the line: ▲ toxicity at ~25%, ◆ causality at ~75%
            dur = (x1 - x0).days if isinstance(x1, datetime) and isinstance(x0, datetime) else 2
            p25 = x0 + timedelta(days=max(0.1, 0.25*max(1, dur)))
            p75 = x0 + timedelta(days=max(0.2, 0.75*max(1, dur)))
            tox_color = ae_color(grade)
            cau_color = ae_causality_color(r["CAUSAL"])

            fig.add_trace(
                go.Scatter(
                    x=[p25], y=[label], mode="markers",
                    marker=dict(symbol="triangle-up", size=11, color=tox_color, line=dict(color="white", width=1)),
                    name="AE Toxicity (▲)", legendgroup="AE_TOX", showlegend=False,
                    hovertemplate=f"Toxicity grade: {grade if grade else 'N/A'}<extra></extra>"
                ),
                row=3, col=1
            )
            if str(r["CAUSAL"]).strip():
                fig.add_trace(
                    go.Scatter(
                        x=[p75], y=[label], mode="markers",
                        marker=dict(symbol="diamond", size=11, color=cau_color, line=dict(color="white", width=1)),
                        name="AE Causality (◆)", legendgroup="AE_CAUS", showlegend=False,
                        hovertemplate=f"Causality: {str(r['CAUSAL'])}<extra></extra>"
                    ),
                    row=3, col=1
                )

    # ---------------- Panel 4: Tumor (per lesion + sum) ----------------
    def numeric_orres(df, col="TRORRES"):
        if df is None or df.empty or col not in df.columns:
            return df
        out = df.copy()
        out[col] = pd.to_numeric(out[col].astype(str).str.extract(r"([0-9.]+)")[0], errors="coerce")
        return out

    tr = numeric_orres(tr, "TRORRES")
    tr_line = tr_sumline(tr) if not tr.empty else pd.DataFrame()
    tr_les = tr_lesions(tr) if not tr.empty else pd.DataFrame()

    leg_seen = set()
    if not tr_les.empty:
        for i, (lesion, grp) in enumerate(tr_les.groupby("LESION")):
            if i >= 8:
                break
            grp = grp.sort_values("DT")
            base = grp.iloc[0]["VAL"]
            color = PALETTE["lesions"][i % len(PALETTE["lesions"])]
            name = f"{lesion} (BL {base:.1f}mm)"
            fig.add_trace(
                go.Scatter(
                    x=grp["DT"], y=grp["VAL"],
                    mode="lines+markers", line=dict(width=3, color=color),
                    marker=dict(size=9, color=color, line=dict(color="white", width=1)),
                    name=name if name not in leg_seen else None,
                    legendgroup=f"LESION_{i}"
                ),
                row=4, col=1
            )
            leg_seen.add(name)
            last = grp.iloc[-1]["VAL"]
            pct = (last - base) / base * 100 if base and base != 0 else np.nan
            fig.add_annotation(row=4, col=1, x=as_py_dt(grp["DT"].iloc[-1]), y=last,
                               text=f"{lesion}: {pct:+.1f}%", showarrow=True, arrowhead=2,
                               bgcolor="rgba(255,255,255,0.9)", bordercolor=color, borderwidth=1, borderpad=3)

    if isinstance(tr_line, pd.DataFrame) and not tr_line.empty:
        tr_line = tr_line.dropna(subset=["DT"]).sort_values("DT")
        fig.add_trace(
            go.Scatter(
                x=tr_line["DT"], y=tr_line["VALUE"],
                mode="lines+markers", line=dict(width=4, color=PALETTE["sumdiam"], dash="solid"),
                marker=dict(size=8, color=PALETTE["sumdiam"], line=dict(color="white", width=1)),
                name="Sum of Diameters", legendgroup="SUM"
            ),
            row=4, col=1
        )

    # ---------- Legend enrichers (no day marks, no RS) ----------
    fig.add_trace(go.Scatter(x=[None], y=[None], mode="markers",
                             marker=dict(symbol="diamond", size=14, color=PALETTE["dose"]),
                             name="Dose (EX)", showlegend=True, hoverinfo="skip"), row=2, col=1)
    for g, colr in [("Grade 1", PALETTE["ae_grade"]["1"]),
                    ("Grade 2", PALETTE["ae_grade"]["2"]),
                    ("Grade 3", PALETTE["ae_grade"]["3"]),
                    ("Grade 4", PALETTE["ae_grade"]["4"])]:
        fig.add_trace(go.Scatter(x=[None], y=[None], mode="lines",
                                 line=dict(width=10, color=colr),
                                 name=f"AE {g} (band color)", showlegend=True, hoverinfo="skip"), row=3, col=1)
    fig.add_trace(go.Scatter(x=[None], y=[None], mode="markers",
                             marker=dict(symbol="triangle-up", size=11, color="#6c757d"),
                             name="AE Toxicity (▲)", showlegend=True, hoverinfo="skip"), row=3, col=1)
    fig.add_trace(go.Scatter(x=[None], y=[None], mode="markers",
                             marker=dict(symbol="diamond", size=11, color="#6c757d"),
                             name="AE Causality (◆)", showlegend=True, hoverinfo="skip"), row=3, col=1)

    # ---------- Axes, grid, legend, summary ----------
    dtick_ms = GRID_DTICK_DAYS * 24 * 60 * 60 * 1000
    fig.update_xaxes(
        showgrid=True, gridcolor=PALETTE["grid"], tickangle=45, dtick=dtick_ms,
        range=[study_start - timedelta(days=2) if study_start else None,
               study_end + timedelta(days=2) if study_end else None]
    )
    for r in range(1, 5):
        fig.update_yaxes(showticklabels=False, showgrid=False, zeroline=False, row=r, col=1)

    fig.update_layout(
        height=1100, template="plotly_white",
        margin=dict(l=40, r=40, t=40, b=60),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="left", x=0,
                    bgcolor="rgba(255,255,255,0.85)", bordercolor="#dee2e6", borderwidth=1)
    )

    # Footer summary
    ex_n = len(ex) if not ex.empty else 0
    ae_n = len(ae) if not ae.empty else 0
    ae_unique = ae["AETERM"].dropna().nunique() if not ae.empty and "AETERM" in ae.columns else 0
    dur_days = total_days or ""
    sum_text = (f"<b>SUMMARY</b>: Infusions: {ex_n} | AEs: {ae_n} (≙ {ae_unique} unique) | "
                f"Period: {study_start.date() if study_start else 'N/A'} → "
                f"{study_end.date() if study_end else 'N/A'} ({dur_days} days)")
    fig.add_annotation(
        x=0.5, xref="paper", y=-0.065, yref="paper",
        text=sum_text, showarrow=False,
        bgcolor="rgba(248,249,250,0.95)", bordercolor="#adb5bd", borderwidth=1, borderpad=8,
        font=dict(size=12, color="#212529")
    )

    st.plotly_chart(fig, use_container_width=True)

# ---------- Tumor Analysis Tab ----------
with tab2:
    st.subheader("Waterfall: % Change from Baseline (Sum of Diameters)")
    if not tr.empty:
        tr_line = tr_sumline(tr)
        if isinstance(tr_line, pd.DataFrame) and not tr_line.empty:
            tr_line = tr_line.dropna(subset=["DT"]).sort_values("DT")
            base = tr_line.iloc[0]["VALUE"]
            last = tr_line.iloc[-1]["VALUE"]
            if base and base != 0 and pd.notna(base):
                pct = ((last - base) / base) * 100.0
                c1, c2 = st.columns([1, 2])
                c1.metric("Total Change", f"{pct:+.1f}%", delta_color="inverse")
                figw = go.Figure(go.Bar(
                    x=[selected_patient], y=[pct],
                    marker_color='green' if pct <= -30 else 'red' if pct >= 20 else 'gray'
                ))
                figw.add_hline(y=-30, line_dash="dash", line_color="green", annotation_text="PR Threshold")
                figw.add_hline(y=20, line_dash="dash", line_color="red", annotation_text="PD Threshold")
                figw.update_layout(title="Tumor Response Waterfall", yaxis_title="% Change", template="plotly_white")
                c2.plotly_chart(figw, use_container_width=True)
            else:
                st.info("Baseline tumor burden is missing or zero; cannot compute % change.")
        else:
            st.info("TR data not available for tumor analysis.")
    else:
        st.info("TR domain was not provided.")

# ---------- Raw Data Tab ----------
with tab3:
    st.subheader("Filtered SDTM Data for Medical Review")
    def show_df(title, df):
        if df is not None and not df.empty:
            st.write(title, df)
    show_df("DM", dm)
    show_df("EX", ex)
    show_df("AE", ae)
    show_df("TR", tr)