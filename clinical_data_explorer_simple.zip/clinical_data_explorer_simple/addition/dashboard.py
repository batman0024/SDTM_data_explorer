# app.py
# Clinical Trial Dashboard (SDTM) — Streamlit
# - Recursive/iterative loader for SAS7BDAT/XPT with multi-encoding tries
# - Preview-then-full read strategy + pandas.read_sas fallback
# - gzip support
# - **Bytes-safe sanitization**: decode bytes→str, coerce numerics (prevents Plotly JSON errors)
# - Detailed debug table
# - Futuristic dark UI + safe KPI block

import streamlit as st
import pandas as pd
import numpy as np

import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots

import tempfile
import gzip
import io
import warnings
from typing import Dict, Any, Tuple, Optional, List

warnings.filterwarnings("ignore")

# -----------------------------
# App Config & Styling
# -----------------------------
st.set_page_config(
    page_title="Clinical Dashboard (SDTM)",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
      .main { background: #0f172a; }
      .block-container { padding-top: 1rem; padding-bottom: 2rem; }
      .stMetric {
        background: #1e293b; padding: 12px; border-radius: 10px;
        border-left: 5px solid #06b6d4; color: white;
        box-shadow: 0 0 12px rgba(6, 182, 212, 0.15);
      }
      h1, h2, h3 { color: #06b6d4 !important; font-family: 'Segoe UI', sans-serif; }
      div[data-testid="stExpander"] { border: 1px solid #334155; border-radius: 10px; }
      code { font-size: 0.85rem; }
    </style>
    """,
    unsafe_allow_html=True,
)

# -----------------------------
# Encoding helpers
# -----------------------------
COMMON_ENCODING_OPTIONS = {
    "Auto (let reader decide)": None,
    "UTF-8": "utf-8",
    "Latin-1 (ISO-8859-1)": "latin1",
    "Windows-1252": "windows-1252",
}

def parse_encoding_candidates(primary: Optional[str], advanced_hint: Optional[str]) -> List[Optional[str]]:
    """
    Build a list of encodings to try.
    Order:
      1) primary selection (may be None for auto)
      2) parsed encodings from free-text hint (split by , / | ; whitespace)
      3) safe fallbacks: utf-8, latin1, windows-1252
    Dedup while preserving order.
    """
    candidates: List[Optional[str]] = []

    def add(enc):
        if enc not in candidates:
            candidates.append(enc)

    add(primary)
    if advanced_hint:
        tmp = advanced_hint
        for sep in [",", "/", "|", ";"]:
            tmp = tmp.replace(sep, " ")
        for p in tmp.split():
            p = p.strip()
            if p:
                add(p)
    for fb in ["utf-8", "latin1", "windows-1252"]:
        add(fb)
    return candidates

# -----------------------------
# Bytes→str sanitizer
# -----------------------------
BYTES_TYPES = (bytes, bytearray, np.bytes_)

def _decode_bytes_cell(v, encodings=("utf-8", "latin1", "windows-1252")):
    if isinstance(v, BYTES_TYPES):
        for enc in encodings:
            try:
                return v.decode(enc)
            except Exception:
                continue
        # last resort: repr
        return repr(v)
    return v

def sanitize_dataframe(df: pd.DataFrame, domain: Optional[str] = None) -> pd.DataFrame:
    """
    - Decode any bytes-like objects in object columns to strings.
    - Coerce expected numeric columns to numeric (errors='coerce').
    - Ensure key categorical columns are strings.
    """
    if df is None or df.empty:
        return df
    df = df.copy()

    # 1) Decode any bytes objects in object columns
    for c in df.columns:
        if df[c].dtype == object:
            # Only apply if there is any bytes-like value
            ser = df[c]
            if ser.map(lambda x: isinstance(x, BYTES_TYPES)).any():
                df[c] = ser.map(_decode_bytes_cell)

    # 2) Domain-specific coercions
    def to_num(col):
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    def to_str(col):
        if col in df.columns:
            df[col] = df[col].astype(str)

    dom = (domain or "").upper()

    if dom == "VS":
        to_str("VISIT"); to_str("VSTESTCD")
        to_num("VSORRES")

    elif dom == "AE":
        to_str("VISIT"); to_str("AETERM"); to_str("AESEV"); to_str("AEREL")
        to_num("AESTDY"); to_num("ASTDY"); to_num("AETOXGR")

    elif dom == "EX":
        to_str("EPOCH"); to_str("EXTRT")
        to_num("EXDOSE"); to_num("COMPLIANCE")

    elif dom == "LB":
        to_str("VISIT"); to_str("LBTESTCD")
        to_num("LBSTRESN"); to_num("VAL")

    # 3) Generic safety for common axes/labels
    for c in ["VISIT", "EPOCH", "AETERM", "AESEV", "AEREL", "LBTESTCD", "EXTRT"]:
        if c in df.columns and df[c].dtype == object:
            df[c] = df[c].astype(str)

    return df

# -----------------------------
# Recursive/Iterative Robust Loader
# -----------------------------
@st.cache_data(show_spinner=False)
def load_table(
    uploaded_file,
    *,
    primary_encoding: Optional[str],
    advanced_hint: Optional[str],
    row_preview: int = 50,
) -> Tuple[Optional[pd.DataFrame], Dict[str, Any]]:
    """
    Robust loader for SAS7BDAT / XPT / CSV:

    Strategy:
    1) Read bytes; handle .gz if needed.
    2) Sniff header: if it looks like XPT (SAS v5 transport), try XPT first; otherwise SAS7BDAT first.
    3) For SAS7BDAT:
       - Iterate encodings: [primary, user hints..., utf-8, latin1, windows-1252]
       - For each encoding:
           a) pyreadstat preview (row_limit=row_preview) → b) pyreadstat full
           c) pandas.read_sas preview/full with same encoding
    4) For XPT:
       - pyreadstat preview/full; fall back to pandas.read_sas(format='xport')
    5) Return DataFrame + detailed attempts log.
    """
    info: Dict[str, Any] = {"attempts": []}

    try:
        import pyreadstat
    except Exception as e:
        info.update(success=False, name=getattr(uploaded_file, "name", "unknown"), error=f"pyreadstat import failed: {e}")
        return None, info

    name = uploaded_file.name
    lower = name.lower()

    # Read raw bytes
    raw = uploaded_file.read()
    uploaded_file.seek(0)
    info["name"] = name
    info["size_bytes"] = len(raw)
    if not raw or len(raw) < 16:
        info.update(success=False, error="File seems empty or corrupted (bytes < 16).")
        return None, info

    # If gzipped, decompress
    if lower.endswith(".gz"):
        try:
            raw = gzip.decompress(raw)
            info["gzipped"] = True
            info["decompressed_bytes"] = len(raw)
        except Exception as e:
            info.update(success=False, error=f"Could not decompress gzip: {e}")
            return None, info
    else:
        info["gzipped"] = False

    # Sniff header for XPT signature
    head = raw[:128]
    head_text = head.decode("ascii", "ignore")
    looks_xpt = (b"HEADER RECORD*******" in head) or ("XPORT" in head_text)
    info["header_preview_ascii"] = head_text[:80]
    info["looks_xpt"] = bool(looks_xpt)

    # --- helpers ------------------------------------------------------------
    def _write_temp(suffix: str):
        f = tempfile.NamedTemporaryFile(delete=False, suffix="." + suffix)
        f.write(raw)
        f.flush()
        return f

    def _attempt_pyreadstat_sas7bdat(path: str, encoding: Optional[str], limit: Optional[int]):
        try:
            kw = {}
            if encoding:
                kw["encoding"] = encoding
            if limit is not None:
                kw["row_limit"] = limit
            df, _ = pyreadstat.read_sas7bdat(path, **kw)
            return df, None, "pyreadstat"
        except Exception as e:
            return None, repr(e), "pyreadstat"

    def _attempt_pyreadstat_xpt(path: str, limit: Optional[int]):
        try:
            kw = {}
            if limit is not None:
                kw["row_limit"] = limit
            df, _ = pyreadstat.read_xport(path, **kw)
            return df, None, "pyreadstat"
        except Exception as e:
            return None, repr(e), "pyreadstat"

    def _attempt_pandas_read_sas(path: str, fmt: str, encoding: Optional[str], limit: Optional[int]):
        try:
            if fmt == "sas7bdat":
                df = pd.read_sas(path, format="sas7bdat", encoding=encoding)
            else:
                df = pd.read_sas(path, format="xport")
            if limit is not None:
                df = df.head(limit)
            return df, None, "pandas"
        except Exception as e:
            return None, repr(e), "pandas"

    def _log(format_kind: str, reader: str, encoding: Optional[str], phase: str, error: Optional[str]):
        info["attempts"].append({
            "format": format_kind, "reader": reader, "encoding": encoding, "phase": phase, "error": error
        })

    # --- CSV short-circuit --------------------------------------------------
    if lower.endswith(".csv"):
        try:
            df = pd.read_csv(io.BytesIO(raw))
            info.update(success=True, success_format="csv", used_encoding=None)
            _log("csv", "pandas", None, "full", None)
            return df, info
        except Exception as e:
            _log("csv", "pandas", None, "full", repr(e))
            # continue to SAS path

    # --- Build tries list ---------------------------------------------------
    encodings_to_try = parse_encoding_candidates(primary_encoding, advanced_hint)
    info["encodings_considered"] = encodings_to_try

    try_orders = [("xpt",), ("sas7bdat",)] if looks_xpt else [("sas7bdat",), ("xpt",)]
    last_err = None

    # --- Core attempts ------------------------------------------------------
    for (fmt,) in try_orders:
        if fmt == "xpt":
            tf = _write_temp("xpt"); path = tf.name
            # pyreadstat preview/full
            df, err, rdr = _attempt_pyreadstat_xpt(path, limit=50)
            _log("xpt", rdr, None, "preview", err)
            if err is None and isinstance(df, pd.DataFrame):
                df, err, rdr = _attempt_pyreadstat_xpt(path, limit=None)
                _log("xpt", rdr, None, "full", err)
                if err is None and isinstance(df, pd.DataFrame):
                    info.update(success=True, success_format="xpt", used_encoding=None)
                    return df, info
            # pandas fallback
            df, err, rdr = _attempt_pandas_read_sas(path, fmt="xport", encoding=None, limit=50)
            _log("xpt", rdr, None, "preview", err)
            if err is None and isinstance(df, pd.DataFrame):
                df, err, rdr = _attempt_pandas_read_sas(path, fmt="xport", encoding=None, limit=None)
                _log("xpt", rdr, None, "full", err)
                if err is None and isinstance(df, pd.DataFrame):
                    info.update(success=True, success_format="xpt", used_encoding=None)
                    return df, info
            last_err = err

        else:  # sas7bdat
            tf = _write_temp("sas7bdat"); path = tf.name
            for enc in encodings_to_try:
                # pyreadstat preview
                df, err, rdr = _attempt_pyreadstat_sas7bdat(path, encoding=enc, limit=50)
                _log("sas7bdat", rdr, enc, "preview", err)
                if err is None and isinstance(df, pd.DataFrame):
                    # full
                    df, err, rdr = _attempt_pyreadstat_sas7bdat(path, encoding=enc, limit=None)
                    _log("sas7bdat", rdr, enc, "full", err)
                    if err is None and isinstance(df, pd.DataFrame):
                        info.update(success=True, success_format="sas7bdat", used_encoding=enc)
                        return df, info

                # pandas preview/full
                df, err, rdr = _attempt_pandas_read_sas(path, fmt="sas7bdat", encoding=enc, limit=50)
                _log("sas7bdat", rdr, enc, "preview", err)
                if err is None and isinstance(df, pd.DataFrame):
                    df, err, rdr = _attempt_pandas_read_sas(path, fmt="sas7bdat", encoding=enc, limit=None)
                    _log("sas7bdat", rdr, enc, "full", err)
                    if err is None and isinstance(df, pd.DataFrame):
                        info.update(success=True, success_format="sas7bdat", used_encoding=enc)
                        return df, info
                last_err = err

    info.update(success=False, error=f"All reader attempts failed. Last error: {last_err}")
    return None, info

# -----------------------------
# Domain inference
# -----------------------------
def infer_domain_name(filename: str) -> str:
    """Heuristic domain detector based on filename."""
    stem = (
        filename.rsplit("/", 1)[-1]
        .rsplit("\\", 1)[-1]
        .rsplit(".", 1)[0]
        .upper()
    )
    for dom in ("AE", "VS", "EX", "LB", "DM"):
        if stem == dom or stem.endswith("/" + dom) or stem.endswith("_" + dom) or stem.endswith("-" + dom) or stem.endswith(dom):
            return dom
    return stem  # fallback

# -----------------------------
# Plotting helpers (unchanged)
# -----------------------------
def get_color_map():
    return {
        "MILD": "#10b981",
        "MODERATE": "#f59e0b",
        "SEVERE": "#ef4444",
        "POSSIBLE": "#3b82f6",
        "PROBABLE": "#f59e0b",
        "UNLIKELY": "#64748b",
    }

def plot_vitals_ae_overlay(vs_df: pd.DataFrame, ae_df: pd.DataFrame):
    fig = make_subplots(specs=[[{"secondary_y": True}]])
    if isinstance(ae_df, pd.DataFrame) and not ae_df.empty and "VISIT" in ae_df.columns:
        ae_counts = ae_df.groupby("VISIT", dropna=False).size().reset_index(name="count")
        fig.add_trace(
            go.Scatter(
                x=ae_counts["VISIT"], y=ae_counts["count"], fill="tozeroy",
                name="AE Count", line=dict(color="#f59e0b", dash="dash"), opacity=0.25
            ),
            secondary_y=True,
        )
    if isinstance(vs_df, pd.DataFrame) and not vs_df.empty and {"VISIT","VSTESTCD","VSORRES"}.issubset(vs_df.columns):
        vsc = vs_df.copy()
        vsc["VSTESTCD"] = vsc["VSTESTCD"].astype(str).str.upper()
        for test, color in zip(["SYSBP","DIABP","HR"], ["#ef4444","#3b82f6","#10b981"]):
            sub = vsc[vsc["VSTESTCD"] == test]
            if not sub.empty:
                fig.add_trace(go.Scatter(
                    x=sub["VISIT"].astype(str), y=pd.to_numeric(sub["VSORRES"], errors="coerce"),
                    name=test, line=dict(color=color, width=3), mode="lines+markers"
                ))
    fig.update_layout(template="plotly_dark", height=350, title="Vital Signs Trends with AE Overlay",
                      paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", legend_orientation="h")
    fig.update_yaxes(title_text="Vitals")
    fig.update_yaxes(title_text="AE Count", secondary_y=True)
    return fig

def plot_weight(vs_df: pd.DataFrame):
    if not isinstance(vs_df, pd.DataFrame) or vs_df.empty: return go.Figure()
    if not {"VISIT","VSTESTCD","VSORRES"}.issubset(vs_df.columns): return go.Figure()
    sub = vs_df.copy()
    sub["VSTESTCD"] = sub["VSTESTCD"].astype(str).str.upper()
    sub = sub[sub["VSTESTCD"].isin(["WEIGHT","WT"])]
    if sub.empty: return go.Figure()
    sub["VSORRES"] = pd.to_numeric(sub["VSORRES"], errors="coerce")
    return px.line(sub, x="VISIT", y="VSORRES", template="plotly_dark", markers=True, title="Weight Trend from Baseline")

def plot_exposure_compliance(ex_df: pd.DataFrame):
    fig = make_subplots(specs=[[{"secondary_y": True}]])
    if isinstance(ex_df, pd.DataFrame) and not ex_df.empty:
        xvals = ex_df["EPOCH"] if "EPOCH" in ex_df else (ex_df["EXTRT"] if "EXTRT" in ex_df else ex_df.index.astype(str))
        if "EXDOSE" in ex_df:
            fig.add_trace(go.Bar(x=xvals.astype(str), y=pd.to_numeric(ex_df["EXDOSE"], errors="coerce"),
                                 name="Actual Dose (mg)", marker_color="#06b6d4"))
        if "COMPLIANCE" in ex_df:
            fig.add_trace(go.Scatter(x=xvals.astype(str), y=pd.to_numeric(ex_df["COMPLIANCE"], errors="coerce"),
                                     name="Compliance %", line=dict(color="#10b981", width=3),
                                     mode="lines+markers"), secondary_y=True)
    fig.update_layout(template="plotly_dark", height=350, title="Exposure & Compliance by Epoch")
    fig.update_yaxes(title_text="Dose (mg)")
    fig.update_yaxes(title_text="Compliance (%)", secondary_y=True, range=[0,110])
    return fig

def plot_ae_timeline(ae_df: pd.DataFrame):
    colors = get_color_map()
    if not isinstance(ae_df, pd.DataFrame) or ae_df.empty: return go.Figure()
    xcol = "AESTDY" if "AESTDY" in ae_df.columns else ("ASTDY" if "ASTDY" in ae_df.columns else None)
    if xcol is None: return go.Figure()
    text = ae_df["AETERM"].astype(str)
    if "AETOXGR" in ae_df.columns:
        text = text + " (G" + ae_df["AETOXGR"].astype(str) + ")"
    fig = px.scatter(
        ae_df, x=xcol, y="AETERM",
        color=("AESEV" if "AESEV" in ae_df.columns else None),
        color_discrete_map=colors,
        symbol=("AESEV" if "AESEV" in ae_df.columns else None),
        hover_data=[c for c in ["AETOXGR","AEREL","VISIT"] if c in ae_df.columns],
        text=text
    )
    fig.update_traces(textposition="top center", marker_size=12)
    fig.update_layout(template="plotly_dark", height=400, title="AE Timeline with Severity & Causality",
                      xaxis_title="Study Day", legend_orientation="h")
    fig.update_xaxes(showgrid=True, gridwidth=1, gridcolor="#334155")
    return fig

# -----------------------------
# Sidebar: Upload & Options
# -----------------------------
with st.sidebar:
    st.header("📂 Upload SDTM Domains")
    uploads = st.file_uploader(
        "Upload SAS7BDAT/XPT/CSV files (VS, AE, EX, LB)",
        type=["sas7bdat", "xpt", "csv", "sas7bdat.gz", "xpt.gz"],
        accept_multiple_files=True,
    )
    primary_enc_label = st.selectbox("SAS encoding (common)", options=list(COMMON_ENCODING_OPTIONS.keys()), index=0)
    primary_enc = COMMON_ENCODING_OPTIONS[primary_enc_label]
    enc_hint_adv = st.text_input("Advanced: additional encodings (optional)", placeholder="utf-8 latin1 windows-1252")
    st.caption("Tip: Provide one or more encodings separated by space/comma. Filenames containing AE/VS/EX/LB help auto-detect domains.")

# -----------------------------
# Header
# -----------------------------
st.markdown(
    """
<h1 style='text-align:center;'>Clinical Trial Dashboard</h1>
<h3 style='text-align:center; color:#94a3b8;'>Subject-level Explorer (SDTM)</h3>
""",
    unsafe_allow_html=True,
)
st.markdown("---")

# -----------------------------
# Load Data (+ bytes-safe sanitize) & Debug
# -----------------------------
vs = ae = ex = lb = pd.DataFrame()
debug_rows = []

if uploads:
    domain_frames: dict[str, pd.DataFrame] = {}
    for f in uploads:
        df, info = load_table(f, primary_encoding=primary_enc, advanced_hint=enc_hint_adv)
        debug_rows.append({
            "file": info.get("name"),
            "size_bytes": info.get("size_bytes"),
            "gzipped": info.get("gzipped"),
            "looks_xpt": info.get("looks_xpt"),
            "success": info.get("success"),
            "success_format": info.get("success_format"),
            "used_encoding": info.get("used_encoding"),
            "encodings_considered": info.get("encodings_considered"),
            "error": info.get("error"),
            "attempts": info.get("attempts"),
            "header_preview_ascii": (info.get("header_preview_ascii") or "")[:80],
        })
        if df is None or (isinstance(df, pd.DataFrame) and df.empty):
            st.warning(f"{info.get('name')}: could not be parsed or is empty.")
            continue

        # --- sanitize to avoid Plotly bytes serialization errors ---
        dom = infer_domain_name(f.name)
        dom_key = dom if dom in {"AE","VS","EX","LB"} else None
        df = sanitize_dataframe(df, domain=dom_key)

        domain_frames[dom] = df

    # Map domains we visualize
    vs = domain_frames.get("VS", pd.DataFrame())
    ae = domain_frames.get("AE", pd.DataFrame())
    ex = domain_frames.get("EX", pd.DataFrame())
    lb = domain_frames.get("LB", pd.DataFrame())

# -----------------------------
# Debug Panel
# -----------------------------
with st.expander("🔧 Debug: Uploaded file signatures & read attempts", expanded=False):
    if debug_rows:
        dbg_df = pd.DataFrame(debug_rows)
        st.dataframe(dbg_df, use_container_width=True, hide_index=True)
        st.caption(
            "Review 'attempts' per file to see which (format, reader, encoding, phase) failed/succeeded. "
            "If looks_xpt=True but SAS7BDAT attempts fail (and XPT succeeds), the file is XPT mislabeled as .sas7bdat."
        )

# -----------------------------
# Demo toggle if nothing uploaded/recognized
# -----------------------------
use_demo = False
if (vs.empty and ae.empty and ex.empty and lb.empty):
    use_demo = st.toggle("Use demo data (no uploads)", value=True)

if use_demo:
    visits = ["Screening", "Baseline", "Week 2", "Week 4", "Week 6", "Week 8", "Week 12"]
    vs = pd.concat(
        [
            pd.DataFrame({"VISIT": visits, "VSTESTCD": "SYSBP", "VSORRES": [120, 118, 115, 114, 115, 116, 118]}),
            pd.DataFrame({"VISIT": visits, "VSTESTCD": "DIABP", "VSORRES": [78, 79, 75, 74, 75, 74, 76]}),
            pd.DataFrame({"VISIT": visits, "VSTESTCD": "HR", "VSORRES": [74, 76, 74, 72, 73, 72, 74]}),
            pd.DataFrame({"VISIT": visits, "VSTESTCD": "WEIGHT", "VSORRES": [70.0, 70.2, 70.8, 71.1, 71.5, 71.6, 72.8]}),
        ],
        ignore_index=True,
    )

    lb = pd.DataFrame(
        {"VISIT": ["Baseline", "Week 2", "Week 4", "Week 6", "Week 8", "Week 12"],
         "VAL": [13.0, 13.2, 13.5, 13.8, 14.0, 14.2]}
    )

    ae = pd.DataFrame(
        {"AETERM": ["Headache", "Nausea", "Fatigue", "Dizziness", "Insomnia"],
         "SOC": ["Nervous system", "Gastrointestinal", "General", "Nervous system", "Psychiatric"],
         "AESTDY": [3, 12, 28, 45, 78],
         "AESEV": ["MILD", "MILD", "MODERATE", "MILD", "MILD"],
         "AETOXGR": [1, 1, 2, 1, 1],
         "AEREL": ["POSSIBLE", "PROBABLE", "POSSIBLE", "UNLIKELY", "POSSIBLE"],
         "VISIT": ["Week 2", "Week 2", "Week 4", "Week 6", "Week 12"]}
    )

    ex = pd.DataFrame(
        {"EPOCH": ["Wk 1-2", "Wk 3-4", "Wk 5-6", "Wk 7-8", "Wk 9-10", "Wk 11-12"],
         "EXDOSE": [90, 85, 95, 92, 98, 90],
         "COMPLIANCE": [100, 98, 100, 96, 100, 100]}
    )

# -----------------------------
# KPI Ribbon (safe, no nested f-strings)
# -----------------------------
k1, k2, k3, k4 = st.columns(4)

active_ae_count = len(ae) if isinstance(ae, pd.DataFrame) else 0
with k1:
    st.metric("Active AEs", f"{active_ae_count}")

severe_count = 0
if isinstance(ae, pd.DataFrame) and not ae.empty and "AETOXGR" in ae.columns:
    severe_count = pd.to_numeric(ae["AETOXGR"], errors="coerce").ge(3).sum()
with k2:
    st.metric("Grade ≥ 3 AEs", f"{severe_count}")

mean_hr_display = "–"
if isinstance(vs, pd.DataFrame) and not vs.empty and {"VSTESTCD", "VSORRES"}.issubset(vs.columns):
    hr = vs[vs["VSTESTCD"].astype(str).str.upper() == "HR"]
    if not hr.empty:
        hr_vals = pd.to_numeric(hr["VSORRES"], errors="coerce")
        if hr_vals.notna().any():
            mean_hr_display = f"{hr_vals.mean():.1f}"
with k3:
    st.metric("Mean HR", mean_hr_display)

avg_comp_display = "–"
if isinstance(ex, pd.DataFrame) and not ex.empty and "COMPLIANCE" in ex.columns:
    comp_vals = pd.to_numeric(ex["COMPLIANCE"], errors="coerce")
    if comp_vals.notna().any():
        avg_comp_display = f"{comp_vals.mean():.0f}%"
with k4:
    st.metric("Avg Compliance", avg_comp_display)

# -----------------------------
# Layout & Plots
# -----------------------------
r1c1, r1c2 = st.columns(2)
with r1c1:
    st.plotly_chart(plot_vitals_ae_overlay(vs, ae), use_container_width=True)

with r1c2:
    if isinstance(lb, pd.DataFrame) and not lb.empty and {"VISIT", "VAL"}.issubset(lb.columns):
        fig_lb = px.line(lb, x="VISIT", y="VAL", title="Lab Values Trend from Baseline", template="plotly_dark", markers=True)
        st.plotly_chart(fig_lb, use_container_width=True)
    elif isinstance(lb, pd.DataFrame) and not lb.empty and {"VISIT", "LBTESTCD", "LBSTRESN"}.issubset(lb.columns):
        tests = sorted(lb["LBTESTCD"].dropna().astype(str).unique())
        sel = st.selectbox("Select Lab Test", options=tests, index=0)
        sub = lb[lb["LBTESTCD"].astype(str) == sel].groupby("VISIT", as_index=False)["LBSTRESN"].mean()
        fig_lb = px.line(sub, x="VISIT", y="LBSTRESN", title=f"Lab: {sel} (mean by visit)", template="plotly_dark", markers=True)
        st.plotly_chart(fig_lb, use_container_width=True)
    else:
        st.info("Upload LB domain (VISIT+VAL or VISIT+LBTESTCD+LBSTRESN) to see Lab Trend.")

r2c1, r2c2 = st.columns(2)
with r2c1:
    st.plotly_chart(plot_exposure_compliance(ex), use_container_width=True)

with r2c2:
    fig_wt = plot_weight(vs)
    if fig_wt.data:
        st.plotly_chart(fig_wt, use_container_width=True)
    else:
        st.info("No WEIGHT/WT records in VS to display weight trend.")

st.plotly_chart(plot_ae_timeline(ae), use_container_width=True)

r4c1, r4c2 = st.columns(2)
with r4c1:
    if isinstance(ae, pd.DataFrame) and not ae.empty and "AESEV" in ae.columns:
        sev = ae["AESEV"].astype(str).value_counts().rename_axis("Severity").reset_index(name="Count")
        fig_sev = px.bar(sev, x="Severity", y="Count", title="AE Distribution by Severity",
                         template="plotly_dark", color_discrete_sequence=["#10b981"])
        st.plotly_chart(fig_sev, use_container_width=True)

with r4c2:
    if isinstance(ae, pd.DataFrame) and not ae.empty and "AEREL" in ae.columns:
        rel = ae["AEREL"].astype(str).value_counts().rename_axis("Causality").reset_index(name="Count")
        fig_rel = px.bar(rel, x="Causality", y="Count", title="AE Distribution by Causality",
                         template="plotly_dark", color_discrete_sequence=["#3b82f6"])
        st.plotly_chart(fig_rel, use_container_width=True)

st.markdown("### Adverse Events - Detailed Analysis (AE Domain)")
if isinstance(ae, pd.DataFrame) and not ae.empty:
    st.dataframe(ae, use_container_width=True, hide_index=True)
else:
    st.info("AE table will appear here when AE data is available.")