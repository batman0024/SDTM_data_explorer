from src.utils.defensive import safe_merge, safe_get_usubjid, safe_numeric, safe_datetime
# =============================================================================
# src/derivations/populations.py  -  ADSL-like derivations from SDTM
# =============================================================================

import pandas as pd
import numpy as np
import logging
from typing import Optional

logger = logging.getLogger(__name__)


class PopulationDerivation:
    """Derive analysis-ready subject-level dataset from DM + EX."""

    def create_adsl(
        self,
        dm: Optional[pd.DataFrame],
        ex: Optional[pd.DataFrame] = None,
    ) -> pd.DataFrame:
        if dm is None or dm.empty:
            logger.error("DM domain is required for ADSL creation")
            return pd.DataFrame()

        adsl = dm.copy()
        adsl = self._standardize_cols(adsl)
        adsl = self._derive_treatment_vars(adsl)

        if ex is not None and not ex.empty:
            adsl = self._derive_exposure(adsl, ex)
            adsl = self._derive_safety_flag(adsl, ex)
        else:
            adsl["SAFFL"] = "N"

        adsl = self._derive_itt_flag(adsl)
        adsl = self._derive_age_groups(adsl)
        adsl = self._derive_bmi(adsl)
        logger.info("ADSL created: %d subjects", len(adsl))
        return adsl

    # -------------------------------------------------------------------------
    def _standardize_cols(self, df: pd.DataFrame) -> pd.DataFrame:
        df.columns = [c.strip().upper() for c in df.columns]
        return df

    def _derive_treatment_vars(self, adsl: pd.DataFrame) -> pd.DataFrame:
        if "ARM" in adsl.columns and "TRT01P" not in adsl.columns:
            adsl["TRT01P"] = adsl["ARM"]
        if "ACTARM" in adsl.columns and "TRT01A" not in adsl.columns:
            adsl["TRT01A"] = adsl["ACTARM"]
        elif "ARM" in adsl.columns and "TRT01A" not in adsl.columns:
            adsl["TRT01A"] = adsl["ARM"]
        if "TRT01A" in adsl.columns:
            arms = sorted(adsl["TRT01A"].dropna().unique())
            arm_map = {a: i + 1 for i, a in enumerate(arms)}
            adsl["TRT01AN"] = adsl["TRT01A"].map(arm_map)
        return adsl

    def _derive_exposure(
        self, adsl: pd.DataFrame, ex: pd.DataFrame
    ) -> pd.DataFrame:
        ex2 = ex.copy()
        ex2.columns = [c.strip().upper() for c in ex2.columns]
        if "USUBJID" not in ex2.columns or "EXSTDTC" not in ex2.columns:
            return adsl

        ex2["EXSTDTC"] = pd.to_datetime(ex2["EXSTDTC"], errors="coerce")
        ex2["EXENDTC"] = pd.to_datetime(
            ex2.get("EXENDTC", pd.Series(index=ex2.index, dtype="object")),
            errors="coerce",
        )

        grp = ex2.groupby("USUBJID")
        dates = grp.agg(
            TRTSDT=("EXSTDTC", "min"),
            TRTEDT=("EXENDTC", "max"),
        ).reset_index()

        # Fallback: use EXSTDTC max if EXENDTC all null
        ex_no_end = grp.agg(TRTEDT_FB=("EXSTDTC", "max")).reset_index()
        dates = safe_merge(dates, ex_no_end, on="USUBJID", how="left")
        mask = dates["TRTEDT"].isna()
        dates.loc[mask, "TRTEDT"] = dates.loc[mask, "TRTEDT_FB"]
        dates = dates.drop(columns=["TRTEDT_FB"])

        # Ensure USUBJID is a column (not index) before merge
        if adsl.index.name == "USUBJID":
            adsl = adsl.reset_index()
        if "USUBJID" not in adsl.columns:
            logger.warning("USUBJID not found in ADSL after standardize - skipping exposure merge")
            return adsl
        if "USUBJID" not in dates.columns:
            return adsl
        adsl = safe_merge(adsl, dates, on="USUBJID", how="left")
        adsl["TRTSDT"] = pd.to_datetime(adsl["TRTSDT"], errors="coerce")
        adsl["TRTEDT"] = pd.to_datetime(adsl["TRTEDT"], errors="coerce")
        adsl["TRTDURD"] = (
            (adsl["TRTEDT"] - adsl["TRTSDT"]).dt.days + 1
        ).where(adsl["TRTSDT"].notna() & adsl["TRTEDT"].notna())
        return adsl

    def _derive_safety_flag(
        self, adsl: pd.DataFrame, ex: pd.DataFrame
    ) -> pd.DataFrame:
        ex2 = ex.copy()
        ex2.columns = [c.strip().upper() for c in ex2.columns]

        # Subjects who received any dose (EXDOSE > 0 or any EX record)
        if "EXDOSE" in ex2.columns:
            treated = ex2[
                pd.to_numeric(ex2["EXDOSE"], errors="coerce").gt(0)
            ]["USUBJID"].unique()
        else:
            treated = ex2["USUBJID"].dropna().unique()

        adsl["SAFFL"] = adsl["USUBJID"].isin(treated).map(
            {True: "Y", False: "N"}
        )
        return adsl

    def _derive_itt_flag(self, adsl: pd.DataFrame) -> pd.DataFrame:
        if "ARMCD" in adsl.columns:
            adsl["ITTFL"] = adsl["ARMCD"].notna().map({True: "Y", False: "N"})
        elif "TRT01A" in adsl.columns:
            adsl["ITTFL"] = adsl["TRT01A"].notna().map({True: "Y", False: "N"})
        else:
            adsl["ITTFL"] = "Y"
        return adsl

    def _derive_age_groups(self, adsl: pd.DataFrame) -> pd.DataFrame:
        if "AGE" not in adsl.columns:
            return adsl
        age = pd.to_numeric(adsl["AGE"], errors="coerce")
        adsl["AGEGR1"] = pd.cut(
            age,
            bins=[-np.inf, 17, 64, np.inf],
            labels=["<18", "18-64", ">=65"],
        ).astype(str)
        adsl["AGEGR2"] = pd.cut(
            age,
            bins=[-np.inf, 64, np.inf],
            labels=["<65", ">=65"],
        ).astype(str)
        return adsl

    def _derive_bmi(self, adsl: pd.DataFrame) -> pd.DataFrame:
        for h_col in ["HEIGHTBL", "HEIGHT"]:
            for w_col in ["WEIGHTBL", "WEIGHT"]:
                if h_col in adsl.columns and w_col in adsl.columns:
                    h = pd.to_numeric(adsl[h_col], errors="coerce")
                    w = pd.to_numeric(adsl[w_col], errors="coerce")
                    # assume height in cm, weight in kg
                    h_m = h / 100.0
                    adsl["BMI"] = (w / (h_m ** 2)).where(h_m > 0).round(1)
                    return adsl
        return adsl


# ---------------------------------------------------------------------------
# TEAE identification  (shared across all AE analysis pages)
# ---------------------------------------------------------------------------
def identify_teae(
    ae: pd.DataFrame,
    ex: pd.DataFrame,
    tail_days: int = 30,
) -> pd.DataFrame:
    """
    Flag treatment-emergent AEs:
      TEAE = AESTDTC >= first EXSTDTC AND
             AESTDTC <= last EXENDTC (or EXSTDTC) + tail_days

    Returns ae with TEAE bool column added.
    """
    if ae is None or ae.empty or ex is None or ex.empty:
        out = ae.copy() if ae is not None else pd.DataFrame()
        out["TEAE"] = True
        return out

    ae2 = ae.copy()
    ex2 = ex.copy()
    ae2.columns = [c.strip().upper() for c in ae2.columns]
    ex2.columns = [c.strip().upper() for c in ex2.columns]

    if "AESTDTC" not in ae2.columns or "EXSTDTC" not in ex2.columns:
        ae2["TEAE"] = True
        return ae2

    ae2["AESTDTC"] = pd.to_datetime(ae2["AESTDTC"], errors="coerce")
    ex2["EXSTDTC"] = pd.to_datetime(ex2["EXSTDTC"], errors="coerce")
    ex2["EXENDTC"] = pd.to_datetime(
        ex2.get("EXENDTC", pd.Series(dtype="object")), errors="coerce"
    )

    # First dose and last dose per subject
    first_dose = (
        ex2.groupby("USUBJID")["EXSTDTC"].min().reset_index()
        .rename(columns={"EXSTDTC": "TRTSDT"})
    )
    last_end = ex2.copy()
    last_end["end_dt"] = last_end["EXENDTC"].fillna(last_end["EXSTDTC"])
    last_dose = (
        last_end.groupby("USUBJID")["end_dt"].max().reset_index()
        .rename(columns={"end_dt": "TRTEDT"})
    )

    ae2 = safe_merge(ae2, first_dose, on="USUBJID", how="left")
    ae2 = safe_merge(ae2, last_dose, on="USUBJID", how="left")

    trtedt_ext = ae2["TRTEDT"] + pd.Timedelta(days=tail_days)

    ae2["TEAE"] = (
        ae2["AESTDTC"].ge(ae2["TRTSDT"])
        & ae2["AESTDTC"].le(trtedt_ext)
    )
    ae2["TEAE"] = ae2["TEAE"].fillna(False)
    return ae2


# ---------------------------------------------------------------------------
# Study Day derivation (CDISC SDTM convention: no day 0)
# ---------------------------------------------------------------------------
def derive_study_day(
    dates: pd.Series,
    rfstdtc: pd.Series,
) -> pd.Series:
    """
    Study Day = (date - RFSTDTC).days + 1 if date >= RFSTDTC
                (date - RFSTDTC).days     if date <  RFSTDTC
    """
    d = pd.to_datetime(dates, errors="coerce")
    r = pd.to_datetime(rfstdtc, errors="coerce")
    delta = (d - r).dt.days
    return delta.where(delta < 0, delta + 1)
