# =============================================================================
# pages/12_oncology.py  -  Oncology-specific analysis
# =============================================================================

import streamlit as st
import pandas as pd
import numpy as np
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.data.session import init_session, get_population_df, get_trt_col
from src.utils.theme import apply_theme, get_colors
from src.analysis.descriptive import kaplan_meier
from src.analysis.plots import km_curve, swimmer_plot, waterfall_plot
from src.utils.helpers import pfs_from_rs_ds, format_n_pct

init_session()
apply_theme(st.session_state.get("dark_mode", True))
dark = st.session_state.get("dark_mode", True)
c = get_colors()

st.title("Oncology Analysis")
st.caption("RECIST response, PFS/OS/DOR, swimmer plot, response summary tables.")

if not st.session_state.get("data_loaded"):
    st.warning("Load data first.")
    st.stop()

sdtm = st.session_state["sdtm_data"]
adsl = get_population_df()
trt_col = get_trt_col(adsl)

rs  = sdtm.get("rs")
tr  = sdtm.get("tr")
ds  = sdtm.get("ds")
ex  = sdtm.get("ex")
dm  = sdtm.get("dm")
ae  = sdtm.get("ae")

has_rs = rs is not None and not rs.empty
has_tr = tr is not None and not tr.empty
has_ds = ds is not None and not ds.empty
has_ex = ex is not None and not ex.empty

if not has_rs and not has_tr:
    st.info(
        "Oncology analysis requires RS (Disease Response) or TR (Tumor Results) domain. "
        "Neither is present in the loaded data. \n\n"
        "You can still use the Swimmer Plot if EX and ADSL are loaded."
    )

tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "Response Summary",
    "PFS / OS Curves",
    "Duration of Response",
    "Swimmer Plot",
    "Prior Therapy",
])

# =============================================================
# Tab 1: Response Summary Table
# =============================================================
with tab1:
    if not has_rs:
        st.info("RS domain required for response analysis.")
    else:
        st.markdown("#### Best Overall Response (BOR) Summary")
        rs2 = rs.copy()
        if not adsl.empty:
            rs2 = rs2[rs2["USUBJID"].isin(adsl["USUBJID"].tolist())] if "USUBJID" in rs2.columns else rs2

        if "RSSTRESC" not in rs2.columns:
            st.warning("RSSTRESC not found in RS domain.")
        else:
            # Best response per subject (priority: CR > PR > SD > PD > NE)
            PRIORITY = {"CR": 1, "PR": 2, "SD": 3, "PD": 4, "NE": 5}
            rs2["_PRIO"] = rs2["RSSTRESC"].astype(str).str.upper().map(PRIORITY).fillna(99)
            best = (
                rs2.sort_values("_PRIO")
                .groupby("USUBJID")
                .first()
                .reset_index()[["USUBJID", "RSSTRESC"]]
            )
            best["RSSTRESC"] = best["RSSTRESC"].astype(str).str.upper()

            if trt_col and not adsl.empty:
                best = best.merge(adsl[["USUBJID", trt_col]].drop_duplicates(), on="USUBJID", how="left")

            # Response counts
            arms = sorted(adsl[trt_col].dropna().unique()) if trt_col and not adsl.empty else []
            N_arms = adsl.groupby(trt_col)["USUBJID"].nunique().to_dict() if trt_col and not adsl.empty else {}
            N_total = len(adsl) if not adsl.empty else best["USUBJID"].nunique()

            response_order = ["CR", "PR", "SD", "PD", "NE"]
            rows = []
            for resp in response_order:
                r = {"Response": resp}
                n_tot = int((best["RSSTRESC"] == resp).sum())
                for arm in arms:
                    n_arm = int(((best["RSSTRESC"] == resp) & (best[trt_col] == arm)).sum()) if trt_col else n_tot
                    r[arm] = format_n_pct(n_arm, N_arms.get(arm, 1))
                r["Total"] = format_n_pct(n_tot, N_total)
                rows.append(r)

            # ORR and DCR
            orr_n = int(best["RSSTRESC"].isin(["CR", "PR"]).sum())
            dcr_n = int(best["RSSTRESC"].isin(["CR", "PR", "SD"]).sum())
            rows.append({"Response": "---", **{arm: "---" for arm in arms}, "Total": "---"})
            r_orr = {"Response": "ORR (CR + PR)"}
            r_dcr = {"Response": "DCR (CR + PR + SD)"}
            for arm in arms:
                arm_best = best[best[trt_col] == arm]["RSSTRESC"] if trt_col else best["RSSTRESC"]
                r_orr[arm] = format_n_pct(int(arm_best.isin(["CR", "PR"]).sum()), N_arms.get(arm, 1))
                r_dcr[arm] = format_n_pct(int(arm_best.isin(["CR", "PR", "SD"]).sum()), N_arms.get(arm, 1))
            r_orr["Total"] = format_n_pct(orr_n, N_total)
            r_dcr["Total"] = format_n_pct(dcr_n, N_total)
            rows.append(r_orr)
            rows.append(r_dcr)

            resp_df = pd.DataFrame(rows)
            st.dataframe(resp_df, use_container_width=True, hide_index=True)
            st.download_button(
                "Download Response Table",
                resp_df.to_csv(index=False).encode("utf-8"),
                "response_summary.csv",
            )

            # Pie chart
            import plotly.graph_objects as go
            valid_resp = best["RSSTRESC"].value_counts()
            RESP_COLORS = {"CR": "#22c55e", "PR": "#86efac", "SD": "#fbbf24", "PD": "#ef4444", "NE": "#94a3b8"}
            fig_pie = go.Figure(go.Pie(
                labels=valid_resp.index.tolist(),
                values=valid_resp.values.tolist(),
                marker_colors=[RESP_COLORS.get(r, "#64748b") for r in valid_resp.index],
                hole=0.4,
                hovertemplate="%{label}: %{value} (%{percent})<extra></extra>",
            ))
            fig_pie.update_layout(
                title="Best Overall Response Distribution",
                paper_bgcolor=c["card"],
                font=dict(color=c["text"]),
                legend=dict(bgcolor=c["card"], font=dict(color=c["text"])),
            )
            st.plotly_chart(fig_pie, use_container_width=True)

# =============================================================
# Tab 2: PFS / OS
# =============================================================
with tab2:
    if not has_ex:
        st.info("EX domain required for survival analysis.")
    else:
        endpoint = st.radio("Endpoint", ["PFS (Progression-Free Survival)", "OS (Overall Survival)"], horizontal=True)
        col1, col2 = st.columns([3, 1])
        with col2:
            ci_ribbon = st.toggle("95% CI ribbon", value=True, key="onc_ci")
        with col1:
            if st.button("Compute KM", type="primary", key="onc_km"):
                with st.spinner("Deriving time-to-event data ..."):
                    pfs_df = pfs_from_rs_ds(rs, ds, ex, dm)

                if pfs_df.empty:
                    st.error("Unable to derive time-to-event data. Ensure EX + RS or DS domains are loaded.")
                else:
                    if not adsl.empty and trt_col:
                        adsl_arm = adsl[["USUBJID", trt_col]].drop_duplicates()
                        pfs_df = pfs_df.merge(adsl_arm, on="USUBJID", how="left")
                        if "ARM" not in pfs_df.columns or pfs_df["ARM"].isna().all():
                            pfs_df["ARM"] = pfs_df[trt_col]

                    if "OS" in endpoint:
                        # For OS use death events only
                        pfs_df["EVENT"] = (pfs_df["EVENT_TYPE"] == "Death").astype(int)

                    km_res = kaplan_meier(
                        pfs_df["PFS_MONTHS"],
                        pfs_df["EVENT"],
                        group=pfs_df["ARM"] if "ARM" in pfs_df.columns else None,
                        label=endpoint,
                    )
                    if km_res is None:
                        st.error("lifelines not installed: pip install lifelines")
                    else:
                        if not ci_ribbon:
                            for k in list(km_res.keys()):
                                if not k.startswith("_") and "ci" in km_res[k]:
                                    km_res[k]["ci"] = None

                        fig_km = km_curve(
                            km_res,
                            title=f"{endpoint} Kaplan-Meier Estimate",
                            x_label="Time (months)",
                            dark=dark,
                        )
                        if fig_km:
                            st.plotly_chart(fig_km, use_container_width=True)

                        # Summary
                        rows_km = []
                        for grp, res in km_res.items():
                            if grp.startswith("_"):
                                continue
                            mask = pfs_df["ARM"] == grp if "ARM" in pfs_df.columns else pd.Series([True] * len(pfs_df))
                            rows_km.append({
                                "Group": grp,
                                f"Median {endpoint} (months)": f"{res['median']:.1f}",
                                "N": int(mask.sum()),
                                "Events": int(pfs_df.loc[mask, "EVENT"].sum()),
                            })
                        if rows_km:
                            st.dataframe(pd.DataFrame(rows_km), use_container_width=True, hide_index=True)

                        p = km_res.get("_logrank_p")
                        if p is not None:
                            st.markdown(
                                f"**Log-rank p = "
                                f"<span style='color:{c['accent']}'>{p:.4f}</span>**",
                                unsafe_allow_html=True,
                            )

# =============================================================
# Tab 3: Duration of Response
# =============================================================
with tab3:
    if not has_rs:
        st.info("RS domain required for DOR analysis.")
    elif not has_ex:
        st.info("EX domain required to identify first dose date.")
    else:
        st.markdown(
            "Duration of Response (DOR) = time from first CR/PR to progression/death, "
            "for subjects who achieved response."
        )
        rs3 = rs.copy()
        rs3.columns = [col.upper() for col in rs3.columns]
        if "RSSTRESC" not in rs3.columns:
            st.info("RSSTRESC not found.")
        else:
            # Responders: subjects with CR or PR
            if "USUBJID" in rs3.columns:
                resp_subjs = rs3[rs3["RSSTRESC"].isin(["CR", "PR"])]["USUBJID"].unique()
                st.metric("Subjects with CR/PR (responders)", len(resp_subjs))

                if len(resp_subjs) > 0:
                    # First response date
                    rs3["RSDTC"] = pd.to_datetime(rs3.get("RSDTC", pd.Series(dtype="object")), errors="coerce")
                    first_resp = (
                        rs3[rs3["RSSTRESC"].isin(["CR", "PR"])]
                        .groupby("USUBJID")["RSDTC"].min()
                        .reset_index()
                        .rename(columns={"RSDTC": "FIRST_RESP_DT"})
                    )
                    # Progression / death date (reuse PFS logic)
                    pfs_df = pfs_from_rs_ds(rs, ds, ex, dm)
                    pfs_resp = pfs_df[pfs_df["USUBJID"].isin(resp_subjs)].copy()
                    pfs_resp = pfs_resp.merge(first_resp, on="USUBJID", how="left")

                    if not pfs_resp.empty:
                        if not adsl.empty and trt_col:
                            pfs_resp = pfs_resp.merge(
                                adsl[["USUBJID", trt_col]].drop_duplicates(), on="USUBJID", how="left"
                            )
                            pfs_resp["ARM"] = pfs_resp[trt_col]

                        km_dor = kaplan_meier(
                            pfs_resp["PFS_MONTHS"],
                            pfs_resp["EVENT"],
                            group=pfs_resp["ARM"] if "ARM" in pfs_resp.columns else None,
                            label="DOR",
                        )
                        if km_dor:
                            fig_dor = km_curve(km_dor,
                                               title="Duration of Response (KM)",
                                               x_label="Time from Response (months)",
                                               dark=dark)
                            if fig_dor:
                                st.plotly_chart(fig_dor, use_container_width=True)
                        else:
                            st.info("lifelines required: pip install lifelines")
                    else:
                        st.info("Insufficient data for DOR analysis.")
            else:
                st.info("USUBJID missing in RS.")

# =============================================================
# Tab 4: Swimmer Plot
# =============================================================
with tab4:
    if adsl.empty:
        st.info("ADSL required for swimmer plot.")
    elif "TRTSDT" not in adsl.columns or "TRTEDT" not in adsl.columns:
        st.info("TRTSDT and TRTEDT required in ADSL. Ensure EX domain is loaded.")
    else:
        sort_by = st.radio("Sort subjects by", ["Treatment Duration", "Treatment Arm"], horizontal=True)
        adsl_sw = adsl.copy()
        if sort_by == "Treatment Duration" and "TRTDURD" in adsl_sw.columns:
            adsl_sw = adsl_sw.sort_values("TRTDURD", ascending=True)

        fig_sw = swimmer_plot(
            adsl_sw,
            subj_col="USUBJID",
            start_col="TRTSDT",
            end_col="TRTEDT",
            group_col=trt_col if trt_col else None,
            title="Swimmer Plot - Treatment Duration",
            dark=dark,
        )
        if fig_sw:
            st.plotly_chart(fig_sw, use_container_width=True)
        else:
            st.info("Unable to render swimmer plot.")

# =============================================================
# Tab 5: Prior Anticancer Therapy
# =============================================================
with tab5:
    mh = sdtm.get("mh")
    cm = sdtm.get("cm")

    if mh is None and cm is None:
        st.info("MH (Medical History) or CM (Concomitant Medications) domain required.")
    else:
        KW_SYSTEMIC  = r"CHEMO|PLATIN|PACLITAXEL|DOCETAXEL|GEMCITABINE|IRINOTECAN|DOXORUBICIN|TRASTUZUMAB|BEVACIZUMAB|NIVOLUMAB|PEMBROLIZUMAB|ATEZOLIZUMAB|DURVALUMAB|IMATINIB|ERLOTINIB|GEFITINIB|SORAFENIB|SUNITINIB|LETROZOLE|TAMOXIFEN|FULVESTRANT|ABIRATERONE|ENZALUTAMIDE|CYCLOPHOSPHAMIDE|VINCRISTINE|CAPECITABINE|OXALIPLATIN|CARBOPLATIN|CISPLATIN"
        KW_RADIATION = r"RADIATION|RADIOTHERAPY|XRT|IRRADIATION|RADIOTHERAPEUTIC"
        KW_SURGERY   = r"SURGERY|RESECTION|OPERAT|EXCISION|LOBECTOMY|MASTECTOMY|AMPUTATION|COLECTOMY"

        def _classify(term: str):
            t = str(term).upper()
            if pd.isna(term) or not t.strip():
                return "UNKNOWN"
            import re
            if re.search(KW_SYSTEMIC, t):
                return "SYSTEMIC"
            if re.search(KW_RADIATION, t):
                return "RADIATION"
            if re.search(KW_SURGERY, t):
                return "SURGERY"
            return "OTHER"

        rows_prior = []
        for dom, col in [(mh, "MHDECOD"), (mh, "MHTERM"),
                         (cm, "CMDECOD"), (cm, "CMTRT")]:
            if dom is None or col not in dom.columns:
                continue
            for _, row in dom.iterrows():
                sid = str(row.get("USUBJID", ""))
                term = str(row.get(col, ""))
                if not sid or not term or term == "nan":
                    continue
                rows_prior.append({"USUBJID": sid, "TERM": term, "CATEGORY": _classify(term)})

        if rows_prior:
            df_prior = pd.DataFrame(rows_prior).drop_duplicates()
            if not adsl.empty:
                df_prior = df_prior[df_prior["USUBJID"].isin(adsl["USUBJID"].tolist())]

            # Category counts
            cat_counts = (
                df_prior.groupby("CATEGORY")["USUBJID"].nunique()
                .reset_index()
                .rename(columns={"USUBJID": "N_Subjects"})
                .sort_values("N_Subjects", ascending=False)
            )
            cat_counts["Pct"] = (cat_counts["N_Subjects"] / len(adsl) * 100).round(1) if not adsl.empty else 0

            k1, k2, k3, k4 = st.columns(4)
            for metric_col, cat in zip([k1, k2, k3, k4],
                                        ["SYSTEMIC", "RADIATION", "SURGERY", "OTHER"]):
                n = int(cat_counts[cat_counts["CATEGORY"] == cat]["N_Subjects"].sum())
                metric_col.metric(cat.title(), format_n_pct(n, len(adsl)) if not adsl.empty else str(n))

            import plotly.graph_objects as go
            fig_cat = go.Figure(go.Bar(
                x=cat_counts["CATEGORY"],
                y=cat_counts["N_Subjects"],
                marker_color=[c["accent"], c["success"], c["warning"], c["subtext"]],
            ))
            fig_cat.update_layout(
                title="Prior Therapy by Category (subjects)",
                paper_bgcolor=c["card"], plot_bgcolor=c["bg"],
                font=dict(color=c["text"]),
                xaxis_title="Category", yaxis_title="N Subjects",
            )
            st.plotly_chart(fig_cat, use_container_width=True)

            st.markdown("#### Top Prior Medications / Conditions")
            top_terms = (
                df_prior.groupby(["CATEGORY", "TERM"])["USUBJID"].nunique()
                .reset_index()
                .rename(columns={"USUBJID": "N_Subjects"})
                .sort_values("N_Subjects", ascending=False)
                .head(30)
            )
            st.dataframe(top_terms, use_container_width=True, hide_index=True)
        else:
            st.info("No prior therapy terms found in MH/CM domains.")
