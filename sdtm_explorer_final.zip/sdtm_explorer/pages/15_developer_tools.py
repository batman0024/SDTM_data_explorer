# =============================================================================
# pages/15_developer_tools.py  -  SAS/R code gen, DuckDB, define.xml,
#                                  biomarker stratification
# =============================================================================

import streamlit as st
import pandas as pd
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.data.session import init_session, get_population_df, get_trt_col
from src.utils.theme import apply_theme, get_colors
from src.data.query_engine import (
    SDTMQueryEngine, generate_all_code_samples,
    parse_define_xml, HAS_DUCKDB,
)
from src.analysis.plots import km_curve, waterfall_plot, forest_plot
from src.analysis.descriptive import kaplan_meier, subgroup_stats
from src.utils.helpers import pfs_from_rs_ds

init_session()
apply_theme(st.session_state.get("dark_mode", True))
dark = st.session_state.get("dark_mode", True)
c = get_colors()

st.title("Developer Tools")
st.caption("SAS/R code generation, DuckDB SQL engine, define.xml metadata, biomarker analysis")

if not st.session_state.get("data_loaded"):
    st.warning("Load data first.")
    st.stop()

sdtm   = st.session_state["sdtm_data"]
adsl   = get_population_df()
trt_col = get_trt_col(adsl)

tab1, tab2, tab3, tab4 = st.tabs([
    "SAS / R Code Generator",
    "DuckDB SQL Engine",
    "define.xml Metadata",
    "Biomarker Stratification",
])

# =============================================================
# Tab 1: SAS / R Code Generation
# =============================================================
with tab1:
    st.markdown("### SAS / R Code Generator")
    st.caption(
        "Generate equivalent SAS or R code for any analysis performed in this tool. "
        "Use for validation, documentation, or extending analyses in regulated environments."
    )

    analysis_choices = {
        "AE Frequency Table (PROC FREQ / dplyr)": "ae_freq",
        "Lab Summary Statistics (PROC MEANS / dplyr)": "lab_means",
        "Kaplan-Meier PFS (PROC LIFETEST / survfit)": "km_pfs",
        "ADaM ADLB CHG/PCHG (DATA step / admiral)": "adlb",
    }
    sel_analysis = st.selectbox("Select Analysis", list(analysis_choices.keys()))
    analysis_key = analysis_choices[sel_analysis]

    code_samples = generate_all_code_samples(analysis_key)

    col_sas, col_r = st.columns(2)
    with col_sas:
        st.markdown("#### SAS Code")
        st.code(code_samples.get("SAS", ""), language="sas")
        st.download_button(
            "Download SAS",
            code_samples.get("SAS", "").encode("utf-8"),
            f"{analysis_key}.sas",
            "text/plain",
        )
    with col_r:
        st.markdown("#### R Code")
        st.code(code_samples.get("R", ""), language="r")
        st.download_button(
            "Download R",
            code_samples.get("R", "").encode("utf-8"),
            f"{analysis_key}.R",
            "text/plain",
        )

    st.markdown("---")
    st.markdown("### Custom Code Builder")
    st.caption("Fill in parameters to generate tailored SAS code.")
    c1, c2, c3 = st.columns(3)
    with c1:
        code_dom  = st.selectbox("Domain", sorted(sdtm.keys()), format_func=str.upper, key="code_dom")
    with c2:
        dom_df    = sdtm[code_dom]
        code_var  = st.selectbox("Variable", dom_df.columns.tolist(), key="code_var")
    with c3:
        code_type = st.radio("Type", ["Freq", "Means"], horizontal=True)

    from src.data.query_engine import generate_sas_freq, generate_sas_means
    if code_type == "Freq":
        gen = generate_sas_freq(code_dom, code_var, by_var=trt_col)
    else:
        gen = generate_sas_means(code_dom, code_var, class_var=trt_col)

    st.code(gen, language="sas")
    st.download_button("Download", gen.encode("utf-8"), "custom_code.sas")

# =============================================================
# Tab 2: DuckDB SQL Engine
# =============================================================
with tab2:
    st.markdown("### DuckDB SQL Query Engine")
    if HAS_DUCKDB:
        st.success("DuckDB available - queries run in-process at high speed")
    else:
        st.warning(
            "DuckDB not installed. Install with: `pip install duckdb`  \n"
            "SQL queries will fail but the interface is fully built."
        )

    st.caption(
        f"Available tables: **{', '.join(k.lower() for k in sdtm.keys())}**  \n"
        "Write any SQL SELECT query against these table names."
    )

    # Init engine once per session
    if "query_engine" not in st.session_state or st.session_state.get("_qe_stale"):
        st.session_state["query_engine"] = SDTMQueryEngine(sdtm)
        st.session_state["_qe_stale"] = False

    engine = st.session_state["query_engine"]
    st.caption(f"Backend: **{engine.backend}**")

    example_queries = {
        "AE incidence by SOC (subject count)":
            "SELECT AEBODSYS, COUNT(DISTINCT USUBJID) AS N_Subjects\n"
            "FROM ae\nGROUP BY AEBODSYS\nORDER BY N_Subjects DESC",
        "Mean ALT by visit":
            "SELECT VISIT, ROUND(AVG(LBSTRESN), 2) AS Mean_ALT, COUNT(*) AS N\n"
            "FROM lb\nWHERE LBTESTCD = 'ALT'\nGROUP BY VISIT\nORDER BY VISIT",
        "Subjects with SAE":
            "SELECT DISTINCT USUBJID, AEDECOD, AESTDTC\n"
            "FROM ae\nWHERE AESER = 'Y'\nORDER BY USUBJID",
        "Treatment duration summary":
            "SELECT ARM, COUNT(*) AS N,\n"
            "  ROUND(AVG(TRTDURD), 1) AS Mean_Days,\n"
            "  MIN(TRTDURD) AS Min_Days, MAX(TRTDURD) AS Max_Days\n"
            "FROM adsl\nGROUP BY ARM",
        "Lab values outside normal range":
            "SELECT USUBJID, LBTESTCD, LBSTRESN, LBNRIND, VISIT\n"
            "FROM lb\nWHERE LBNRIND NOT IN ('NORMAL', 'N', '')\n"
            "  AND LBNRIND IS NOT NULL\nORDER BY USUBJID, LBTESTCD",
    }

    sel_example = st.selectbox("Load example query", ["-- custom --"] + list(example_queries.keys()))
    default_sql = example_queries.get(sel_example, "SELECT * FROM dm LIMIT 10")
    sql_input   = st.text_area("SQL Query", value=default_sql, height=130)

    if st.button("Run Query", type="primary"):
        if not HAS_DUCKDB:
            st.error("DuckDB not installed: pip install duckdb")
        else:
            with st.spinner("Running ..."):
                try:
                    result = engine.query(sql_input)
                    if result.empty:
                        st.info("Query returned no rows.")
                    else:
                        st.success(f"{len(result):,} rows returned")
                        st.dataframe(result, use_container_width=True, hide_index=True, height=400)
                        st.download_button(
                            "Download Result CSV",
                            result.to_csv(index=False).encode("utf-8"),
                            "query_result.csv",
                        )
                except Exception as exc:
                    st.error(f"Query failed: {exc}")

# =============================================================
# Tab 3: define.xml Metadata
# =============================================================
with tab3:
    st.markdown("### define.xml Metadata Integration")
    st.caption(
        "Upload your study define.xml to load variable labels, controlled terminology "
        "codelists, data types, and variable lengths directly into the explorer."
    )

    def_file = st.file_uploader("Upload define.xml", type=["xml"], key="define_xml_upload")

    if def_file is not None:
        import tempfile
        with tempfile.NamedTemporaryFile(delete=False, suffix=".xml") as tmp:
            tmp.write(def_file.getvalue())
            tmp_path = tmp.name

        with st.spinner("Parsing define.xml ..."):
            meta = parse_define_xml(tmp_path)

        if "error" in meta:
            st.error(f"Parse failed: {meta['error']}")
        else:
            st.success(
                f"Parsed define.xml v{meta['version']}: "
                f"{len(meta['domains'])} domains, {len(meta['codelists'])} codelists"
            )
            st.session_state["define_metadata"] = meta

            col_a, col_b = st.columns(2)
            with col_a:
                st.markdown("#### Domains + Variable Count")
                dom_info = [{"Domain": k, "Variables": len(v)} for k, v in meta["domains"].items()]
                st.dataframe(pd.DataFrame(dom_info), use_container_width=True, hide_index=True)

            with col_b:
                st.markdown("#### Codelists")
                cl_info = [{"OID": k, "Name": v["name"], "N Values": len(v["values"])}
                           for k, v in meta["codelists"].items()]
                st.dataframe(pd.DataFrame(cl_info).head(30), use_container_width=True, hide_index=True)

            # Domain variable detail
            if meta["domains"]:
                sel_dom_meta = st.selectbox("Inspect domain", sorted(meta["domains"].keys()))
                dom_vars = meta["domains"].get(sel_dom_meta, {})
                if dom_vars:
                    var_df = pd.DataFrame([
                        {"Variable": k, "Label": v.get("label",""), "Type": v.get("type",""), "Length": v.get("length","")}
                        for k, v in dom_vars.items()
                    ])
                    st.dataframe(var_df, use_container_width=True, hide_index=True)
    else:
        st.info(
            "No define.xml uploaded.  \n\n"
            "The define.xml file is produced by your data management system "
            "(e.g., Pinnacle 21, Medidata Rave, SAS) and describes the "
            "structure and controlled terminology of all SDTM datasets."
        )

# =============================================================
# Tab 4: Biomarker Stratification  (Phase 4 - O7 / biomarker)
# =============================================================
with tab4:
    st.markdown("### Biomarker Stratification Analysis")
    st.caption(
        "Stratify efficacy (KM/waterfall) and safety (AE rates) by biomarker status.  \n"
        "Biomarker data from: MB (Microbiology), FA (Findings About), or custom DM variables."
    )

    # Find biomarker data
    mb = sdtm.get("mb")
    fa = sdtm.get("fa")

    biomarker_sources = {}
    if mb is not None and "MBTESTCD" in mb.columns:
        for t in mb["MBTESTCD"].dropna().unique()[:20]:
            biomarker_sources[f"MB: {t}"] = ("mb", "MBTESTCD", t, "MBORRES")
    if fa is not None and "FATESTCD" in fa.columns:
        for t in fa["FATESTCD"].dropna().unique()[:20]:
            biomarker_sources[f"FA: {t}"] = ("fa", "FATESTCD", t, "FAORRES")

    # Also check DM columns that might be biomarker-like
    dm = sdtm.get("dm")
    if dm is not None:
        extra_dm_cols = [c2 for c2 in dm.columns
                         if any(k in c2.upper() for k in
                                ["PDL1", "PD-L1", "KRAS", "EGFR", "ALK", "TMB",
                                 "BRAF", "HER2", "MSI", "BRCA", "NRAS"])]
        for col2 in extra_dm_cols:
            biomarker_sources[f"DM: {col2}"] = ("dm_col", col2, None, col2)

    if not biomarker_sources and adsl is not None:
        # Check ADSL for biomarker flags
        extra_adsl = [c2 for c2 in adsl.columns
                      if any(k in c2.upper() for k in ["FL", "GRP", "CAT", "STATUS"])
                      and c2 not in ["SAFFL", "ITTFL", "PPROTFL", "EFFFL"]]
        for col2 in extra_adsl[:10]:
            biomarker_sources[f"ADSL: {col2}"] = ("adsl_col", col2, None, col2)

    if not biomarker_sources:
        st.info(
            "No biomarker domains (MB, FA) found in loaded data.  \n\n"
            "Biomarker stratification requires:  \n"
            "- **MB domain**: MBTESTCD (test), MBORRES (result), USUBJID  \n"
            "- **FA domain**: FATESTCD (test), FAORRES (result), USUBJID  \n"
            "- Or biomarker flag columns in DM (e.g., PDL1GRP, KRASMUT)  \n\n"
            "Load these domains and return here."
        )
    else:
        sel_bm = st.selectbox("Biomarker", list(biomarker_sources.keys()))
        bm_info = biomarker_sources[sel_bm]
        bm_type = bm_info[0]

        # Extract biomarker per subject
        bm_col_name = f"BM_{sel_bm.replace(': ', '_').replace(' ', '_')}"
        adsl_bm = adsl.copy() if adsl is not None and not adsl.empty else pd.DataFrame()

        if bm_type in ("mb", "fa") and not adsl_bm.empty:
            _, testcd_col_bm, testcd_val, result_col_bm = bm_info
            source_df = sdtm.get(bm_type.split("_")[0])
            if source_df is not None:
                bm_rows = source_df[source_df[testcd_col_bm] == testcd_val]
                if not bm_rows.empty and "USUBJID" in bm_rows.columns:
                    bm_per_subj = (
                        bm_rows.groupby("USUBJID")[result_col_bm]
                        .first().reset_index()
                        .rename(columns={result_col_bm: bm_col_name})
                    )
                    adsl_bm = adsl_bm.merge(bm_per_subj, on="USUBJID", how="left")

        elif bm_type in ("dm_col", "adsl_col") and not adsl_bm.empty:
            _, col2, _, _ = bm_info
            src_df = dm if bm_type == "dm_col" else adsl_bm
            if src_df is not None and col2 in src_df.columns:
                if "USUBJID" in src_df.columns:
                    bm_per_subj = src_df[["USUBJID", col2]].drop_duplicates().rename(columns={col2: bm_col_name})
                    if bm_col_name not in adsl_bm.columns:
                        adsl_bm = adsl_bm.merge(bm_per_subj, on="USUBJID", how="left")
                    else:
                        pass
                else:
                    adsl_bm[bm_col_name] = src_df[col2] if col2 in src_df.columns else None

        if adsl_bm.empty or bm_col_name not in adsl_bm.columns:
            st.info("Could not extract biomarker values for subjects.")
        else:
            bm_vals = adsl_bm[bm_col_name].dropna()
            st.metric("Subjects with biomarker data", len(bm_vals))
            vc = bm_vals.value_counts().reset_index()
            vc.columns = ["Value", "N"]
            st.dataframe(vc, use_container_width=True, hide_index=True)

            bm_group = st.selectbox("Stratify analysis", ["KM (PFS)", "Waterfall", "Forest plot"])

            if bm_group == "KM (PFS)" and st.button("Run KM by Biomarker", type="primary"):
                rs = sdtm.get("rs")
                ds = sdtm.get("ds")
                ex = sdtm.get("ex")
                dm2 = sdtm.get("dm")
                pfs_df = pfs_from_rs_ds(rs, ds, ex, dm2)
                if not pfs_df.empty:
                    pfs_df = pfs_df.merge(adsl_bm[["USUBJID", bm_col_name]].drop_duplicates(),
                                           on="USUBJID", how="left")
                    km_res = kaplan_meier(
                        pfs_df["PFS_MONTHS"],
                        pfs_df["EVENT"],
                        group=pfs_df[bm_col_name],
                        label="PFS",
                    )
                    if km_res:
                        fig = km_curve(km_res, title=f"PFS by {sel_bm}", dark=dark)
                        if fig:
                            st.plotly_chart(fig, use_container_width=True)
                    else:
                        st.error("lifelines required: pip install lifelines")
                else:
                    st.info("PFS data not available.")

            elif bm_group == "Forest plot" and st.button("Run Forest by Biomarker", type="primary"):
                ae_dom = sdtm.get("ae")
                if ae_dom is not None and not adsl_bm.empty:
                    has_ae = adsl_bm["USUBJID"].isin(ae_dom["USUBJID"].dropna().unique())
                    has_ae_idx = has_ae.reindex(adsl_bm.index, fill_value=False)

                    bm_cats = adsl_bm[bm_col_name].dropna().unique()
                    extra_subs = {f"BM: {cat}": (bm_col_name, cat) for cat in bm_cats}

                    sg = subgroup_stats(adsl_bm, has_ae_idx, trt_col,
                                        subgroup_defs=extra_subs,
                                        endpoint_type="binary")
                    if not sg.empty:
                        fig_fp = forest_plot(
                            sg, "Subgroup", "Effect", "Lower", "Upper",
                            n_col="N",
                            title=f"Any AE by Subgroup + {sel_bm}",
                            dark=dark,
                        )
                        if fig_fp:
                            st.plotly_chart(fig_fp, use_container_width=True)
                    else:
                        st.info("No subgroup results.")
