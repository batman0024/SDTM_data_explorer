# =============================================================================
# pages/18_ml_subject_clusters.py  -  UMAP clustering + cross-domain patterns
# =============================================================================

import streamlit as st
import pandas as pd
import numpy as np
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.data.session import init_session, get_population_df, get_trt_col
from src.utils.theme import apply_theme, get_colors

init_session()
apply_theme(st.session_state.get("dark_mode", True))
dark = st.session_state.get("dark_mode", True)
c = get_colors()

try:
    import plotly.graph_objects as go
    import plotly.express as px
except ImportError:
    st.error("plotly required."); st.stop()

st.title("Subject Clustering & Cross-Domain Patterns")
st.caption(
    "UMAP/PCA dimensionality reduction with HDBSCAN/KMeans clustering, "
    "association rule mining across AE+LB+VS domains, "
    "and temporal AE-Lab co-occurrence detection."
)

if not st.session_state.get("data_loaded"):
    st.warning("Load data first."); st.stop()

try:
    from src.ml.feature_engineering import build_subject_feature_matrix, prepare_for_ml
    from src.ml.subject_clusterer import run_clustering
    from src.ml.cross_domain_patterns import (
        mine_association_rules,
        temporal_ae_lab_cooccurrence,
        build_subject_similarity_network,
    )
except Exception as e:
    st.error(f"ML module import failed: {e}"); st.stop()

sdtm    = st.session_state["sdtm_data"]
adsl    = get_population_df()
trt_col = get_trt_col(adsl)

tab1, tab2, tab3, tab4 = st.tabs([
    "Subject Clustering (UMAP/PCA)",
    "Association Rules",
    "AE-Lab Temporal Co-occurrence",
    "Subject Similarity Network",
])

# ===========================================================
# Tab 1 – Clustering
# ===========================================================
with tab1:
    st.markdown("### Patient Phenotype Clustering")
    with st.expander("Clustering Settings", expanded=False):
        cc1, cc2, cc3 = st.columns(3)
        with cc1:
            n_clusters = st.slider("KMeans clusters (fallback)", 2, 10, 3, key="cl_k")
            umap_neighbors = st.slider("UMAP n_neighbors", 5, 50, 15, key="cl_nn")
        with cc2:
            hdbscan_min = st.slider("HDBSCAN min cluster size", 2, 20, 5, key="cl_hm")
            include_lb_cl = st.toggle("Lab features",  value=True, key="cl_lb")
        with cc3:
            include_ae_cl = st.toggle("AE features",   value=True, key="cl_ae")
            include_vs_cl = st.toggle("VS features",   value=True, key="cl_vs")

    if st.button("Run Clustering", type="primary", key="btn_cluster"):
        with st.spinner("Building features and clustering ..."):
            try:
                feat_df, _, feat_meta = build_subject_feature_matrix(
                    sdtm, adsl,
                    include_lb=include_lb_cl,
                    include_ae=include_ae_cl,
                    include_vs=include_vs_cl,
                )
                if feat_df.empty:
                    st.error("Empty feature matrix."); st.stop()

                X_prep, _, _ = prepare_for_ml(feat_df, scale=True)
                if X_prep.empty:
                    st.error("Could not prepare feature matrix."); st.stop()

                cl_result = run_clustering(
                    X_prep, adsl, trt_col,
                    n_clusters=n_clusters,
                    umap_n_neighbors=umap_neighbors,
                    hdbscan_min_cluster_size=hdbscan_min,
                )
                st.session_state["ml_cluster_result"] = cl_result
                st.session_state["ml_cluster_X"] = X_prep
            except Exception as exc:
                st.error(f"Clustering failed: {exc}")
                import traceback; st.code(traceback.format_exc())

    cl_result = st.session_state.get("ml_cluster_result")
    if cl_result:
        for w in cl_result["warnings"]:
            st.warning(w)

        if not cl_result["embedding"].empty:
            st.success(
                f"Method: {cl_result['method_dim']} + {cl_result['method_cluster']} | "
                f"Clusters: {cl_result['n_clusters']} | "
                f"Silhouette: {cl_result['silhouette'] or 'N/A'}"
            )
            emb = cl_result["embedding"].copy()
            emb["Cluster"] = cl_result["cluster_labels"].astype(str)
            emb = emb.reset_index().rename(columns={"index": "USUBJID"})

            if not adsl.empty and trt_col:
                emb = emb.merge(
                    adsl[["USUBJID", trt_col]].drop_duplicates(),
                    on="USUBJID", how="left"
                )

            # 2D scatter
            dim1, dim2 = emb.columns[1], emb.columns[2]
            CLUSTER_COLORS = px.colors.qualitative.Bold
            fig_sc = go.Figure()
            for cid, grp in emb.groupby("Cluster"):
                c_idx = int(cid) % len(CLUSTER_COLORS) if cid != "-1" else -1
                col_c = "#64748b" if cid == "-1" else CLUSTER_COLORS[c_idx]
                fig_sc.add_trace(go.Scatter(
                    x=grp[dim1], y=grp[dim2],
                    mode="markers",
                    name=f"Cluster {cid}" if cid != "-1" else "Noise",
                    marker=dict(size=8, color=col_c, opacity=0.8),
                    text=grp["USUBJID"],
                    hovertemplate=(
                        "<b>%{text}</b><br>"
                        + (f"{trt_col}: %{{customdata}}<br>" if trt_col and trt_col in grp.columns else "")
                        + f"Cluster: {cid}<extra></extra>"
                    ),
                    customdata=grp[trt_col].values if trt_col and trt_col in grp.columns else None,
                ))
            fig_sc.update_layout(
                title=f"Subject Embedding ({cl_result['method_dim']})",
                xaxis_title=dim1, yaxis_title=dim2,
                paper_bgcolor=c["card"], plot_bgcolor=c["bg"],
                font=dict(color=c["text"]), height=550,
                legend=dict(bgcolor=c["card"]),
            )
            st.plotly_chart(fig_sc, use_container_width=True)

            # Cluster summary
            if not cl_result["cluster_summary"].empty:
                st.markdown("**Cluster Demographics:**")
                st.dataframe(cl_result["cluster_summary"], use_container_width=True, hide_index=True)
                st.download_button(
                    "Download Cluster Assignments",
                    emb.to_csv(index=False).encode("utf-8"),
                    "cluster_assignments.csv",
                )
    else:
        st.info("Configure settings and click 'Run Clustering'.")

# ===========================================================
# Tab 2 – Association Rules
# ===========================================================
with tab2:
    st.markdown("### Cross-Domain Association Rule Mining")
    st.caption(
        "Finds clinical event combinations that co-occur more than expected by chance. "
        "Each 'item' is an AE term, lab flag, VS flag, or disposition event per subject."
    )
    ac1, ac2, ac3 = st.columns(3)
    with ac1:
        min_sup  = st.slider("Min support",    0.05, 0.50, 0.10, 0.05, key="ar_sup")
    with ac2:
        min_conf = st.slider("Min confidence", 0.20, 0.90, 0.50, 0.05, key="ar_conf")
    with ac3:
        min_lift = st.slider("Min lift",       1.0,  5.0,  1.2,  0.1,  key="ar_lift")

    inc_ae_ar = st.toggle("AE events",      value=True, key="ar_ae")
    inc_lb_ar = st.toggle("Lab flags",      value=True, key="ar_lb")
    inc_vs_ar = st.toggle("VS flags",       value=True, key="ar_vs")
    inc_ds_ar = st.toggle("Disposition",    value=True, key="ar_ds")

    if st.button("Mine Association Rules", type="primary", key="btn_ar"):
        with st.spinner("Mining patterns ..."):
            try:
                ar_result = mine_association_rules(
                    sdtm, adsl,
                    min_support=min_sup,
                    min_confidence=min_conf,
                    min_lift=min_lift,
                    include_ae=inc_ae_ar,
                    include_lb_flags=inc_lb_ar,
                    include_vs_flags=inc_vs_ar,
                    include_ds=inc_ds_ar,
                )
                st.session_state["ml_ar_result"] = ar_result
            except Exception as exc:
                st.error(f"Association mining failed: {exc}")

    ar_result = st.session_state.get("ml_ar_result")
    if ar_result:
        for w in ar_result["warnings"]:
            st.warning(w)

        if not ar_result["rules"].empty:
            st.success(f"{len(ar_result['rules'])} rules found")
            st.markdown("**Association Rules (sorted by lift):**")
            st.dataframe(ar_result["rules"], use_container_width=True, hide_index=True)
            st.download_button(
                "Download Rules",
                ar_result["rules"].to_csv(index=False).encode("utf-8"),
                "association_rules.csv",
            )

            if not ar_result["itemset_counts"].empty:
                st.markdown("**Frequent Itemsets:**")
                st.dataframe(ar_result["itemset_counts"].head(30),
                             use_container_width=True, hide_index=True)
        elif ar_result["warnings"]:
            st.info("No rules at current thresholds. Try lowering support or lift.")
        else:
            st.info("Run mining above.")
    else:
        st.info("Click 'Mine Association Rules' to find co-occurring clinical events.")

# ===========================================================
# Tab 3 – Temporal AE-Lab co-occurrence
# ===========================================================
with tab3:
    st.markdown("### Temporal AE-Lab Co-occurrence")
    st.caption(
        "Identifies adverse events that co-occur with laboratory abnormalities "
        "within a user-defined time window in the same subject."
    )
    tc1, tc2 = st.columns(2)
    with tc1:
        window = st.slider("Co-occurrence window (days)", 3, 60, 21, key="tc_win")
    with tc2:
        min_subj_tc = st.slider("Min subjects", 1, 10, 2, key="tc_min")

    if st.button("Detect Temporal Patterns", type="primary", key="btn_tc"):
        ae = sdtm.get("ae")
        lb = sdtm.get("lb")
        if ae is None or lb is None:
            st.error("Both AE and LB domains required.")
        else:
            with st.spinner("Computing temporal co-occurrences ..."):
                try:
                    cooc = temporal_ae_lab_cooccurrence(
                        ae, lb, adsl,
                        window_days=window,
                        min_subjects=min_subj_tc,
                    )
                    st.session_state["ml_cooc"] = cooc
                except Exception as exc:
                    st.error(f"Temporal analysis failed: {exc}")

    cooc = st.session_state.get("ml_cooc")
    if cooc is not None:
        if cooc.empty:
            st.info("No temporal co-occurrences found at current settings.")
        else:
            st.success(f"{len(cooc)} AE-Lab pairs with temporal co-occurrence")
            st.dataframe(cooc, use_container_width=True, hide_index=True)

            # Heatmap
            try:
                pivot = cooc.pivot_table(
                    index="AE_Term", columns="Lab_Test",
                    values="N_Subjects", aggfunc="sum", fill_value=0
                )
                fig_cooc = go.Figure(go.Heatmap(
                    z=pivot.values,
                    x=pivot.columns.tolist(),
                    y=[t[:30] for t in pivot.index.tolist()],
                    colorscale="YlOrRd",
                    hovertemplate="AE: %{y}<br>Lab: %{x}<br>N subjects: %{z}<extra></extra>",
                    colorbar=dict(title="N Subjects", tickfont=dict(color=c["text"])),
                ))
                fig_cooc.update_layout(
                    title=f"AE-Lab Temporal Co-occurrence (±{window}d)",
                    paper_bgcolor=c["card"], plot_bgcolor=c["bg"],
                    font=dict(color=c["text"]),
                    height=max(350, len(pivot) * 30),
                    margin=dict(l=200, r=40, t=50, b=80),
                )
                fig_cooc.update_xaxes(tickangle=45)
                st.plotly_chart(fig_cooc, use_container_width=True)
            except Exception as exc:
                st.warning(f"Heatmap failed: {exc}")

            st.download_button(
                "Download Co-occurrence Table",
                cooc.to_csv(index=False).encode("utf-8"),
                "ae_lab_cooccurrence.csv",
            )
    else:
        st.info("Click 'Detect Temporal Patterns' above.")

# ===========================================================
# Tab 4 – Subject Similarity Network
# ===========================================================
with tab4:
    st.markdown("### Subject Similarity Network")
    st.caption(
        "Subjects are connected if their clinical feature profiles are similar "
        "(cosine similarity above threshold). High-degree subjects are clinically similar "
        "to many others and may form natural phenotype clusters."
    )
    nc1, nc2 = st.columns(2)
    with nc1:
        sim_thr = st.slider("Similarity threshold", 0.5, 0.99, 0.80, 0.01, key="sn_thr")
    with nc2:
        top_k_sn = st.slider("Show top N subjects", 10, 60, 30, key="sn_topk")

    if st.button("Build Similarity Network", type="primary", key="btn_sn"):
        X_cl = st.session_state.get("ml_cluster_X")
        if X_cl is None:
            with st.spinner("Building feature matrix ..."):
                try:
                    feat_df, _, feat_meta = build_subject_feature_matrix(sdtm, adsl)
                    X_cl, _, _ = prepare_for_ml(feat_df, scale=True)
                    st.session_state["ml_cluster_X"] = X_cl
                except Exception as exc:
                    st.error(f"Feature build failed: {exc}"); st.stop()

        with st.spinner("Computing pairwise similarity ..."):
            try:
                edge_df, degree_df = build_subject_similarity_network(
                    X_cl, adsl, trt_col,
                    similarity_threshold=sim_thr,
                )
                st.session_state["ml_sim_edges"] = edge_df
                st.session_state["ml_sim_degree"] = degree_df
            except Exception as exc:
                st.error(f"Network failed: {exc}")

    edge_df   = st.session_state.get("ml_sim_edges")
    degree_df = st.session_state.get("ml_sim_degree")

    if edge_df is not None:
        if edge_df.empty:
            st.info(f"No subject pairs above similarity threshold {sim_thr}. Try lowering it.")
        else:
            st.success(f"{len(edge_df)} similar subject pairs found")

            # Network visualization with plotly scatter
            if not degree_df.empty and not edge_df.empty:
                try:
                    # Use degree as node size
                    top_subjs_net = degree_df.head(top_k_sn)
                    subj_pos = {}
                    n_net = len(top_subjs_net)
                    for i, sid in enumerate(top_subjs_net["USUBJID"]):
                        angle = 2 * np.pi * i / max(n_net, 1)
                        subj_pos[sid] = (np.cos(angle), np.sin(angle))

                    # Draw edges
                    edge_x, edge_y = [], []
                    top_subj_set = set(top_subjs_net["USUBJID"])
                    for _, row in edge_df.iterrows():
                        if row["Subject_A"] in subj_pos and row["Subject_B"] in subj_pos:
                            xa, ya = subj_pos[row["Subject_A"]]
                            xb, yb = subj_pos[row["Subject_B"]]
                            edge_x += [xa, xb, None]
                            edge_y += [ya, yb, None]

                    fig_net = go.Figure()
                    fig_net.add_trace(go.Scatter(
                        x=edge_x, y=edge_y, mode="lines",
                        line=dict(width=0.5, color="#475569"),
                        hoverinfo="none", showlegend=False,
                    ))

                    # Nodes colored by arm
                    ARM_COLORS = [c["accent"], c["success"], c["warning"], c["danger"], c["accent2"]]
                    arms_list = sorted(adsl[trt_col].dropna().unique()) if trt_col and not adsl.empty else []
                    arm_color_map = {arm: ARM_COLORS[i % len(ARM_COLORS)] for i, arm in enumerate(arms_list)}

                    for _, row in top_subjs_net.iterrows():
                        sid = row["USUBJID"]
                        if sid not in subj_pos:
                            continue
                        x_pos, y_pos = subj_pos[sid]
                        arm = str(row.get(trt_col, "")) if trt_col and trt_col in row else ""
                        node_color = arm_color_map.get(arm, c["subtext"])
                        deg = int(row["Degree"])
                        fig_net.add_trace(go.Scatter(
                            x=[x_pos], y=[y_pos], mode="markers+text",
                            marker=dict(size=max(8, deg * 3), color=node_color, opacity=0.85),
                            text=[str(sid)[:8]], textposition="top center",
                            textfont=dict(size=8, color=c["text"]),
                            hovertemplate=f"<b>{sid}</b><br>Arm: {arm}<br>Connections: {deg}<extra></extra>",
                            showlegend=False,
                        ))

                    fig_net.update_layout(
                        title=f"Subject Similarity Network (threshold={sim_thr})",
                        paper_bgcolor=c["card"], plot_bgcolor=c["bg"],
                        font=dict(color=c["text"]),
                        xaxis=dict(showticklabels=False, showgrid=False, zeroline=False),
                        yaxis=dict(showticklabels=False, showgrid=False, zeroline=False),
                        height=550,
                    )
                    st.plotly_chart(fig_net, use_container_width=True)
                except Exception as exc:
                    st.warning(f"Network plot failed: {exc}")

            st.markdown("**Top subjects by network degree:**")
            st.dataframe(degree_df.head(20), use_container_width=True, hide_index=True)
            st.download_button(
                "Download Edge List",
                edge_df.to_csv(index=False).encode("utf-8"),
                "similarity_edges.csv",
            )
    else:
        st.info("Click 'Build Similarity Network' to compute subject-to-subject similarity.")
