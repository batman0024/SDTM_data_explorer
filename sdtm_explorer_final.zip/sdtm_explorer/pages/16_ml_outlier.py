# =============================================================================
# pages/16_ml_outlier.py  -  ML-based outlier detection
# =============================================================================

import streamlit as st
import pandas as pd
import numpy as np
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.data.session import init_session, get_population_df, get_trt_col
from src.utils.theme import apply_theme, get_colors, hex_to_rgba

init_session()
apply_theme(st.session_state.get("dark_mode", True))
dark = st.session_state.get("dark_mode", True)
c = get_colors()

st.title("ML Outlier Detection")
st.caption(
    "Automatic anomaly identification using IsolationForest, Z-score, "
    "Mahalanobis distance, and Local Outlier Factor. "
    "All outputs are exploratory - not for regulatory submission."
)

if not st.session_state.get("data_loaded"):
    st.warning("Load data first.")
    st.stop()

try:
    import plotly.graph_objects as go
    import plotly.express as px
    HAS_PX = True
except ImportError:
    HAS_PX = False
    st.error("plotly required.")
    st.stop()

sdtm  = st.session_state["sdtm_data"]
adsl  = get_population_df()
trt_col = get_trt_col(adsl)

if adsl.empty:
    st.error("No subjects in selected population.")
    st.stop()

# Lazy imports with graceful fallback
try:
    from src.ml.feature_engineering import build_subject_feature_matrix, prepare_for_ml
    from src.ml.outlier_engine import run_outlier_detection, get_outlier_explanation, observation_level_outliers
    ML_OK = True
except Exception as e:
    st.error(f"ML module import failed: {e}")
    st.stop()

# ---- Settings panel ----
with st.expander("Detection Settings", expanded=True):
    c1, c2, c3 = st.columns(3)
    with c1:
        contamination = st.slider(
            "Expected outlier fraction",
            0.01, 0.30, 0.10, 0.01,
            help="Fraction of subjects expected to be anomalies (5-15% typical)",
        )
        zscore_thr = st.slider("Z-score threshold", 2.0, 5.0, 3.0, 0.5)
    with c2:
        use_iso  = st.toggle("IsolationForest", value=True)
        use_z    = st.toggle("Z-score",         value=True)
        use_mah  = st.toggle("Mahalanobis",     value=True)
        use_lof  = st.toggle("LOF",             value=True)
    with c3:
        include_lb  = st.toggle("Lab features",   value=True)
        include_ae  = st.toggle("AE features",    value=True)
        include_vs  = st.toggle("VS features",    value=True)
        include_ex  = st.toggle("Exposure features", value=True)

if st.button("Run Outlier Detection", type="primary"):
    with st.spinner("Building feature matrix and running detection ..."):
        try:
            feat_df, feat_names, feat_meta = build_subject_feature_matrix(
                sdtm, adsl,
                include_lb=include_lb,
                include_ae=include_ae,
                include_vs=include_vs,
                include_ex=include_ex,
            )

            if feat_df.empty:
                st.error("Feature matrix is empty. Ensure lab/AE domains are loaded.")
                st.stop()

            X_prep, imputer, scaler = prepare_for_ml(feat_df, scale=True)

            if X_prep.empty:
                st.error("Could not prepare feature matrix (too many missing values).")
                st.stop()

            st.session_state["ml_feat_df"]   = feat_df
            st.session_state["ml_X_prep"]    = X_prep
            st.session_state["ml_feat_meta"] = feat_meta

            result = run_outlier_detection(
                X_prep,
                contamination=contamination,
                use_isolation_forest=use_iso,
                use_zscore=use_z,
                use_mahalanobis=use_mah,
                use_lof=use_lof,
                zscore_threshold=zscore_thr,
            )

            st.session_state["ml_outlier_result"] = result

        except Exception as exc:
            st.error(f"Detection failed: {exc}")
            import traceback
            st.code(traceback.format_exc())
            st.stop()

# ---- Display results ----
result = st.session_state.get("ml_outlier_result")
feat_df   = st.session_state.get("ml_feat_df")
X_prep    = st.session_state.get("ml_X_prep")
feat_meta = st.session_state.get("ml_feat_meta", {})

if result is None:
    st.info("Configure settings and click 'Run Outlier Detection'.")
    st.stop()

# Warnings
for w in result["warnings"]:
    st.warning(w)

if not result["methods_run"]:
    st.error("No algorithms ran successfully.")
    st.stop()

st.success(
    f"Methods run: {', '.join(result['methods_run'])}. "
    f"Ensemble flagged: {result['n_flagged'].get('Ensemble', 0)} subjects"
)

tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "Ensemble Summary",
    "Subject Scores",
    "Heatmap",
    "Subject Explanation",
    "Observation-Level",
])

# ---- Tab 1: Ensemble summary ----
with tab1:
    ensemble = result["ensemble"]
    n_flagged = result["n_flagged"].get("Ensemble", 0)
    n_total   = len(ensemble)

    k1, k2, k3, k4 = st.columns(4)
    k1.metric("Subjects Analysed",  n_total)
    k2.metric("Flagged (Ensemble)", n_flagged)
    k3.metric("Flag Rate", f"{n_flagged/max(n_total,1)*100:.1f}%")
    k4.metric("Methods Run", len(result["methods_run"]))

    # Method agreement table
    flags_df = result["flags"].copy()
    flags_df["Ensemble_Score"] = ensemble
    if trt_col and not adsl.empty:
        flags_df = flags_df.join(
            adsl[["USUBJID", trt_col]].drop_duplicates().set_index("USUBJID"),
            how="left",
        )
    flags_df = flags_df.sort_values("Ensemble_Score", ascending=False)
    st.markdown("**Agreement across methods:**")
    n_flag_cols = [c2 for c2 in flags_df.columns if c2 not in ["Ensemble_Score", trt_col]]
    flags_df["N_Methods_Flagged"] = flags_df[n_flag_cols].sum(axis=1)
    st.dataframe(flags_df.head(20), use_container_width=True, height=350)

    # Per-method counts bar
    nf = {k: v for k, v in result["n_flagged"].items() if k != "Ensemble"}
    if nf:
        fig_nf = go.Figure(go.Bar(
            x=list(nf.keys()), y=list(nf.values()),
            marker_color=c["accent"],
        ))
        fig_nf.update_layout(
            title="Flagged Subjects per Method",
            paper_bgcolor=c["card"], plot_bgcolor=c["bg"],
            font=dict(color=c["text"]),
            xaxis_title="Method", yaxis_title="N Flagged",
        )
        st.plotly_chart(fig_nf, use_container_width=True)

# ---- Tab 2: Subject scores scatter ----
with tab2:
    if not result["scores"].empty:
        scores_df = result["scores"].copy()
        scores_df["Ensemble"] = ensemble
        scores_df["Flagged"]  = result["flags"].get("Ensemble", pd.Series(False, index=scores_df.index))
        scores_df = scores_df.reset_index().rename(columns={"index": "USUBJID"})
        if trt_col and not adsl.empty:
            scores_df = scores_df.merge(
                adsl[["USUBJID", trt_col]].drop_duplicates(), on="USUBJID", how="left"
            )
        scores_df = scores_df.sort_values("Ensemble", ascending=False)
        st.dataframe(scores_df, use_container_width=True, hide_index=True)
        st.download_button(
            "Download Scores CSV",
            scores_df.to_csv(index=False).encode("utf-8"),
            "outlier_scores.csv",
        )

# ---- Tab 3: Heatmap (subjects x features) ----
with tab3:
    if feat_df is not None and not feat_df.empty:
        st.markdown(
            "Subjects (rows) x features (columns). Color = z-score magnitude. "
            "Sorted by ensemble anomaly score (most anomalous at top)."
        )
        top_n_subj = st.slider("Top N subjects to show", 10, 100, 30, key="hm_subj")
        top_n_feat = st.slider("Top N features to show", 5, 50, 20, key="hm_feat")

        # Sort subjects by ensemble score
        sorted_subjs = ensemble.sort_values(ascending=False).index[:top_n_subj].tolist()

        # Select most variable features
        feat_var = feat_df.var().sort_values(ascending=False)
        top_feats = feat_var.index[:top_n_feat].tolist()

        hm_data = feat_df.loc[feat_df.index.isin(sorted_subjs), top_feats]
        if hm_data.empty:
            st.info("No data for heatmap.")
        else:
            # Z-score normalise for display
            hm_z = (hm_data - hm_data.mean()) / (hm_data.std().replace(0, 1))
            hm_z = hm_z.clip(-3, 3)

            # Short feature labels
            col_labels = [f[:20] for f in hm_z.columns]
            row_labels  = [str(s)[:15] for s in hm_z.index]

            fig_hm = go.Figure(go.Heatmap(
                z=hm_z.values,
                x=col_labels,
                y=row_labels,
                colorscale="RdBu_r",
                zmid=0,
                zmin=-3, zmax=3,
                hovertemplate="Subject: %{y}<br>Feature: %{x}<br>Z-score: %{z:.2f}<extra></extra>",
            ))
            fig_hm.update_layout(
                title="Subject x Feature Heatmap (Z-scored, sorted by anomaly score)",
                paper_bgcolor=c["card"], plot_bgcolor=c["bg"],
                font=dict(color=c["text"], size=9),
                height=max(400, len(sorted_subjs) * 18),
                margin=dict(l=120, r=20, t=50, b=120),
            )
            fig_hm.update_xaxes(tickangle=45)
            st.plotly_chart(fig_hm, use_container_width=True)
    else:
        st.info("Feature matrix not available.")

# ---- Tab 4: Subject explanation ----
with tab4:
    st.markdown("### Per-Subject Anomaly Explanation")
    flagged_subjs = result["flags"].get(
        "Ensemble",
        pd.Series(False, index=result["ensemble"].index)
    )
    flagged_subjs = flagged_subjs[flagged_subjs].index.tolist()

    if not flagged_subjs:
        st.info("No subjects flagged by ensemble.")
    else:
        all_subjs = result["ensemble"].sort_values(ascending=False).index.tolist()
        sel_subj  = st.selectbox(
            "Subject",
            all_subjs,
            help="Sorted by anomaly score (highest first)",
        )
        if X_prep is not None and sel_subj in X_prep.index:
            explanation = get_outlier_explanation(sel_subj, X_prep, result, feat_meta)

            score_val = explanation.get("score", 0)
            flagged_by = explanation.get("flags", [])
            tl = "red" if score_val > 0.66 else ("amber" if score_val > 0.33 else "green")
            tl_color = c["danger"] if tl == "red" else (c["warning"] if tl == "amber" else c["success"])

            st.markdown(
                f"<h4>Anomaly Score: "
                f"<span style='color:{tl_color}'>{score_val:.2f}/1.0 ({tl.upper()})</span></h4>",
                unsafe_allow_html=True,
            )
            st.markdown(f"**Flagged by:** {', '.join(flagged_by) if flagged_by else 'None'}")
            st.markdown(explanation.get("narrative", ""))

            top_feats = explanation.get("top_features", [])
            if top_feats:
                st.markdown("**Top contributing features:**")
                for ft in top_feats:
                    direction_icon = "^" if ft["direction"] == "elevated" else "v"
                    st.markdown(
                        f"- `{ft['feature']}` ({ft['description'].split('|')[-1].strip()}) "
                        f"— Z={ft['z_score']:.2f} {direction_icon}"
                    )

            # Mini radar chart of top features
            if len(top_feats) >= 3 and X_prep is not None:
                feat_names_radar = [f["feature"] for f in top_feats[:6]]
                feat_names_radar = [f for f in feat_names_radar if f in X_prep.columns]
                if feat_names_radar:
                    subj_vals = X_prep.loc[sel_subj, feat_names_radar].fillna(0).values.tolist()
                    pop_mean  = X_prep[feat_names_radar].mean().values.tolist()
                    fig_r = go.Figure()
                    fig_r.add_trace(go.Scatterpolar(
                        r=subj_vals + [subj_vals[0]],
                        theta=feat_names_radar + [feat_names_radar[0]],
                        name=sel_subj,
                        line_color=c["danger"],
                        fill="toself",
                        fillcolor=hex_to_rgba(c["danger"], 0.18),
                    ))
                    fig_r.add_trace(go.Scatterpolar(
                        r=pop_mean + [pop_mean[0]],
                        theta=feat_names_radar + [feat_names_radar[0]],
                        name="Population Mean",
                        line_color=c["accent"],
                        fill="toself",
                        fillcolor=hex_to_rgba(c["accent"], 0.12),
                    ))
                    fig_r.update_layout(
                        polar=dict(bgcolor=c["card"]),
                        paper_bgcolor=c["card"],
                        font=dict(color=c["text"]),
                        title=f"Feature Profile vs Population: {sel_subj}",
                        showlegend=True,
                        height=400,
                    )
                    st.plotly_chart(fig_r, use_container_width=True)

# ---- Tab 5: Observation-level outliers ----
with tab5:
    st.markdown("### Observation-Level Outlier Detection")
    st.caption(
        "Flag individual lab or VS measurements as outliers within their "
        "group (test + visit + treatment arm)."
    )
    domain_sel = st.radio("Domain", ["Lab (LB)", "Vital Signs (VS)"], horizontal=True)
    dom_key = "lb" if "Lab" in domain_sel else "vs"
    dom_df  = sdtm.get(dom_key)

    if dom_df is None or dom_df.empty:
        st.info(f"{dom_key.upper()} domain not available.")
    else:
        val_col  = "LBSTRESN" if dom_key == "lb" else "VSSTRESN"
        test_col = "LBTESTCD" if dom_key == "lb" else "VSTESTCD"

        if val_col not in dom_df.columns:
            st.info(f"{val_col} not found in {dom_key.upper()} domain.")
        else:
            zs_obs = st.slider("Z-score threshold (observation-level)", 2.0, 5.0, 3.5, 0.5, key="obs_z")

            group_options = []
            if test_col in dom_df.columns:
                group_options.append(test_col)
            if "VISIT" in dom_df.columns:
                group_options.append("VISIT")

            grp_cols = st.multiselect("Group by", group_options, default=group_options)

            if st.button("Run Observation Outliers", key="btn_obs"):
                with st.spinner("Computing observation-level z-scores ..."):
                    try:
                        dom_pop = dom_df[dom_df["USUBJID"].isin(adsl["USUBJID"].tolist())] if not adsl.empty else dom_df
                        flagged_df = observation_level_outliers(
                            dom_pop, val_col,
                            group_cols=grp_cols if grp_cols else None,
                            zscore_threshold=zs_obs,
                        )
                        obs_flagged = flagged_df[flagged_df["OUTLIER_FLAG"]] if "OUTLIER_FLAG" in flagged_df.columns else pd.DataFrame()
                        n_obs_flag = len(obs_flagged)
                        st.metric("Flagged observations", n_obs_flag)

                        if n_obs_flag > 0:
                            disp_cols = [col for col in
                                         ["USUBJID", test_col, "VISIT", val_col, "OUTLIER_ZSCORE", "OUTLIER_FLAG"]
                                         if col in obs_flagged.columns]
                            st.dataframe(
                                obs_flagged[disp_cols].sort_values("OUTLIER_ZSCORE", key=abs, ascending=False).head(200),
                                use_container_width=True, hide_index=True,
                            )
                            st.download_button(
                                "Download Flagged Observations",
                                obs_flagged[disp_cols].to_csv(index=False).encode("utf-8"),
                                f"{dom_key}_obs_outliers.csv",
                            )
                        else:
                            st.success("No observation-level outliers at current threshold.")
                    except Exception as exc:
                        st.error(f"Observation outlier detection failed: {exc}")
