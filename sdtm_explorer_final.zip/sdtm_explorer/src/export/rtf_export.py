# =============================================================================
# src/export/rtf_export.py  -  RTF / Word-compatible table export
# =============================================================================
# Generates RTF (Rich Text Format) tables that open correctly in Word and
# can be used in CSR appendices.  No external library required beyond stdlib.
# Also generates python-docx Word files if openpyxl is available.
# =============================================================================

import io
import datetime
import pandas as pd
from typing import Optional, List


# ---------------------------------------------------------------------------
# RTF builder (pure Python, no dependencies)
# ---------------------------------------------------------------------------
def _rtf_escape(text: str) -> str:
    """Escape special RTF characters."""
    s = str(text)
    s = s.replace("\\", "\\\\")
    s = s.replace("{", "\\{")
    s = s.replace("}", "\\}")
    # encode non-ASCII as unicode escapes
    out = []
    for ch in s:
        if ord(ch) > 127:
            out.append(f"\\u{ord(ch)}?")
        else:
            out.append(ch)
    return "".join(out)


def dataframe_to_rtf(
    df: pd.DataFrame,
    title: str = "",
    footnote: str = "",
    study_name: str = "Study",
    program_name: str = "SDTM Clinical Data Explorer",
    data_cut: Optional[str] = None,
    col_widths: Optional[List[int]] = None,
) -> str:
    """
    Convert a DataFrame to an RTF string with CSR-quality formatting:
    - Title block at top
    - Bold column headers with shaded background
    - Alternating row emphasis
    - Footnote + program/date footer
    Returns RTF string (encode to bytes for download).
    """
    cut = data_cut or datetime.date.today().isoformat()
    n_cols = len(df.columns)

    # Column widths in twips (1 inch = 1440 twips; page = ~9360 twips)
    if col_widths is None:
        base_w = max(900, 9000 // n_cols)
        col_widths = [base_w] * n_cols

    def _cell(text, bold=False, shaded=False, width=1500):
        shade = "\\clshdng500\\clcfpat8\\clcbpat8" if shaded else ""
        bold_on  = "\\b "  if bold else ""
        bold_off = "\\b0 " if bold else ""
        escaped  = _rtf_escape(text)
        return (
            f"\\clbrdrt\\brdrs\\brdrw10\\clbrdrl\\brdrs\\brdrw10"
            f"\\clbrdrb\\brdrs\\brdrw10\\clbrdrr\\brdrs\\brdrw10"
            f"{shade}\\cellx{width} "
        ), f"{bold_on}{escaped}{bold_off}\\cell "

    # Build header row
    header_defs   = []
    header_cells  = []
    running_width = 0
    for i, col_name in enumerate(df.columns):
        running_width += col_widths[i]
        cell_def, cell_content = _cell(str(col_name), bold=True, shaded=True, width=running_width)
        header_defs.append(cell_def)
        header_cells.append(cell_content)

    # Build data rows
    data_rows_rtf = []
    for _, row in df.iterrows():
        row_defs  = []
        row_cells = []
        running_w = 0
        for i, val in enumerate(row):
            running_w += col_widths[i]
            cell_def, cell_content = _cell(str(val) if pd.notna(val) else "", width=running_w)
            row_defs.append(cell_def)
            row_cells.append(cell_content)
        data_rows_rtf.append(
            "\\trowd \\trgaph108\\trleft-108\n"
            + "".join(row_defs) + "\n"
            + "\\pard\\intbl " + "".join(row_cells) + "\\row\n"
        )

    rtf = (
        "{\\rtf1\\ansi\\deff0\n"
        "{\\fonttbl{\\f0\\froman\\fcharset0 Times New Roman;}"
        "{\\f1\\fswiss\\fcharset0 Arial;}}\n"
        "{\\colortbl ;\\red0\\green0\\blue0;\\red128\\green128\\blue128;"
        "\\red230\\green230\\blue230;}\n"
        "\\widowctrl\\wpaper15840\\wpapr12240\\wmargl1800\\wmargr1800"
        "\\wmargt1440\\wmargb1440\n"
        "\\f1\\fs18\n"
        # Title block
        f"\\pard\\sa120\\sb120\\b\\fs22 {_rtf_escape(title)}\\b0\\par\n"
        f"\\pard\\sa60 \\fs16\\cf2 "
        f"Study: {_rtf_escape(study_name)}  |  "
        f"Data Cut: {_rtf_escape(cut)}  |  "
        f"Population: Safety\\par\n"
        "\\pard\\sa120\\par\n"
        # Header row
        "\\trowd \\trgaph108\\trleft-108\n"
        + "".join(header_defs) + "\n"
        + "\\pard\\intbl \\b " + "".join(header_cells) + "\\b0\\row\n"
        # Data rows
        + "".join(data_rows_rtf)
        # Footer
        + "\\pard\\sa120\\par\n"
        + f"\\pard\\fs14\\cf2 {_rtf_escape(footnote)}\\par\n"
        + f"\\pard\\fs14\\cf2 Program: {_rtf_escape(program_name)}  |  "
        + f"Generated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}\\par\n"
        + "}"
    )
    return rtf


def dataframe_to_rtf_bytes(
    df: pd.DataFrame,
    title: str = "",
    **kwargs,
) -> bytes:
    return dataframe_to_rtf(df, title=title, **kwargs).encode("ascii", errors="replace")


# ---------------------------------------------------------------------------
# Word (.docx) export via python-docx (optional)
# ---------------------------------------------------------------------------
def dataframe_to_docx_bytes(
    df: pd.DataFrame,
    title: str = "",
    study_name: str = "Study",
    data_cut: Optional[str] = None,
    footnote: str = "",
) -> Optional[bytes]:
    """
    Export DataFrame to a .docx Word file.
    Requires: pip install python-docx
    Returns bytes or None if python-docx not installed.
    """
    try:
        from docx import Document
        from docx.shared import Pt, RGBColor, Inches
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.oxml.ns import qn
        from docx.oxml import OxmlElement
    except ImportError:
        return None

    cut = data_cut or datetime.date.today().isoformat()
    doc = Document()

    # Page margins
    section = doc.sections[0]
    section.left_margin   = Inches(1)
    section.right_margin  = Inches(1)
    section.top_margin    = Inches(1)
    section.bottom_margin = Inches(1)

    # Title
    h = doc.add_heading(title, level=1)
    h.runs[0].font.size = Pt(13)
    h.runs[0].font.color.rgb = RGBColor(0x1e, 0x29, 0x3b)

    # Study metadata
    meta = doc.add_paragraph()
    meta.add_run(f"Study: {study_name}  |  Data Cut: {cut}  |  ").font.size = Pt(9)
    meta.add_run(f"Generated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}").font.size = Pt(9)

    doc.add_paragraph()

    # Table
    table = doc.add_table(rows=1, cols=len(df.columns))
    table.style = "Table Grid"

    # Header row
    hdr_cells = table.rows[0].cells
    for i, col_name in enumerate(df.columns):
        hdr_cells[i].text = str(col_name)
        run = hdr_cells[i].paragraphs[0].runs[0]
        run.font.bold = True
        run.font.size = Pt(9)
        # Header shading
        tc   = hdr_cells[i]._tc
        tcPr = tc.get_or_add_tcPr()
        shd  = OxmlElement("w:shd")
        shd.set(qn("w:val"), "clear")
        shd.set(qn("w:color"), "auto")
        shd.set(qn("w:fill"), "E2E8F0")
        tcPr.append(shd)

    # Data rows
    for _, row in df.iterrows():
        row_cells = table.add_row().cells
        for i, val in enumerate(row):
            row_cells[i].text = str(val) if pd.notna(val) else ""
            row_cells[i].paragraphs[0].runs[0].font.size = Pt(9)

    # Footnote
    if footnote:
        doc.add_paragraph()
        fn = doc.add_paragraph(footnote)
        fn.runs[0].font.size = Pt(8)
        fn.runs[0].font.color.rgb = RGBColor(0x64, 0x74, 0x8b)

    buf = io.BytesIO()
    doc.save(buf)
    buf.seek(0)
    return buf.getvalue()


# ---------------------------------------------------------------------------
# Streamlit download helpers for RTF and Word
# ---------------------------------------------------------------------------
def render_rtf_download(
    df: pd.DataFrame,
    title: str = "Table",
    filename: str = "table.rtf",
    key: Optional[str] = None,
    **kwargs,
):
    """Render a Streamlit download button for an RTF file."""
    try:
        import streamlit as st
        rtf_bytes = dataframe_to_rtf_bytes(df, title=title, **kwargs)
        st.download_button(
            label=f"Download RTF: {title[:40]}",
            data=rtf_bytes,
            file_name=filename,
            mime="application/rtf",
            key=key,
        )
    except ImportError:
        pass


def render_docx_download(
    df: pd.DataFrame,
    title: str = "Table",
    filename: str = "table.docx",
    key: Optional[str] = None,
    **kwargs,
):
    """Render a Streamlit download button for a .docx file."""
    try:
        import streamlit as st
        docx_bytes = dataframe_to_docx_bytes(df, title=title, **kwargs)
        if docx_bytes:
            st.download_button(
                label=f"Download Word: {title[:40]}",
                data=docx_bytes,
                file_name=filename,
                mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                key=key,
            )
        else:
            st.caption("Word export requires: pip install python-docx")
    except ImportError:
        pass
