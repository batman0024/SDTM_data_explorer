# =============================================================================
# src/ml/feature_engineering.py
# Per-subject feature matrix builder from SDTM domains.
# Handles missing data, normalization, and edge cases robustly.
# =============================================================================

import pandas as pd
import numpy as np
import logging
from typing import Dict, Optional, List, Tuple

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Minimum viable data thresholds
# ---------------------------------------------------------------------------
MIN_SUBJECTS_ML  = 10   # Below this, skip all ML and warn
MIN_SUBJECTS_UMAP = 15  # Below this, skip UMAP specifically
MIN_FEATURES     = 3    # Below this, meaningless outlier detection


def build_subject_feature_matrix(
    sdtm_data: Dict[str, pd.DataFrame],
    adsl: pd.DataFrame,
    include_lb: bool = True,
    include_ae: bool = True,
    include_vs: bool = True,
    include_ex: bool = True,
    include_demo: bool = True,
    max_lb_tests: int = 15,
    max_ae_terms: int = 20,
) -> Tuple[pd.DataFrame, List[str], Dict[str, str]]:
    """
    Build a per-subject feature matrix from multiple SDTM domains.

    Returns:
        feat_df   : DataFrame (USUBJID x features), NaN for missing
        feat_names: list of feature column names
        feat_meta : dict mapping feature -> domain + description
    """
    if adsl is None or adsl.empty:
        return pd.DataFrame(), [], {}

    # Start with all subjects
    subjects = adsl["USUBJID"].dropna().unique().tolist()
    feat = pd.DataFrame({"USUBJID": subjects})
    feat_meta: Dict[str, str] = {}

    # ---- LB features: mean value, max post-baseline change (per test) ----
    if include_lb:
        lb = sdtm_data.get("lb")
        if lb is not None and not lb.empty and "LBTESTCD" in lb.columns:
            feat, feat_meta = _add_lb_features(feat, lb, adsl, max_lb_tests, feat_meta)

    # ---- AE features: counts by type and severity ----
    if include_ae:
        ae = sdtm_data.get("ae")
        if ae is not None and not ae.empty:
            feat, feat_meta = _add_ae_features(feat, ae, adsl, max_ae_terms, feat_meta)

    # ---- VS features: mean and worst value per parameter ----
    if include_vs:
        vs = sdtm_data.get("vs")
        if vs is not None and not vs.empty and "VSTESTCD" in vs.columns:
            feat, feat_meta = _add_vs_features(feat, vs, feat_meta)

    # ---- EX features: treatment duration, dose intensity ----
    if include_ex:
        feat, feat_meta = _add_ex_features(feat, adsl, feat_meta)

    # ---- Demographics (age as continuous, sex/race encoded) ----
    if include_demo:
        feat, feat_meta = _add_demo_features(feat, adsl, feat_meta)

    # Set USUBJID as index
    feat = feat.set_index("USUBJID")
    feat_names = feat.columns.tolist()

    n_subj = len(feat)
    n_feat = len(feat_names)
    missing_pct = feat.isna().sum().sum() / max(1, n_subj * n_feat) * 100
    logger.info(
        "Feature matrix: %d subjects x %d features, %.1f%% missing",
        n_subj, n_feat, missing_pct,
    )
    return feat, feat_names, feat_meta


# ---------------------------------------------------------------------------
# Lab features
# ---------------------------------------------------------------------------
def _add_lb_features(
    feat: pd.DataFrame,
    lb: pd.DataFrame,
    adsl: pd.DataFrame,
    max_tests: int,
    meta: Dict[str, str],
) -> Tuple[pd.DataFrame, Dict[str, str]]:
    lb2 = lb.copy()
    lb2["LBSTRESN"] = pd.to_numeric(lb2.get("LBSTRESN", pd.Series(dtype=float)), errors="coerce")

    # Get TRTSDT for baseline separation
    trtsdt_map: Dict[str, pd.Timestamp] = {}
    if "TRTSDT" in adsl.columns:
        trtsdt_map = adsl[["USUBJID", "TRTSDT"]].dropna().set_index("USUBJID")["TRTSDT"].to_dict()

    # Pick most variable tests (by IQR across subjects) up to max_tests
    test_variability = {}
    for test, grp in lb2.groupby("LBTESTCD"):
        vals = grp["LBSTRESN"].dropna()
        if len(vals) >= 3:
            q75, q25 = vals.quantile(0.75), vals.quantile(0.25)
            test_variability[test] = q75 - q25
    top_tests = sorted(test_variability, key=test_variability.get, reverse=True)[:max_tests]

    for test in top_tests:
        sub = lb2[lb2["LBTESTCD"] == test]

        # Normalise by ULN if available
        uln_map: Dict[str, float] = {}
        if "LBSTNRHI" in sub.columns:
            uln_grp = sub.groupby("USUBJID")["LBSTNRHI"].first()
            uln_map = pd.to_numeric(uln_grp, errors="coerce").dropna().to_dict()

        # Mean post-baseline value (normalised to ULN where available)
        mean_vals = sub.groupby("USUBJID")["LBSTRESN"].mean()
        col_mean = f"LB_{test}_mean_uln"
        feat[col_mean] = feat.index.map(
            lambda sid: (mean_vals.get(sid, np.nan) / uln_map[sid])
            if sid in uln_map and uln_map[sid] > 0
            else mean_vals.get(sid, np.nan)
        ) if "USUBJID" not in feat.columns else feat["USUBJID"].map(
            lambda sid: (mean_vals.get(sid, np.nan) / uln_map[sid])
            if sid in uln_map and uln_map[sid] > 0
            else mean_vals.get(sid, np.nan)
        )
        meta[col_mean] = f"LB | {test} mean value (/ ULN if available)"

        # Max value (worst = highest for liver, lowest for HGB etc.)
        max_vals = sub.groupby("USUBJID")["LBSTRESN"].max()
        col_max = f"LB_{test}_max"
        feat[col_max] = feat["USUBJID"].map(max_vals.to_dict()) if "USUBJID" in feat.columns else feat.index.map(max_vals.to_dict())
        meta[col_max] = f"LB | {test} maximum observed value"

        # Count of abnormal values (HIGH or LOW)
        if "LBNRIND" in sub.columns:
            abnormal = sub[
                sub["LBNRIND"].astype(str).str.upper().isin(
                    {"HIGH", "LOW", "HIGH HIGH", "LOW LOW", "H", "L", "HH", "LL"}
                )
            ]
            abn_counts = abnormal.groupby("USUBJID").size()
            col_abn = f"LB_{test}_n_abnormal"
            feat[col_abn] = feat["USUBJID"].map(abn_counts.to_dict()).fillna(0) if "USUBJID" in feat.columns else feat.index.map(abn_counts.to_dict()).fillna(0)
            meta[col_abn] = f"LB | {test} count of out-of-normal-range values"

    return _fix_feat_index(feat), meta


def _fix_feat_index(feat: pd.DataFrame) -> pd.DataFrame:
    """Ensure USUBJID column is used for mapping, not index."""
    if "USUBJID" in feat.columns:
        return feat
    return feat.reset_index() if feat.index.name == "USUBJID" else feat


# ---------------------------------------------------------------------------
# AE features
# ---------------------------------------------------------------------------
def _add_ae_features(
    feat: pd.DataFrame,
    ae: pd.DataFrame,
    adsl: pd.DataFrame,
    max_terms: int,
    meta: Dict[str, str],
) -> Tuple[pd.DataFrame, Dict[str, str]]:
    ae2 = ae.copy()

    if "USUBJID" not in ae2.columns:
        return feat, meta

    sid_col = "USUBJID"
    pop_subjs = set(feat["USUBJID"].tolist() if "USUBJID" in feat.columns else feat.index.tolist())
    ae2 = ae2[ae2[sid_col].isin(pop_subjs)]

    # Total TEAE count
    teae = ae2[ae2["TEAE"].astype(bool)] if "TEAE" in ae2.columns else ae2
    n_teae = teae.groupby(sid_col).size()
    feat["AE_n_teae"] = _map_to_feat(feat, n_teae, default=0)
    meta["AE_n_teae"] = "AE | Number of treatment-emergent AEs"

    # SAE count
    if "AESER" in ae2.columns:
        sae = ae2[ae2["AESER"].astype(str).str.upper().isin({"Y", "YES", "1"})]
        n_sae = sae.groupby(sid_col).size()
        feat["AE_n_sae"] = _map_to_feat(feat, n_sae, default=0)
        meta["AE_n_sae"] = "AE | Number of serious adverse events"

    # Max grade
    grade_col = "AETOXGR" if "AETOXGR" in ae2.columns else ("AESEV" if "AESEV" in ae2.columns else None)
    if grade_col:
        from src.analysis.safety import normalize_grade
        ae2["_grade"] = normalize_grade(ae2[grade_col])
        max_grade = ae2.groupby(sid_col)["_grade"].max()
        feat["AE_max_grade"] = _map_to_feat(feat, max_grade, default=0)
        meta["AE_max_grade"] = "AE | Maximum CTCAE grade observed"

    # Count of related AEs
    for rel_col in ["AEREL", "AERELNS"]:
        if rel_col in ae2.columns:
            from src.analysis.safety import is_causally_related
            related = ae2[is_causally_related(ae2[rel_col])]
            n_rel = related.groupby(sid_col).size()
            feat["AE_n_related"] = _map_to_feat(feat, n_rel, default=0)
            meta["AE_n_related"] = "AE | Number of drug-related AEs"
            break

    # Binary flags for top N most frequent AE terms
    pt_col = "AEDECOD" if "AEDECOD" in ae2.columns else "AETERM"
    if pt_col in ae2.columns:
        top_pts = ae2[pt_col].value_counts().head(max_terms).index.tolist()
        for pt in top_pts:
            col_name = f"AE_has_{pt[:20].replace(' ', '_').replace('/', '_')}"
            has_ae = ae2[ae2[pt_col] == pt][sid_col].unique()
            feat[col_name] = _map_to_feat(
                feat,
                pd.Series(1, index=has_ae),
                default=0,
            )
            meta[col_name] = f"AE | Subject ever had: {pt}"

    return feat, meta


# ---------------------------------------------------------------------------
# VS features
# ---------------------------------------------------------------------------
def _add_vs_features(
    feat: pd.DataFrame,
    vs: pd.DataFrame,
    meta: Dict[str, str],
) -> Tuple[pd.DataFrame, Dict[str, str]]:
    vs2 = vs.copy()
    if "VSTESTCD" not in vs2.columns or "VSSTRESN" not in vs2.columns:
        return feat, meta

    vs2["VSSTRESN"] = pd.to_numeric(vs2["VSSTRESN"], errors="coerce")

    CLINICAL_THRESHOLDS = {
        "SYSBP":  {"high": 160, "low": 90},
        "DIABP":  {"high": 100, "low": 60},
        "HR":     {"high": 100, "low": 50},
        "PULSE":  {"high": 100, "low": 50},
        "TEMP":   {"high": 38.5, "low": 36.0},
    }

    for test, grp in vs2.groupby("VSTESTCD"):
        grp2 = grp.dropna(subset=["VSSTRESN"])
        if grp2.empty:
            continue
        # Mean
        mean_v = grp2.groupby("USUBJID")["VSSTRESN"].mean()
        col_m = f"VS_{test}_mean"
        feat[col_m] = _map_to_feat(feat, mean_v)
        meta[col_m] = f"VS | {test} mean value"

        # Count of flagged values
        thr = CLINICAL_THRESHOLDS.get(str(test).upper())
        if thr:
            hi, lo = thr.get("high"), thr.get("low")
            flag_mask = pd.Series(False, index=grp2.index)
            if hi:
                flag_mask |= grp2["VSSTRESN"] > hi
            if lo:
                flag_mask |= grp2["VSSTRESN"] < lo
            flagged = grp2[flag_mask]
            n_flag = flagged.groupby("USUBJID").size()
            col_f = f"VS_{test}_n_flagged"
            feat[col_f] = _map_to_feat(feat, n_flag, default=0)
            meta[col_f] = f"VS | {test} count of values outside clinical thresholds"

    return feat, meta


# ---------------------------------------------------------------------------
# EX / exposure features
# ---------------------------------------------------------------------------
def _add_ex_features(
    feat: pd.DataFrame,
    adsl: pd.DataFrame,
    meta: Dict[str, str],
) -> Tuple[pd.DataFrame, Dict[str, str]]:
    if "TRTDURD" in adsl.columns:
        trtdurd = adsl.set_index("USUBJID")["TRTDURD"]
        feat["EX_trtdurd"] = _map_to_feat(feat, trtdurd)
        meta["EX_trtdurd"] = "EX | Treatment duration (days)"

    if "SAFFL" in adsl.columns:
        saffl = adsl.set_index("USUBJID")["SAFFL"].map({"Y": 1, "N": 0})
        feat["DM_saffl"] = _map_to_feat(feat, saffl, default=0)
        meta["DM_saffl"] = "DM | Safety population flag (1=Y)"

    return feat, meta


# ---------------------------------------------------------------------------
# Demographics features
# ---------------------------------------------------------------------------
def _add_demo_features(
    feat: pd.DataFrame,
    adsl: pd.DataFrame,
    meta: Dict[str, str],
) -> Tuple[pd.DataFrame, Dict[str, str]]:
    if "AGE" in adsl.columns:
        age = pd.to_numeric(adsl.set_index("USUBJID")["AGE"], errors="coerce")
        feat["DM_age"] = _map_to_feat(feat, age)
        meta["DM_age"] = "DM | Age (years)"

    if "SEX" in adsl.columns:
        sex_enc = adsl.set_index("USUBJID")["SEX"].map(
            {"M": 1, "F": 0, "MALE": 1, "FEMALE": 0}
        )
        feat["DM_sex_m"] = _map_to_feat(feat, sex_enc, default=np.nan)
        meta["DM_sex_m"] = "DM | Sex (1=Male, 0=Female)"

    return feat, meta


# ---------------------------------------------------------------------------
# Shared mapping helper
# ---------------------------------------------------------------------------
def _map_to_feat(
    feat: pd.DataFrame,
    series: pd.Series,
    default=np.nan,
) -> pd.Series:
    """Map a Series indexed by USUBJID onto the feat dataframe."""
    if "USUBJID" in feat.columns:
        return feat["USUBJID"].map(series.to_dict()).fillna(default)
    return feat.index.map(series.to_dict()).to_series(index=feat.index).fillna(default)


# ---------------------------------------------------------------------------
# Feature matrix preparation for ML (imputation + scaling)
# ---------------------------------------------------------------------------
def prepare_for_ml(
    feat_df: pd.DataFrame,
    impute_strategy: str = "median",
    scale: bool = True,
) -> Tuple[pd.DataFrame, Optional[object], Optional[object]]:
    """
    Prepare feature matrix for ML:
    1. Drop all-NaN columns
    2. Impute remaining NaNs
    3. Optionally StandardScale

    Returns (X_prepared, imputer, scaler) -- imputer/scaler may be None
    """
    from sklearn.impute import SimpleImputer
    from sklearn.preprocessing import StandardScaler

    if feat_df.empty:
        return feat_df, None, None

    # Drop columns with > 80% missing
    thresh = int(len(feat_df) * 0.2)
    X = feat_df.dropna(axis=1, thresh=thresh).copy()

    if X.empty or X.shape[1] < MIN_FEATURES:
        logger.warning("Too few features after dropping high-missing columns: %d", X.shape[1])
        return pd.DataFrame(), None, None

    # Impute
    try:
        imp = SimpleImputer(strategy=impute_strategy)
        X_imp = imp.fit_transform(X)
        X_imp = pd.DataFrame(X_imp, index=X.index, columns=X.columns)
    except Exception as exc:
        logger.warning("Imputation failed: %s - using median fill", exc)
        X_imp = X.fillna(X.median())
        imp = None

    # Scale
    if scale:
        try:
            sc = StandardScaler()
            X_sc = sc.fit_transform(X_imp)
            X_sc = pd.DataFrame(X_sc, index=X_imp.index, columns=X_imp.columns)
            return X_sc, imp, sc
        except Exception as exc:
            logger.warning("Scaling failed: %s", exc)
            return X_imp, imp, None

    return X_imp, imp, None
