# =============================================================================
# src/ml/outlier_engine.py
# Multi-algorithm outlier detection for clinical trial SDTM data.
#
# Algorithms:
#   1. IsolationForest   - multivariate, no distribution assumption (primary)
#   2. Z-score per variable - univariate, fully explainable (secondary)
#   3. Mahalanobis distance - multivariate with correlations
#      (only when n_subjects > n_features^2, else diagonal fallback)
#   4. LOF (Local Outlier Factor) - density-based, finds local outliers
#
# Design principles:
#   - Every algorithm wrapped in try/except - never crash the page
#   - Minimum N checks before running
#   - Feature contribution explanation for every flagged subject
#   - Returns standardised result dict regardless of which algorithms ran
# =============================================================================

import pandas as pd
import numpy as np
import logging
from typing import Dict, List, Optional, Tuple, Any

logger = logging.getLogger(__name__)

# Graceful sklearn imports
try:
    from sklearn.ensemble import IsolationForest
    from sklearn.neighbors import LocalOutlierFactor
    from sklearn.preprocessing import StandardScaler
    HAS_SKLEARN = True
except ImportError:
    HAS_SKLEARN = False
    logger.warning("scikit-learn not available - outlier detection disabled")

MIN_SUBJECTS = 10


# ---------------------------------------------------------------------------
# Primary API
# ---------------------------------------------------------------------------
def run_outlier_detection(
    X: pd.DataFrame,
    contamination: float = 0.1,
    use_isolation_forest: bool = True,
    use_zscore: bool = True,
    use_mahalanobis: bool = True,
    use_lof: bool = True,
    zscore_threshold: float = 3.0,
    random_state: int = 42,
) -> Dict[str, Any]:
    """
    Run all enabled outlier algorithms on the feature matrix X.

    Parameters
    ----------
    X              : pd.DataFrame, subjects x features (already scaled/imputed)
    contamination  : expected fraction of outliers (0.01 - 0.5)
    *_threshold    : per-method sensitivity controls

    Returns
    -------
    dict with keys:
      'scores'     : DataFrame (subjects x algorithms) with anomaly scores 0-1
      'flags'      : DataFrame (subjects x algorithms) with bool outlier flags
      'ensemble'   : Series with ensemble outlier score per subject (0-1)
      'top_features': dict {subject -> [(feature, z_score), ...]}
      'methods_run': list of algorithm names that succeeded
      'warnings'   : list of warning strings
      'n_flagged'  : dict {method -> n_outliers}
    """
    result: Dict[str, Any] = {
        "scores":      pd.DataFrame(index=X.index),
        "flags":       pd.DataFrame(index=X.index),
        "ensemble":    pd.Series(np.nan, index=X.index),
        "top_features": {},
        "methods_run":  [],
        "warnings":    [],
        "n_flagged":   {},
    }

    if not HAS_SKLEARN:
        result["warnings"].append("scikit-learn not installed.")
        return result

    if X is None or X.empty:
        result["warnings"].append("Empty feature matrix.")
        return result

    n_subj, n_feat = X.shape
    if n_subj < MIN_SUBJECTS:
        result["warnings"].append(
            f"Only {n_subj} subjects. Minimum {MIN_SUBJECTS} required for ML."
        )
        return result
    if n_feat < 2:
        result["warnings"].append("At least 2 features required for outlier detection.")
        return result

    # Clamp contamination
    contamination = float(np.clip(contamination, 0.01, 0.49))

    # Ensure numeric
    X_num = X.select_dtypes(include=[np.number]).fillna(0.0)
    if X_num.shape[1] < 2:
        result["warnings"].append("Fewer than 2 numeric features available.")
        return result

    # ---- 1. Isolation Forest ----
    if use_isolation_forest:
        try:
            max_samples = min(n_subj, 256)
            iso = IsolationForest(
                n_estimators=200,
                max_samples=max_samples,
                contamination=contamination,
                random_state=random_state,
                n_jobs=-1,
            )
            iso.fit(X_num)
            # decision_function: higher = more normal; negate and scale 0-1
            raw_score = iso.decision_function(X_num)
            score_01 = _minmax_score(-raw_score)
            flag = iso.predict(X_num) == -1

            result["scores"]["IsolationForest"] = score_01
            result["flags"]["IsolationForest"]  = flag
            result["n_flagged"]["IsolationForest"] = int(flag.sum())
            result["methods_run"].append("IsolationForest")
        except Exception as exc:
            result["warnings"].append(f"IsolationForest failed: {exc}")
            logger.warning("IsolationForest failed: %s", exc)

    # ---- 2. Z-score (per feature) ----
    if use_zscore:
        try:
            z_scores = (X_num - X_num.mean()) / (X_num.std().replace(0, np.nan))
            max_z = z_scores.abs().max(axis=1)
            score_01 = _minmax_score(max_z.fillna(0))
            flag = max_z > zscore_threshold

            result["scores"]["ZScore"] = score_01
            result["flags"]["ZScore"]  = flag
            result["n_flagged"]["ZScore"] = int(flag.sum())
            result["methods_run"].append("ZScore")

            # Feature contributions: which features drove the z-score for each subject
            for subj in X_num.index:
                row_z = z_scores.loc[subj].abs().sort_values(ascending=False)
                top3 = [(feat, round(float(v), 2)) for feat, v in row_z.head(5).items()]
                result["top_features"][subj] = top3

        except Exception as exc:
            result["warnings"].append(f"Z-score failed: {exc}")
            logger.warning("Z-score failed: %s", exc)

    # ---- 3. Mahalanobis distance ----
    if use_mahalanobis:
        try:
            score_01, flag = _mahalanobis_outliers(X_num, contamination)
            if score_01 is not None:
                result["scores"]["Mahalanobis"] = score_01
                result["flags"]["Mahalanobis"]  = flag
                result["n_flagged"]["Mahalanobis"] = int(flag.sum())
                result["methods_run"].append("Mahalanobis")
        except Exception as exc:
            result["warnings"].append(f"Mahalanobis failed: {exc}")
            logger.warning("Mahalanobis failed: %s", exc)

    # ---- 4. LOF ----
    if use_lof and n_subj >= 20:
        try:
            n_neighbors = min(20, n_subj - 1)
            lof = LocalOutlierFactor(
                n_neighbors=n_neighbors,
                contamination=contamination,
                n_jobs=-1,
            )
            preds = lof.fit_predict(X_num)
            # negative_outlier_factor_: more negative = more anomalous
            raw_nof = -lof.negative_outlier_factor_
            score_01 = _minmax_score(raw_nof)
            flag = preds == -1

            result["scores"]["LOF"] = score_01
            result["flags"]["LOF"]  = flag
            result["n_flagged"]["LOF"] = int(flag.sum())
            result["methods_run"].append("LOF")
        except Exception as exc:
            result["warnings"].append(f"LOF failed: {exc}")
            logger.warning("LOF failed: %s", exc)
    elif use_lof and n_subj < 20:
        result["warnings"].append(
            f"LOF skipped: needs >= 20 subjects (have {n_subj})"
        )

    # ---- Ensemble score (average of available scores) ----
    if not result["scores"].empty:
        try:
            ensemble = result["scores"].mean(axis=1)
            result["ensemble"] = ensemble
            # Ensemble flag: top contamination fraction by ensemble score
            threshold = ensemble.quantile(1 - contamination)
            result["flags"]["Ensemble"] = ensemble >= threshold
            result["n_flagged"]["Ensemble"] = int((ensemble >= threshold).sum())
        except Exception as exc:
            result["warnings"].append(f"Ensemble aggregation failed: {exc}")
            logger.warning("Ensemble failed: %s", exc)

    # Sanity check: if >50% flagged, contamination is probably too high
    if result["n_flagged"].get("Ensemble", 0) > n_subj * 0.5:
        result["warnings"].append(
            "More than 50% of subjects flagged as outliers. "
            "Consider reducing contamination threshold."
        )

    return result


# ---------------------------------------------------------------------------
# Mahalanobis with graceful fallbacks
# ---------------------------------------------------------------------------
def _mahalanobis_outliers(
    X: pd.DataFrame,
    contamination: float,
) -> Tuple[Optional[pd.Series], Optional[pd.Series]]:
    """
    Compute Mahalanobis distances with robust covariance.
    Falls back to diagonal (per-variable variance) when n < p^2.
    """
    n, p = X.shape
    Xv = X.values

    # Try robust covariance (MinCovDet) first
    cov_matrix = None
    if n > p * 3:  # need enough samples for reliable covariance
        try:
            from sklearn.covariance import MinCovDet
            mcd = MinCovDet(random_state=42, support_fraction=min(0.95, (n + p + 1) / (2 * n)))
            mcd.fit(Xv)
            cov_matrix = mcd.covariance_
        except Exception:
            pass

    if cov_matrix is None:
        # Fallback: sample covariance
        try:
            cov_matrix = np.cov(Xv, rowvar=False)
            if cov_matrix.ndim == 0:
                cov_matrix = np.array([[cov_matrix]])
        except Exception:
            cov_matrix = None

    if cov_matrix is None:
        return None, None

    # Use pseudoinverse for singular matrices
    try:
        inv_cov = np.linalg.pinv(cov_matrix)
    except Exception:
        inv_cov = np.diag(1.0 / (np.diag(cov_matrix) + 1e-8))

    # Compute distances
    mean_vec = X.mean().values
    diff = Xv - mean_vec
    try:
        dist = np.sqrt(np.einsum("ij,jk,ik->i", diff, inv_cov, diff))
    except Exception:
        return None, None

    score_01 = _minmax_score(pd.Series(dist, index=X.index))
    threshold = np.quantile(dist, 1 - contamination)
    flag = pd.Series(dist >= threshold, index=X.index)
    return score_01, flag


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _minmax_score(series: pd.Series) -> pd.Series:
    """Scale series to [0, 1]. If all equal, returns zeros."""
    mn, mx = series.min(), series.max()
    if mx == mn:
        return pd.Series(0.0, index=series.index)
    return (series - mn) / (mx - mn)


def get_outlier_explanation(
    subject_id: str,
    X: pd.DataFrame,
    result: Dict[str, Any],
    feat_meta: Dict[str, str],
    top_n: int = 5,
) -> Dict[str, Any]:
    """
    Build a human-readable explanation for why a subject was flagged.

    Returns dict with:
      'score'         : ensemble anomaly score 0-1
      'flags'         : which methods flagged this subject
      'top_features'  : list of (feature, z_score, description)
      'narrative'     : plain-English summary string
    """
    if X is None or subject_id not in X.index:
        return {"error": f"Subject {subject_id} not in feature matrix"}

    score = float(result["ensemble"].get(subject_id, 0.0))
    flags = [
        method for method, series in result["flags"].items()
        if method != "Ensemble" and bool(series.get(subject_id, False))
    ]

    # Feature contributions from Z-score
    top_features_raw = result["top_features"].get(subject_id, [])

    top_features_explained = []
    for feat_name, z_val in top_features_raw[:top_n]:
        desc = feat_meta.get(feat_name, feat_name)
        direction = "elevated" if z_val > 0 else "reduced"
        top_features_explained.append({
            "feature":     feat_name,
            "z_score":     z_val,
            "description": desc,
            "direction":   direction,
        })

    # Narrative
    if not top_features_explained:
        narrative = f"Subject {subject_id} has an anomaly score of {score:.2f}/1.0."
    else:
        top = top_features_explained[0]
        narrative = (
            f"Subject {subject_id} (anomaly score {score:.2f}/1.0) "
            f"was flagged by: {', '.join(flags) if flags else 'ensemble'}. "
            f"Primary driver: {top['description']} is {top['direction']} "
            f"(z={top['z_score']:.1f}). "
        )
        if len(top_features_explained) > 1:
            others = [f["description"].split('|')[-1].strip() for f in top_features_explained[1:3]]
            narrative += f"Also notable: {'; '.join(others)}."

    return {
        "subject_id":    subject_id,
        "score":         score,
        "flags":         flags,
        "top_features":  top_features_explained,
        "narrative":     narrative,
    }


def observation_level_outliers(
    domain_df: pd.DataFrame,
    value_col: str,
    group_cols: Optional[List[str]] = None,
    zscore_threshold: float = 3.5,
) -> pd.DataFrame:
    """
    Flag individual observations (not subjects) as outliers using Z-score
    within groups (e.g. per LBTESTCD x VISIT x TRTGRP).

    Returns original DataFrame with added columns:
      OUTLIER_FLAG (bool), OUTLIER_ZSCORE (float)
    """
    if domain_df is None or domain_df.empty or value_col not in domain_df.columns:
        return domain_df

    df = domain_df.copy()
    df[value_col] = pd.to_numeric(df[value_col], errors="coerce")

    if group_cols and all(c in df.columns for c in group_cols):
        def _flag_group(grp):
            vals = grp[value_col]
            mu   = vals.mean()
            sigma = vals.std()
            if sigma == 0 or np.isnan(sigma):
                grp["OUTLIER_ZSCORE"] = 0.0
                grp["OUTLIER_FLAG"]   = False
                return grp
            z = (vals - mu) / sigma
            grp["OUTLIER_ZSCORE"] = z.round(3)
            grp["OUTLIER_FLAG"]   = z.abs() > zscore_threshold
            return grp
        try:
            df = df.groupby(group_cols, group_keys=False).apply(_flag_group)
        except Exception as exc:
            logger.warning("Observation-level outlier groupby failed: %s", exc)
            df["OUTLIER_FLAG"]   = False
            df["OUTLIER_ZSCORE"] = 0.0
    else:
        mu    = df[value_col].mean()
        sigma = df[value_col].std()
        if sigma and not np.isnan(sigma):
            z = (df[value_col] - mu) / sigma
        else:
            z = pd.Series(0.0, index=df.index)
        df["OUTLIER_ZSCORE"] = z.round(3)
        df["OUTLIER_FLAG"]   = z.abs() > zscore_threshold

    return df
