from src.utils.defensive import safe_merge, safe_get_usubjid, safe_numeric, safe_datetime
# =============================================================================
# src/derivations/populations.py  -  ADSL-like derivations from SDTM
# Defensive programming: USUBJID is always guaranteed to be a column (not index)
# before any operation. All functions are individually guarded.
# =============================================================================

import pandas as pd
import numpy as np
import logging
from typing import Optional

logger = logging.getLogger(__name__)


def _ensure_usubjid_col(df: pd.DataFrame, label: str = "") -> pd.DataFrame:
    """
    Guarantee USUBJID is a proper column, not the DataFrame index.
    Handles every way SAS/pyreadstat might store it:
      - Normal column                  -> nothing to do
      - RangeIndex  + USUBJID column   -> nothing to do
      - USUBJID as named index         -> reset_index()
      - Numeric index + SUBJID col     -> nothing (no USUBJID available)
      - Byte-string columns            -> already uppercased by _standardize_cols
    Returns the (possibly modified) DataFrame.  Never raises.
    """
    try:
        # Already a column? Done.
        if "USUBJID" in df.columns:
            return df
        # USUBJID is the index?
        if df.index.name == "USUBJID":
            logger.debug("_ensure_usubjid_col [%s]: resetting USUBJID from index", label)
            return df.reset_index()
        # Multi-index containing USUBJID?
        if hasattr(df.index, "names") and "USUBJID" in df.index.names:
            return df.reset_index()
        # Nothing we can do — log and return as-is
        logger.warning(
            "_ensure_usubjid_col [%s]: USUBJID not found as column or index. "
            "Columns: %s | Index name: %s",
            label, list(df.columns[:8]), df.index.name,
        )
    except Exception as exc:
        logger.warning("_ensure_usubjid_col [%s] error: %s", label, exc)
    return df


class PopulationDerivation:
    """Derive analysis-ready subject-level dataset from DM + EX."""

    def create_adsl(
        self,
        dm: Optional[pd.DataFrame],
        ex: Optional[pd.DataFrame] = None,
    ) -> pd.DataFrame:
        if dm is None or dm.empty:
            logger.error("DM domain is required for ADSL creation")
            return pd.DataFrame()

        adsl = dm.copy()
        # Step 1: Normalise all column names to uppercase strings
        adsl = self._standardize_cols(adsl)
        # Step 2: CRITICAL — guarantee USUBJID is a column before anything else
        adsl = _ensure_usubjid_col(adsl, "create_adsl/after_standardize")
        # Step 3: Derive downstream variables
        adsl = self._derive_treatment_vars(adsl)

        if ex is not None and not ex.empty:
            adsl = self._derive_exposure(adsl, ex)
            # Re-guarantee after merge (merge can sometimes reset index)
            adsl = _ensure_usubjid_col(adsl, "create_adsl/after_exposure")
            adsl = self._derive_safety_flag(adsl, ex)
        else:
            adsl["SAFFL"] = "N"

        adsl = self._derive_itt_flag(adsl)
        adsl = self._derive_age_groups(adsl)
        adsl = self._derive_bmi(adsl)
        logger.info("ADSL created: %d subjects, cols: %s", len(adsl), list(adsl.columns[:6]))
        return adsl

    # -------------------------------------------------------------------------
    def _standardize_cols(self, df: pd.DataFrame) -> pd.DataFrame:
        """Uppercase all column names; decode byte-string column names."""
        try:
            df.columns = [
                c.decode("latin-1").strip().upper() if isinstance(c, bytes)
                else str(c).strip().upper()
                for c in df.columns
            ]
        except Exception as exc:
            logger.warning("_standardize_cols: column rename failed: %s", exc)
        return df

    def _derive_treatment_vars(self, adsl: pd.DataFrame) -> pd.DataFrame:
        try:
            if "ARM" in adsl.columns and "TRT01P" not in adsl.columns:
                adsl["TRT01P"] = adsl["ARM"]
            if "ACTARM" in adsl.columns and "TRT01A" not in adsl.columns:
                adsl["TRT01A"] = adsl["ACTARM"]
            elif "ARM" in adsl.columns and "TRT01A" not in adsl.columns:
                adsl["TRT01A"] = adsl["ARM"]
            if "TRT01A" in adsl.columns:
                arms = sorted(adsl["TRT01A"].dropna().unique())
                arm_map = {a: i + 1 for i, a in enumerate(arms)}
                adsl["TRT01AN"] = adsl["TRT01A"].map(arm_map)
        except Exception as exc:
            logger.warning("_derive_treatment_vars failed: %s", exc)
        return adsl

    def _derive_exposure(
        self, adsl: pd.DataFrame, ex: pd.DataFrame
    ) -> pd.DataFrame:
        try:
            ex2 = ex.copy()
            ex2 = self._standardize_cols(ex2)
            ex2 = _ensure_usubjid_col(ex2, "_derive_exposure/ex")

            if "USUBJID" not in ex2.columns or "EXSTDTC" not in ex2.columns:
                return adsl

            ex2["EXSTDTC"] = pd.to_datetime(ex2["EXSTDTC"], errors="coerce")
            ex2["EXENDTC"] = pd.to_datetime(
                ex2["EXENDTC"] if "EXENDTC" in ex2.columns
                else pd.Series(index=ex2.index, dtype="object"),
                errors="coerce",
            )

            grp   = ex2.groupby("USUBJID")
            dates = grp.agg(
                TRTSDT=("EXSTDTC", "min"),
                TRTEDT=("EXENDTC", "max"),
            ).reset_index()

            # Fallback: use EXSTDTC max if EXENDTC all null
            ex_no_end = grp.agg(TRTEDT_FB=("EXSTDTC", "max")).reset_index()
            dates = safe_merge(dates, ex_no_end, on="USUBJID", how="left", label="exposure_dates")
            if "TRTEDT_FB" in dates.columns:
                mask = dates["TRTEDT"].isna()
                dates.loc[mask, "TRTEDT"] = dates.loc[mask, "TRTEDT_FB"]
                dates = dates.drop(columns=["TRTEDT_FB"])

            adsl = safe_merge(adsl, dates, on="USUBJID", how="left", label="adsl+dates")
            if "TRTSDT" in adsl.columns:
                adsl["TRTSDT"] = pd.to_datetime(adsl["TRTSDT"], errors="coerce")
            if "TRTEDT" in adsl.columns:
                adsl["TRTEDT"] = pd.to_datetime(adsl["TRTEDT"], errors="coerce")
            if "TRTSDT" in adsl.columns and "TRTEDT" in adsl.columns:
                adsl["TRTDURD"] = (
                    (adsl["TRTEDT"] - adsl["TRTSDT"]).dt.days + 1
                ).where(adsl["TRTSDT"].notna() & adsl["TRTEDT"].notna())
        except Exception as exc:
            logger.warning("_derive_exposure failed: %s", exc)
        return adsl

    def _derive_safety_flag(
        self, adsl: pd.DataFrame, ex: pd.DataFrame
    ) -> pd.DataFrame:
        """
        Set SAFFL = Y for subjects with at least one dose > 0 (or any EX record
        if EXDOSE not present). Uses safe_get_usubjid so USUBJID can be a column
        OR an index in either DataFrame.
        """
        try:
            ex2 = ex.copy()
            ex2 = self._standardize_cols(ex2)
            ex2 = _ensure_usubjid_col(ex2, "_derive_safety_flag/ex")

            if "USUBJID" not in ex2.columns:
                adsl["SAFFL"] = "N"
                return adsl

            # Get set of treated USUBJIDs
            if "EXDOSE" in ex2.columns:
                dose_mask = pd.to_numeric(ex2["EXDOSE"], errors="coerce").gt(0)
                treated = set(ex2.loc[dose_mask, "USUBJID"].dropna().astype(str))
                # If no positive doses found, fall back to any EX record
                if not treated:
                    treated = set(ex2["USUBJID"].dropna().astype(str))
            else:
                treated = set(ex2["USUBJID"].dropna().astype(str))

            # Guarantee USUBJID is a column in adsl before .isin()
            adsl = _ensure_usubjid_col(adsl, "_derive_safety_flag/adsl")

            if "USUBJID" in adsl.columns:
                adsl["SAFFL"] = (
                    adsl["USUBJID"].astype(str).isin(treated)
                    .map({True: "Y", False: "N"})
                )
            elif adsl.index.name == "USUBJID":
                adsl["SAFFL"] = (
                    adsl.index.astype(str).isin(treated)
                )
                adsl["SAFFL"] = adsl["SAFFL"].map({True: "Y", False: "N"})
            else:
                adsl["SAFFL"] = "N"

        except Exception as exc:
            logger.warning("_derive_safety_flag failed (setting all N): %s", exc)
            adsl["SAFFL"] = "N"
        return adsl

    def _derive_itt_flag(self, adsl: pd.DataFrame) -> pd.DataFrame:
        try:
            if "ARMCD" in adsl.columns:
                adsl["ITTFL"] = adsl["ARMCD"].notna().map({True: "Y", False: "N"})
            elif "TRT01A" in adsl.columns:
                adsl["ITTFL"] = adsl["TRT01A"].notna().map({True: "Y", False: "N"})
            else:
                adsl["ITTFL"] = "Y"
        except Exception as exc:
            logger.warning("_derive_itt_flag failed: %s", exc)
            adsl["ITTFL"] = "Y"
        return adsl

    def _derive_age_groups(self, adsl: pd.DataFrame) -> pd.DataFrame:
        try:
            if "AGE" not in adsl.columns:
                return adsl
            age = pd.to_numeric(adsl["AGE"], errors="coerce")
            adsl["AGEGR1"] = pd.cut(
                age,
                bins=[-np.inf, 17, 64, np.inf],
                labels=["<18", "18-64", ">=65"],
            ).astype(str)
            adsl["AGEGR2"] = pd.cut(
                age,
                bins=[-np.inf, 64, np.inf],
                labels=["<65", ">=65"],
            ).astype(str)
        except Exception as exc:
            logger.warning("_derive_age_groups failed: %s", exc)
        return adsl

    def _derive_bmi(self, adsl: pd.DataFrame) -> pd.DataFrame:
        try:
            for h_col in ["HEIGHTBL", "HEIGHT"]:
                for w_col in ["WEIGHTBL", "WEIGHT"]:
                    if h_col in adsl.columns and w_col in adsl.columns:
                        h = pd.to_numeric(adsl[h_col], errors="coerce")
                        w = pd.to_numeric(adsl[w_col], errors="coerce")
                        h_m = h / 100.0
                        adsl["BMI"] = (w / (h_m ** 2)).where(h_m > 0).round(1)
                        return adsl
        except Exception as exc:
            logger.warning("_derive_bmi failed: %s", exc)
        return adsl


# ---------------------------------------------------------------------------
# TEAE identification  (shared across all AE analysis pages)
# ---------------------------------------------------------------------------
def identify_teae(
    ae: pd.DataFrame,
    ex: pd.DataFrame,
    tail_days: int = 30,
) -> pd.DataFrame:
    """
    Flag treatment-emergent AEs:
      TEAE = AESTDTC >= first EXSTDTC AND
             AESTDTC <= last EXENDTC (or EXSTDTC) + tail_days

    Returns ae with TEAE bool column added. Never raises.
    """
    try:
        if ae is None or ae.empty:
            out = ae.copy() if ae is not None else pd.DataFrame()
            out["TEAE"] = True
            return out
        if ex is None or ex.empty:
            out = ae.copy()
            out["TEAE"] = True
            return out

        ae2 = ae.copy()
        ex2 = ex.copy()
        ae2.columns = [
            c.decode("latin-1").strip().upper() if isinstance(c, bytes)
            else str(c).strip().upper() for c in ae2.columns
        ]
        ex2.columns = [
            c.decode("latin-1").strip().upper() if isinstance(c, bytes)
            else str(c).strip().upper() for c in ex2.columns
        ]
        ae2 = _ensure_usubjid_col(ae2, "identify_teae/ae")
        ex2 = _ensure_usubjid_col(ex2, "identify_teae/ex")

        if "AESTDTC" not in ae2.columns or "EXSTDTC" not in ex2.columns:
            ae2["TEAE"] = True
            return ae2

        ae2["AESTDTC"] = pd.to_datetime(ae2["AESTDTC"], errors="coerce")
        ex2["EXSTDTC"] = pd.to_datetime(ex2["EXSTDTC"], errors="coerce")
        ex2["EXENDTC"] = pd.to_datetime(
            ex2["EXENDTC"] if "EXENDTC" in ex2.columns
            else pd.Series(dtype="object"),
            errors="coerce",
        )

        first_dose = (
            ex2.groupby("USUBJID")["EXSTDTC"].min().reset_index()
            .rename(columns={"EXSTDTC": "TRTSDT"})
        )
        last_end = ex2.copy()
        last_end["end_dt"] = last_end["EXENDTC"].fillna(last_end["EXSTDTC"])
        last_dose = (
            last_end.groupby("USUBJID")["end_dt"].max().reset_index()
            .rename(columns={"end_dt": "TRTEDT"})
        )

        ae2 = safe_merge(ae2, first_dose, on="USUBJID", how="left", label="teae_first_dose")
        ae2 = safe_merge(ae2, last_dose,  on="USUBJID", how="left", label="teae_last_dose")

        if "TRTSDT" in ae2.columns and "TRTEDT" in ae2.columns:
            trtedt_ext = ae2["TRTEDT"] + pd.Timedelta(days=tail_days)
            ae2["TEAE"] = (
                ae2["AESTDTC"].ge(ae2["TRTSDT"])
                & ae2["AESTDTC"].le(trtedt_ext)
            ).fillna(False)
        else:
            ae2["TEAE"] = True

    except Exception as exc:
        logger.warning("identify_teae failed: %s - marking all as TEAE", exc)
        if ae is not None:
            ae2 = ae.copy()
            ae2["TEAE"] = True
        else:
            ae2 = pd.DataFrame()

    return ae2


# ---------------------------------------------------------------------------
# Study Day derivation (CDISC SDTM convention: no day 0)
# ---------------------------------------------------------------------------
def derive_study_day(
    dates: pd.Series,
    rfstdtc: pd.Series,
) -> pd.Series:
    """
    Study Day = (date - RFSTDTC).days + 1 if date >= RFSTDTC
                (date - RFSTDTC).days     if date <  RFSTDTC
    """
    try:
        d = pd.to_datetime(dates, errors="coerce")
        r = pd.to_datetime(rfstdtc, errors="coerce")
        delta = (d - r).dt.days
        return delta.where(delta < 0, delta + 1)
    except Exception as exc:
        logger.warning("derive_study_day failed: %s", exc)
        return pd.Series(np.nan, index=dates.index if dates is not None else None)
