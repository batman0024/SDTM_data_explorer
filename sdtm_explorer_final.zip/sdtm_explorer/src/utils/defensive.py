# =============================================================================
# src/utils/defensive.py
# Centralised defensive programming helpers used across all modules.
# Every function here is guaranteed to never raise - only returns safe defaults.
# =============================================================================

import pandas as pd
import numpy as np
import logging
from typing import Any, Dict, List, Optional, Set, Tuple, Union

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# DataFrame safety helpers
# ---------------------------------------------------------------------------

def safe_col(df: Optional[pd.DataFrame], col: str, default=None) -> Any:
    """Return df[col] if it exists and df is not None/empty, else default."""
    try:
        if df is None or df.empty or col not in df.columns:
            return default
        return df[col]
    except Exception:
        return default


def safe_get_usubjid(df: Optional[pd.DataFrame]) -> Set[str]:
    """Extract USUBJID set from a DataFrame whether it's a column or the index."""
    if df is None or df.empty:
        return set()
    try:
        if "USUBJID" in df.columns:
            return set(df["USUBJID"].dropna().astype(str))
        if df.index.name == "USUBJID":
            return set(df.index.dropna().astype(str))
    except Exception:
        pass
    return set()


def ensure_col_exists(df: pd.DataFrame, col: str) -> bool:
    """Return True if col is safely accessible in df."""
    try:
        return df is not None and not df.empty and col in df.columns
    except Exception:
        return False


def safe_merge(
    left: pd.DataFrame,
    right: pd.DataFrame,
    on: str,
    how: str = "left",
    label: str = "",
) -> pd.DataFrame:
    """
    Perform a merge with full defensive guards:
    - Resets index if key is in index instead of columns
    - Validates key column exists in both DataFrames
    - Returns left unchanged if anything fails
    """
    if left is None or left.empty:
        return left if left is not None else pd.DataFrame()
    if right is None or right.empty:
        return left

    try:
        # Reset index if on-column is actually the index
        if left.index.name == on and on not in left.columns:
            left = left.reset_index()
        if right.index.name == on and on not in right.columns:
            right = right.reset_index()

        if on not in left.columns:
            logger.warning("safe_merge [%s]: key '%s' not in left (%s)", label, on, list(left.columns[:5]))
            return left
        if on not in right.columns:
            logger.warning("safe_merge [%s]: key '%s' not in right (%s)", label, on, list(right.columns[:5]))
            return left

        return left.merge(right, on=on, how=how)
    except Exception as exc:
        logger.warning("safe_merge [%s] failed: %s", label, exc)
        return left


def safe_col_access(df: pd.DataFrame, col: str, default_val=np.nan) -> pd.Series:
    """
    Return df[col] as a Series with reset index.
    Never raises - returns Series of default_val if col missing.
    """
    try:
        if df is None or df.empty or col not in df.columns:
            return pd.Series([default_val] * max(len(df) if df is not None else 0, 0))
        return df[col].reset_index(drop=True)
    except Exception:
        return pd.Series(dtype=object)


def align_series_to_df(series: pd.Series, df: pd.DataFrame) -> pd.Series:
    """
    Align a Series to match a DataFrame's index.
    Used to prevent 'Unalignable boolean Series' errors in boolean indexing.
    """
    try:
        if series is None:
            return pd.Series(dtype=object)
        if len(series) == len(df):
            return series.reset_index(drop=True)
        # Try to reindex
        return series.reindex(df.index)
    except Exception:
        return pd.Series(dtype=object)


def safe_numeric(series: pd.Series, fill: float = np.nan) -> pd.Series:
    """Convert series to numeric, filling errors with fill value."""
    try:
        return pd.to_numeric(series, errors="coerce").fillna(fill)
    except Exception:
        return pd.Series([fill] * len(series) if series is not None else 0, dtype=float)


def safe_datetime(series: pd.Series) -> pd.Series:
    """Convert series to datetime, coercing errors to NaT."""
    try:
        return pd.to_datetime(series, errors="coerce")
    except Exception:
        return pd.Series([pd.NaT] * (len(series) if series is not None else 0))


# ---------------------------------------------------------------------------
# Plotly safety helpers
# ---------------------------------------------------------------------------

def safe_vline(fig, x_val, line_dash="dot", line_color="#38bdf8",
               annotation_text="", row=None, col=None):
    """
    Add a vertical line to a plotly figure, safely handling Timestamp objects.
    Never raises - silently skips if x_val is problematic.
    """
    try:
        if x_val is None or (hasattr(x_val, '__class__') and 'NaT' in str(type(x_val))):
            return
        if pd.isna(x_val) if not isinstance(x_val, str) else False:
            return
        # Convert Timestamp/datetime to ISO string for plotly date axes
        if hasattr(x_val, 'isoformat'):
            x_val = x_val.isoformat()
        kwargs = dict(line_dash=line_dash, line_color=line_color)
        if annotation_text:
            kwargs["annotation_text"] = annotation_text
        if row is not None and col is not None:
            kwargs["row"] = row
            kwargs["col"] = col
        fig.add_vline(x=x_val, **kwargs)
    except Exception as exc:
        logger.debug("safe_vline skipped: %s", exc)


def safe_update_layout(fig, base_layout: dict, **extra_kwargs):
    """
    Call fig.update_layout without duplicate keyword conflicts.
    Keys in extra_kwargs override base_layout keys.
    """
    try:
        combined = dict(base_layout)
        for k, v in extra_kwargs.items():
            if k in combined and isinstance(combined[k], dict) and isinstance(v, dict):
                # Merge dicts instead of replacing (e.g. xaxis)
                merged = dict(combined[k])
                merged.update(v)
                combined[k] = merged
            else:
                combined[k] = v
        fig.update_layout(**combined)
    except Exception as exc:
        logger.warning("safe_update_layout failed: %s", exc)
        try:
            fig.update_layout(**extra_kwargs)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# SUPP domain merging
# ---------------------------------------------------------------------------

def merge_supp_to_parent(
    parent_df: pd.DataFrame,
    supp_df: pd.DataFrame,
    parent_domain: str,
) -> pd.DataFrame:
    """
    Merge a SUPPxx domain into its parent SDTM domain following CDISC conventions.

    SUPP structure:
      STUDYID, RDOMAIN, USUBJID, IDVAR, IDVARVAL, QNAM, QLABEL, QVAL, QORIG, QEVAL

    QNAM becomes new columns in the parent, with values from QVAL.
    IDVAR/IDVARVAL links back to the parent record (e.g. AESEQ).

    Returns enriched parent DataFrame (original unchanged on failure).
    """
    if parent_df is None or parent_df.empty:
        return parent_df if parent_df is not None else pd.DataFrame()
    if supp_df is None or supp_df.empty:
        return parent_df

    try:
        supp = supp_df.copy()
        supp.columns = [c.strip().upper() for c in supp.columns]

        required = {"USUBJID", "QNAM", "QVAL"}
        if not required.issubset(set(supp.columns)):
            missing = required - set(supp.columns)
            logger.warning("SUPP%s missing required columns: %s", parent_domain.upper(), missing)
            return parent_df

        parent = parent_df.copy()
        parent.columns = [c.strip().upper() for c in parent.columns]

        # Filter to correct domain if RDOMAIN present
        if "RDOMAIN" in supp.columns:
            supp = supp[supp["RDOMAIN"].astype(str).str.upper() == parent_domain.upper()]
            if supp.empty:
                return parent_df

        # Pivot SUPP: one row per USUBJID+IDVARVAL with QNAM as columns
        id_var  = supp["IDVAR"].iloc[0]  if "IDVAR"  in supp.columns and supp["IDVAR"].notna().any() else None
        id_val  = "IDVARVAL" if "IDVARVAL" in supp.columns else None

        if id_var and id_val and id_var in parent.columns:
            # Link via sequence variable (e.g. AESEQ)
            pivot = supp.pivot_table(
                index=["USUBJID", id_val],
                columns="QNAM",
                values="QVAL",
                aggfunc="first",
            ).reset_index()
            pivot.columns = [str(c).upper() for c in pivot.columns]
            id_val_u = id_val.upper()
            id_var_u = id_var.upper()

            # Coerce types for merge
            if id_val_u in pivot.columns:
                pivot[id_val_u] = pivot[id_val_u].astype(str)
            if id_var_u in parent.columns:
                parent[id_var_u] = parent[id_var_u].astype(str)

            # Rename IDVARVAL to match parent key
            pivot = pivot.rename(columns={id_val_u: id_var_u})
            merge_keys = ["USUBJID", id_var_u]
            merge_keys = [k for k in merge_keys if k in parent.columns and k in pivot.columns]
            if not merge_keys:
                return parent_df

            enriched = parent.merge(pivot, on=merge_keys, how="left", suffixes=("", "_SUPP"))
        else:
            # Simpler pivot: one row per USUBJID, take first value per QNAM
            pivot = supp.pivot_table(
                index="USUBJID",
                columns="QNAM",
                values="QVAL",
                aggfunc="first",
            ).reset_index()
            pivot.columns = [str(c).upper() for c in pivot.columns]
            if "USUBJID" not in parent.columns:
                return parent_df
            enriched = parent.merge(pivot, on="USUBJID", how="left", suffixes=("", "_SUPP"))

        # Remove duplicate _SUPP suffix columns if parent already had QNAM columns
        drop_cols = [c for c in enriched.columns if c.endswith("_SUPP")]
        if drop_cols:
            enriched = enriched.drop(columns=drop_cols)

        new_cols = [c for c in enriched.columns if c not in parent.columns]
        logger.info(
            "SUPP%s merged: added %d columns: %s",
            parent_domain.upper(), len(new_cols), new_cols[:10],
        )
        return enriched

    except Exception as exc:
        logger.warning("merge_supp_to_parent(%s) failed: %s", parent_domain, exc)
        return parent_df


def auto_merge_all_supp(sdtm_data: Dict[str, pd.DataFrame]) -> Dict[str, pd.DataFrame]:
    """
    Automatically detect and merge all SUPPxx domains into their parents.

    Looks for keys matching 'supp*' and merges them into the corresponding
    parent domain (e.g. suppae -> ae, suppex -> ex).

    Returns enriched copy of sdtm_data dict.
    """
    enriched = dict(sdtm_data)
    supp_keys = [k for k in sdtm_data.keys() if k.lower().startswith("supp") and len(k) > 4]

    for supp_key in supp_keys:
        parent_key = supp_key.lower()[4:]  # e.g. 'suppae' -> 'ae'
        if parent_key not in enriched:
            logger.info("SUPP domain %s has no parent %s in loaded domains", supp_key, parent_key)
            continue
        logger.info("Auto-merging %s -> %s", supp_key, parent_key)
        enriched[parent_key] = merge_supp_to_parent(
            enriched[parent_key],
            sdtm_data[supp_key],
            parent_domain=parent_key,
        )

    return enriched
