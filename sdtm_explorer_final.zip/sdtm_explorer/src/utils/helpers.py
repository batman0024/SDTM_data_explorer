# =============================================================================
# src/utils/helpers.py  -  Shared utility functions
# =============================================================================

import pandas as pd
import numpy as np
import re
from typing import Optional, Any


def format_n_pct(n: int, N: int, decimals: int = 1) -> str:
    pct = n / N * 100 if N > 0 else 0.0
    return f"{n} ({pct:.{decimals}f}%)"


def detect_variable_type(series: pd.Series, max_cat: int = 20) -> str:
    """Return 'continuous', 'categorical', or 'datetime'."""
    if pd.api.types.is_datetime64_any_dtype(series):
        return "datetime"
    num = pd.to_numeric(series, errors="coerce")
    n_notnull = num.notna().sum()
    if n_notnull > 0 and (n_notnull / max(1, len(series))) > 0.5:
        n_unique = num.dropna().nunique()
        if n_unique > max_cat:
            return "continuous"
    return "categorical"


def get_domain_label(domain: str) -> str:
    labels = {
        "dm": "Demographics",
        "ae": "Adverse Events",
        "ex": "Exposure",
        "lb": "Lab Results",
        "vs": "Vital Signs",
        "cm": "Concomitant Medications",
        "mh": "Medical History",
        "ds": "Disposition",
        "sv": "Subject Visits",
        "tr": "Tumor Results",
        "rs": "Disease Response",
        "tu": "Tumor Identification",
        "dv": "Protocol Deviations",
        "fa": "Findings About",
        "eg": "ECG Test Results",
        "pc": "PK Concentrations",
        "pp": "PK Parameters",
        "ce": "Clinical Events",
    }
    return labels.get(domain.lower(), domain.upper())


def safe_date(val: Any) -> Optional[pd.Timestamp]:
    try:
        return pd.to_datetime(val, errors="coerce")
    except Exception:
        return None


def normalize_visit_order(series: pd.Series) -> pd.Series:
    """
    Try to sort VISIT labels logically:
    Screening < Baseline < Week N < End of Study
    """
    VISIT_ORDER = {
        "SCREEN": -2, "SCREENING": -2, "SCR": -2,
        "BASELINE": 0, "BASE": 0, "BL": 0, "DAY 1": 0,
        "END OF STUDY": 9999, "EOS": 9999, "EOT": 9998,
        "UNSCHEDULED": 9997, "EARLY TERMINATION": 9996,
    }

    def _key(v):
        s = str(v).strip().upper()
        if s in VISIT_ORDER:
            return VISIT_ORDER[s]
        # Extract numeric week/day
        m = re.search(r"WEEK\s*(\d+)", s)
        if m:
            return int(m.group(1)) * 7
        m = re.search(r"DAY\s*(\d+)", s)
        if m:
            return int(m.group(1))
        m = re.search(r"(\d+)", s)
        if m:
            return int(m.group(1))
        return 5000

    return series.map(_key)


def create_frequency_table(series: pd.Series) -> pd.DataFrame:
    vc = series.value_counts(dropna=True)
    pct = (vc / vc.sum() * 100).round(1)
    return pd.DataFrame({
        "Category": vc.index,
        "N": vc.values,
        "Percent": pct.values,
        "N (%)": [f"{n} ({p:.1f}%)" for n, p in zip(vc.values, pct.values)],
    })


def pfs_from_rs_ds(
    rs: Optional[pd.DataFrame],
    ds: Optional[pd.DataFrame],
    ex: pd.DataFrame,
    dm: Optional[pd.DataFrame] = None,
) -> pd.DataFrame:
    """
    Derive PFS time-to-event dataset from RS/DS/EX/DM.
    Returns DataFrame: USUBJID, ARM, PFS_MONTHS, EVENT, EVENT_TYPE
    """
    rows = []
    if ex is None or ex.empty or "EXSTDTC" not in ex.columns:
        return pd.DataFrame()

    ex2 = ex.copy()
    ex2.columns = [c.upper() for c in ex2.columns]
    ex2["EXSTDTC"] = pd.to_datetime(ex2["EXSTDTC"], errors="coerce")

    subjs = ex2["USUBJID"].dropna().unique() if "USUBJID" in ex2.columns else []

    for sid in subjs:
        sx = ex2[ex2["USUBJID"] == sid]
        start = sx["EXSTDTC"].min()
        if pd.isna(start):
            continue

        # Progression from RS
        prog_dt = None
        if rs is not None and not rs.empty and "RSSTRESC" in rs.columns:
            rs2 = rs.copy()
            rs2.columns = [c.upper() for c in rs2.columns]
            sr = rs2[rs2.get("USUBJID", pd.Series()) == sid] if "USUBJID" in rs2.columns else pd.DataFrame()
            if not sr.empty and "RSDTC" in sr.columns:
                prog_rows = sr[sr["RSSTRESC"].astype(str).str.upper().isin(
                    ["PD", "PROGRESSIVE DISEASE"]
                )]
                if not prog_rows.empty:
                    prog_dt = pd.to_datetime(prog_rows["RSDTC"], errors="coerce").min()

        # Death from DS
        death_dt = None
        if ds is not None and not ds.empty:
            ds2 = ds.copy()
            ds2.columns = [c.upper() for c in ds2.columns]
            sd = ds2[ds2.get("USUBJID", pd.Series()) == sid] if "USUBJID" in ds2.columns else pd.DataFrame()
            if not sd.empty and "DSDECOD" in sd.columns:
                death_rows = sd[
                    sd["DSDECOD"].astype(str).str.upper().str.contains("DEATH", na=False)
                ]
                if not death_rows.empty and "DSSTDTC" in sd.columns:
                    death_dt = pd.to_datetime(
                        death_rows["DSSTDTC"].iloc[0], errors="coerce"
                    )

        ev_dates = [d for d in [prog_dt, death_dt] if pd.notna(d)]
        if ev_dates:
            ev_date = min(ev_dates)
            event = 1
            ev_type = "Progression" if ev_date == prog_dt else "Death"
        else:
            event = 0
            ev_type = "Censored"
            ev_date = start  # will refine with last RS date

            if rs is not None and not rs.empty and "RSDTC" in rs.columns:
                rs3 = rs.copy()
                rs3.columns = [c.upper() for c in rs3.columns]
                sr = rs3[rs3.get("USUBJID", pd.Series()) == sid] if "USUBJID" in rs3.columns else pd.DataFrame()
                if not sr.empty:
                    last_rs = pd.to_datetime(sr["RSDTC"], errors="coerce").max()
                    if pd.notna(last_rs):
                        ev_date = last_rs

        months = max(0.0, (ev_date - start).days / 30.44)

        arm = ""
        if dm is not None and not dm.empty:
            dm2 = dm.copy()
            dm2.columns = [c.upper() for c in dm2.columns]
            for arm_col in ["TRT01A", "ARM", "ACTARM"]:
                if arm_col in dm2.columns:
                    row_dm = dm2[dm2.get("USUBJID", pd.Series()) == sid]
                    if not row_dm.empty:
                        arm = str(row_dm[arm_col].iloc[0])
                        break

        rows.append({
            "USUBJID": sid,
            "ARM": arm,
            "PFS_MONTHS": round(months, 3),
            "EVENT": event,
            "EVENT_TYPE": ev_type,
        })

    return pd.DataFrame(rows) if rows else pd.DataFrame()


# =============================================================================
# Cross-domain subject consistency checks  (Q2)
# =============================================================================
def run_consistency_checks(sdtm_data: dict, adsl=None) -> "pd.DataFrame":
    """
    Cross-domain consistency checks for data integrity.
    Returns DataFrame of findings with Rule, Status, N, Example columns.
    Fully guarded - never raises KeyError or IndexError.
    """
    import pandas as pd

    def _get_col(df, col):
        """Safely get a column, returning empty Series if missing."""
        if df is None or col not in df.columns:
            return pd.Series(dtype=object)
        return df[col]

    def _subjs(df):
        """Get unique USUBJID set from a DataFrame, never raises."""
        if df is None or df.empty:
            return set()
        # Handle USUBJID as column or as index
        if "USUBJID" in df.columns:
            return set(df["USUBJID"].dropna())
        if df.index.name == "USUBJID":
            return set(df.index.dropna())
        return set()

    def _adsl_subjs_saffl(adsl_df):
        """Get USUBJID set for safety pop from ADSL, never raises."""
        if adsl_df is None or adsl_df.empty:
            return set()
        try:
            if "USUBJID" in adsl_df.columns and "SAFFL" in adsl_df.columns:
                return set(adsl_df.loc[adsl_df["SAFFL"] == "Y", "USUBJID"].dropna())
            if adsl_df.index.name == "USUBJID" and "SAFFL" in adsl_df.columns:
                return set(adsl_df.index[adsl_df["SAFFL"] == "Y"].dropna())
        except Exception:
            pass
        return _subjs(adsl_df)  # fallback: all subjects

    rows = []

    dm = sdtm_data.get("dm")
    ae = sdtm_data.get("ae")
    ex = sdtm_data.get("ex")
    lb = sdtm_data.get("lb")

    dm_subjs = _subjs(dm)

    # 1. Subjects in AE not in DM
    try:
        if ae is not None and not ae.empty and dm_subjs:
            ae_subjs = _subjs(ae)
            orphan = ae_subjs - dm_subjs
            rows.append({"Rule": "AE subjects not in DM",
                         "Status": "FAIL" if orphan else "PASS",
                         "N": len(orphan),
                         "Example": str(list(orphan)[:3]) if orphan else ""})
    except Exception as _e:
        rows.append({"Rule": "AE subjects not in DM", "Status": "ERROR", "N": 0, "Example": str(_e)})

    # 2. AESTDTC before RFSTDTC
    try:
        if (ae is not None and dm is not None and
                "AESTDTC" in ae.columns and "RFSTDTC" in dm.columns and
                "USUBJID" in ae.columns and "USUBJID" in dm.columns):
            ae_dt = ae[["USUBJID", "AESTDTC"]].copy()
            ae_dt["AESTDTC"] = pd.to_datetime(ae_dt["AESTDTC"], errors="coerce")
            dm_rf = dm[["USUBJID", "RFSTDTC"]].copy()
            dm_rf["RFSTDTC"] = pd.to_datetime(dm_rf["RFSTDTC"], errors="coerce")
            merged = ae_dt.merge(dm_rf, on="USUBJID", how="left")
            pre = merged[(merged["AESTDTC"].notna()) & (merged["RFSTDTC"].notna()) &
                         (merged["AESTDTC"] < merged["RFSTDTC"])]
            n = pre["USUBJID"].nunique()
            rows.append({"Rule": "AE before RFSTDTC",
                         "Status": "WARN" if n > 0 else "PASS",
                         "N": n,
                         "Example": str(pre["USUBJID"].unique()[:3].tolist()) if n else ""})
    except Exception as _e:
        rows.append({"Rule": "AE before RFSTDTC", "Status": "ERROR", "N": 0, "Example": str(_e)})

    # 3. EXENDTC before EXSTDTC
    try:
        if ex is not None and "EXSTDTC" in ex.columns and "EXENDTC" in ex.columns:
            ex2 = ex[[c for c in ["USUBJID", "EXSTDTC", "EXENDTC"] if c in ex.columns]].copy()
            ex2["EXSTDTC"] = pd.to_datetime(ex2["EXSTDTC"], errors="coerce")
            ex2["EXENDTC"] = pd.to_datetime(ex2["EXENDTC"], errors="coerce")
            bad = ex2[(ex2["EXENDTC"].notna()) & (ex2["EXSTDTC"].notna()) &
                      (ex2["EXENDTC"] < ex2["EXSTDTC"])]
            n = len(bad)
            ex_bad_subjs = str(bad["USUBJID"].unique()[:3].tolist()) if n and "USUBJID" in bad.columns else ""
            rows.append({"Rule": "EXENDTC before EXSTDTC",
                         "Status": "FAIL" if n > 0 else "PASS",
                         "N": n, "Example": ex_bad_subjs})
    except Exception as _e:
        rows.append({"Rule": "EXENDTC before EXSTDTC", "Status": "ERROR", "N": 0, "Example": str(_e)})

    # 4. Duplicate AE records
    try:
        if ae is not None and all(c in ae.columns for c in ["USUBJID", "AETERM", "AESTDTC"]):
            n = int(ae.duplicated(subset=["USUBJID", "AETERM", "AESTDTC"], keep=False).sum())
            rows.append({"Rule": "Duplicate AE (USUBJID+AETERM+AESTDTC)",
                         "Status": "WARN" if n > 0 else "PASS",
                         "N": n, "Example": ""})
    except Exception as _e:
        rows.append({"Rule": "Duplicate AE records", "Status": "ERROR", "N": 0, "Example": str(_e)})

    # 5. LB values outside plausible range
    try:
        if lb is not None and "LBSTRESN" in lb.columns and "LBTESTCD" in lb.columns:
            lb2 = lb.copy()
            lb2["LBSTRESN"] = pd.to_numeric(lb2["LBSTRESN"], errors="coerce")
            for test, (lo, hi) in {"WBC": (0, 200), "HGB": (0, 25), "PLT": (0, 3000),
                                    "ALT": (0, 5000), "CREAT": (0, 50)}.items():
                sub = lb2[lb2["LBTESTCD"] == test]
                if sub.empty:
                    continue
                out = sub[(sub["LBSTRESN"] < lo) | (sub["LBSTRESN"] > hi)]
                n = len(out)
                rows.append({"Rule": f"{test} outside [{lo},{hi}]",
                             "Status": "WARN" if n > 0 else "PASS",
                             "N": n,
                             "Example": str(out["LBSTRESN"].head(3).tolist()) if n else ""})
    except Exception as _e:
        rows.append({"Rule": "LB range checks", "Status": "ERROR", "N": 0, "Example": str(_e)})

    # 6. Safety pop subjects with no EX records
    try:
        if ex is not None and adsl is not None:
            safe_subjs = _adsl_subjs_saffl(adsl)
            ex_subjs   = _subjs(ex)
            no_ex = safe_subjs - ex_subjs
            n = len(no_ex)
            rows.append({"Rule": "Safety pop subjects with no EX records",
                         "Status": "WARN" if n > 0 else "PASS",
                         "N": n, "Example": str(list(no_ex)[:3]) if n else ""})
    except Exception as _e:
        rows.append({"Rule": "Safety pop / EX check", "Status": "ERROR", "N": 0, "Example": str(_e)})

    return pd.DataFrame(rows) if rows else pd.DataFrame(columns=["Rule", "Status", "N", "Example"])


# =============================================================================
# Figure export helpers  (X3 - kaleido)
# =============================================================================
def export_figure_png(fig, filename: str = "figure.png") -> Optional[bytes]:
    """Export plotly figure to PNG bytes using kaleido."""
    try:
        return fig.to_image(format="png", width=1200, height=700, scale=2)
    except Exception:
        return None


def export_figure_svg(fig, filename: str = "figure.svg") -> Optional[bytes]:
    """Export plotly figure to SVG bytes using kaleido."""
    try:
        return fig.to_image(format="svg", width=1200, height=700)
    except Exception:
        return None
