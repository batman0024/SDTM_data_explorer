# =============================================================================
# src/utils/config_loader.py  -  Load study_config.yaml into session
# =============================================================================

import os
import json
import logging
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

_CONFIG_CACHE: Optional[Dict] = None


def load_config(config_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Load study_config.yaml.  Falls back to built-in defaults if file missing
    or PyYAML not installed.  Result is cached in module-level variable.
    """
    global _CONFIG_CACHE
    if _CONFIG_CACHE is not None:
        return _CONFIG_CACHE

    if config_path is None:
        # Look relative to this file: ../../config/study_config.yaml
        here = Path(__file__).resolve().parent
        config_path = str(here.parent.parent / "config" / "study_config.yaml")

    try:
        import yaml
        with open(config_path, "r", encoding="utf-8") as fh:
            cfg = yaml.safe_load(fh)
        logger.info("Loaded config from %s", config_path)
        _CONFIG_CACHE = cfg
        return cfg
    except ImportError:
        logger.warning("PyYAML not installed; using built-in config defaults")
    except FileNotFoundError:
        logger.warning("Config file not found: %s; using defaults", config_path)
    except Exception as exc:
        logger.warning("Config load failed: %s; using defaults", exc)

    _CONFIG_CACHE = _get_defaults()
    return _CONFIG_CACHE


def _get_defaults() -> Dict[str, Any]:
    """Hard-coded defaults matching study_config.yaml structure."""
    return {
        "populations": {
            "safety": "SAFFL",
            "itt": "ITTFL",
            "per_protocol": "PPROTFL",
            "modified_itt": "MITTFL",
        },
        "treatment": {
            "planned": "TRT01P",
            "actual":  "TRT01A",
            "numeric": "TRT01AN",
        },
        "lab_panels": {
            "Hepatic":     ["ALT", "AST", "ALP", "BILI", "TBIL", "GGT", "LDH"],
            "Renal":       ["CREAT", "BUN", "SODIUM", "POTASSIUM", "PHOS", "URIC"],
            "Hematology":  ["HGB", "WBC", "PLT", "RBC", "NEUT", "LYM", "MONO", "EOS"],
            "Coagulation": ["PT", "PTT", "INR", "APTT"],
            "Metabolic":   ["GLUC", "CHOL", "TRIG", "HDL", "LDL", "ALB", "PROT", "CA"],
            "Thyroid":     ["TSH", "T3", "T4", "FT4"],
        },
        "maav_thresholds": {
            "ALT":   {"high_uln": 3.0,  "low_lln": None, "label": "ALT > 3x ULN"},
            "AST":   {"high_uln": 3.0,  "low_lln": None, "label": "AST > 3x ULN"},
            "ALP":   {"high_uln": 2.5,  "low_lln": None, "label": "ALP > 2.5x ULN"},
            "BILI":  {"high_uln": 2.0,  "low_lln": None, "label": "Bili > 2x ULN"},
            "CREAT": {"high_uln": 2.0,  "low_lln": None, "label": "Creat > 2x ULN"},
            "HGB":   {"high_uln": None, "low_lln": 0.8,  "label": "Hgb < 0.8x LLN"},
            "PLT":   {"high_uln": None, "low_lln": 0.75, "label": "Plt < 0.75x LLN"},
            "WBC":   {"high_uln": None, "low_lln": 0.75, "label": "WBC < 0.75x LLN"},
            "NEUT":  {"high_uln": None, "low_lln": 0.5,  "label": "Neut < 0.5x LLN"},
        },
        "vs_thresholds": {
            "SYSBP":  {"high": 160,  "low": 90,   "label": "Systolic BP (mmHg)"},
            "DIABP":  {"high": 100,  "low": 60,   "label": "Diastolic BP (mmHg)"},
            "HR":     {"high": 100,  "low": 50,   "label": "Heart Rate (bpm)"},
            "PULSE":  {"high": 100,  "low": 50,   "label": "Pulse (bpm)"},
            "TEMP":   {"high": 38.5, "low": 36.0, "label": "Temperature (C)"},
            "RESP":   {"high": 20,   "low": 12,   "label": "Respiration Rate"},
        },
        "qtc": {
            "concern_threshold_male":   450,
            "concern_threshold_female": 470,
            "high_risk_threshold":      500,
            "delta_concern":            30,
            "delta_high_risk":          60,
        },
        "ctcae_grade_map": {
            "MILD": 1, "GRADE 1": 1, "G1": 1,
            "MODERATE": 2, "GRADE 2": 2, "G2": 2,
            "SEVERE": 3, "GRADE 3": 3, "G3": 3,
            "LIFE-THREATENING": 4, "LIFE THREATENING": 4, "GRADE 4": 4, "G4": 4,
            "FATAL": 5, "DEATH": 5, "GRADE 5": 5, "G5": 5,
        },
        "ae_related_terms": [
            "RELATED", "PROBABLE", "POSSIBLE", "DEFINITE",
            "POSSIBLY RELATED", "PROBABLY RELATED", "DEFINITELY RELATED",
            "Y", "YES",
        ],
        "graph": {
            "max_subjects": 500,
            "default_layout": "spring",
            "ae_cooccurrence_min_subjects": 2,
        },
    }


def get_lab_panels() -> Dict[str, list]:
    return load_config().get("lab_panels", {})


def get_vs_thresholds() -> Dict[str, Dict]:
    return load_config().get("vs_thresholds", {})


def get_maav_thresholds() -> Dict[str, Dict]:
    return load_config().get("maav_thresholds", {})


def get_qtc_thresholds() -> Dict[str, Any]:
    return load_config().get("qtc", {})


def get_ctcae_grade_map() -> Dict[str, int]:
    return load_config().get("ctcae_grade_map", {})


def get_population_flags() -> Dict[str, str]:
    return load_config().get("populations", {})


def get_treatment_vars() -> Dict[str, str]:
    return load_config().get("treatment", {})
